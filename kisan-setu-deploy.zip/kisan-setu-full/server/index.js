#!/usr/bin/env node
/* =====================================================================
   KRISHI SETU — backend
   Zero dependencies: Node's standard library only. Nothing to npm install.

     node server/index.js          → serves the site AND the API on :3000
     PORT=8080 node server/index.js

   Data is stored in server/data/store.json (created on first run, seeded
   with the demo dataset). Every write is atomic: write to a temp file,
   then rename, so a crash can never leave a half-written store.

   REST API
     GET    /api/state                     full dataset (authenticated view)
     POST   /api/state                     replace the caller's dataset (sync)
     POST   /api/reset                     restore the seeded demo dataset
     POST   /api/otp                       { kind:'login'|'register', id|phone } → sends OTP
     POST   /api/sms                       { to, title, body, kind } → outbox + gateway
     POST   /api/webhook/farmer-login      { id, otp } → { ok }
   Every route returns JSON; unknown /api/* returns 404 JSON, not HTML.
   ===================================================================== */

'use strict';

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const PUBLIC_DIR = path.resolve(__dirname, '..');
const DATA_DIR = path.join(__dirname, 'data');
const STORE_FILE = path.join(DATA_DIR, 'store.json');
const OUTBOX_FILE = path.join(DATA_DIR, 'outbox.log');

/* Real SMS gateway (optional). Leave empty and messages are logged only.
   MSG91 flow OTP example:
     SMS_PROVIDER=msg91
     MSG91_AUTH_KEY=your-key
     MSG91_SENDER=KSNSET   (6-char sender ID approved by TRAI)
*/
const SMS_PROVIDER = (process.env.SMS_PROVIDER || '').toLowerCase();
const MSG91_AUTH_KEY = process.env.MSG91_AUTH_KEY || '';
const MSG91_SENDER = process.env.MSG91_SENDER || 'KSNSET';

/* ------------------------------------------------------------------ */
/* demo dataset                                                        */
/* ------------------------------------------------------------------ */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8',
  '.woff2': 'font/woff2', '.webmanifest': 'application/manifest+json'
};

const CROPS = [
  { id: 'wheat', name: 'Wheat', unit: 'quintal', rate: 2475, glyph: 'wheat' },
  { id: 'paddy', name: 'Paddy (Common)', unit: 'quintal', rate: 2369, glyph: 'grain' },
  { id: 'paddy_a', name: 'Paddy (Grade A)', unit: 'quintal', rate: 2420, glyph: 'grain' },
  { id: 'maize', name: 'Maize', unit: 'quintal', rate: 2225, glyph: 'cob' },
  { id: 'ragi', name: 'Ragi', unit: 'quintal', rate: 4290, glyph: 'grain' },
  { id: 'jowar', name: 'Jowar (Hybrid)', unit: 'quintal', rate: 3371, glyph: 'grain' },
  { id: 'bajra', name: 'Bajra', unit: 'quintal', rate: 2775, glyph: 'grain' },
  { id: 'tur', name: 'Tur / Red Gram', unit: 'quintal', rate: 7550, glyph: 'pod' },
  { id: 'groundnut', name: 'Groundnut', unit: 'quintal', rate: 6783, glyph: 'pod' },
  { id: 'cotton', name: 'Cotton (Medium)', unit: 'quintal', rate: 7521, glyph: 'boll' }
];
const CENTERS = [
  { id: 'C1', name: 'Mandya APMC Procurement Centre', short: 'Mandya', district: 'Mandya', capacity: 40, phone: '08232-220145' },
  { id: 'C2', name: 'Mysuru North Purchase Centre', short: 'Mysuru N', district: 'Mysuru', capacity: 32, phone: '0821-2410882' },
  { id: 'C3', name: 'Hassan Taluk Godown — Beltur', short: 'Hassan', district: 'Hassan', capacity: 24, phone: '08172-256310' }
];
const SLOTS = ['09:00', '10:30', '12:00', '14:00', '15:30', '17:00'];
const MAX_AT_WEIGHBRIDGE = 2;
const NO_SHOW_AFTER_MINS = 30;

const pad = n => (n < 10 ? '0' + n : '' + n);
const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const addDays = (base, n) => { const d = new Date(base.getTime()); d.setDate(d.getDate() + n); return d; };

function seededRandom(seed) {
  let a = seed;
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function seedState() {
  const t = new Date(); t.setHours(0, 0, 0, 0);
  const d0 = ymd(t), d1 = ymd(addDays(t, 1)), d3 = ymd(addDays(t, -3)), d4 = ymd(addDays(t, -9));
  const now = Date.now();

  const crops = CROPS.map(c => {
    const rnd = seededRandom(c.rate);
    const history = [];
    let r = c.rate;
    for (let i = 5; i >= 0; i--) {
      history.push({ date: ymd(addDays(t, -i * 6)), rate: Math.round(r), by: i === 5 ? 'season opening' : 'State Mandate 2026-' + (11 + i) });
      r = r - Math.round((rnd() - 0.38) * c.rate * 0.028);
    }
    history[history.length - 1].rate = c.rate;
    return Object.assign({}, c, {
      active: true, updated_at: new Date(now - Math.round(rnd() * 6 + 1) * 3600000).toISOString(),
      updated_by: 'State Procurement Cell', history
    });
  });

  const demo = {
    id: 'KSN-4471', phone: '9845012345', name: 'Ramesh Gowda',
    village: 'Bellur', district: 'Mandya', state: 'Karnataka',
    land_area: 4.2, land_type: 'owned', survey: '118/2B',
    crops: ['wheat', 'maize', 'ragi'],
    bank: { acc: '50100247119203', ifsc: 'HDFC0001234', holder: 'RAMESH GOWDA' },
    created_at: new Date(now - 26 * 86400000).toISOString()
  };
  const farmers = [demo].concat([
    ['KSN-4472', 'Lakshmamma N', '9845077231', 'Hosahalli', 'Mandya'],
    ['KSN-4473', 'Shivakumar B', '9986011447', 'Nagamangala', 'Mandya'],
    ['KSN-4474', 'Fatima Begum', '9741238890', 'Beltur', 'Hassan'],
    ['KSN-4475', 'Mahadev Naik', '9632145578', 'K.R. Nagar', 'Mysuru'],
    ['KSN-4476', 'Chandrappa S', '9880055112', 'Malavalli', 'Mandya'],
    ['KSN-4477', 'Yashodha Devi', '9900147733', 'Pandavapura', 'Mandya']
  ].map(f => ({
    id: f[0], name: f[1], phone: f[2], village: f[3], district: f[4], state: 'Karnataka',
    land_area: +(1.5 + Math.random() * 6).toFixed(1), land_type: 'owned', survey: '',
    crops: ['paddy'], bank: { acc: '50100' + f[0].slice(-9), ifsc: 'SBIN0040122', holder: f[1].toUpperCase() },
    created_at: new Date(now - 30 * 86400000).toISOString()
  })));

  const bookings = [
    {
      id: 'KS-88231', farmer_id: 'KSN-4471', center_id: 'C1', crop_id: 'paddy',
      date: d3, slot: '09:00', est_qty: 24, grade: 'A',
      status: 'payment_initiated', stage: 'payment_initiated',
      created_at: new Date(now - 5 * 86400000).toISOString(),
      checked_in_at: new Date(new Date(d3).getTime() + 9 * 3600000 + 12 * 60000).toISOString(),
      procured_at: new Date(new Date(d3).getTime() + 9 * 3600000 + 41 * 60000).toISOString(),
      payment_init_at: new Date(new Date(d3).getTime() + 15 * 3600000).toISOString(),
      actual_qty: 23.4, rate: 2420, amount: Math.round(23.4 * 2420),
      payment_completed_at: null, utr: null, checked_in_by: 'STAFF-MANDYA-01'
    },
    {
      id: 'KS-88290', farmer_id: 'KSN-4471', center_id: 'C1', crop_id: 'wheat',
      date: d1, slot: '10:30', est_qty: 18, status: 'confirmed', stage: 'booked',
      created_at: new Date(now - 2 * 86400000).toISOString()
    },
    {
      id: 'KS-88104', farmer_id: 'KSN-4471', center_id: 'C2', crop_id: 'maize',
      date: d4, slot: '14:00', est_qty: 12, grade: 'B',
      status: 'payment_completed', stage: 'payment_completed',
      created_at: new Date(now - 12 * 86400000).toISOString(),
      checked_in_at: new Date(new Date(d4).getTime() + 14 * 3600000 + 6 * 60000).toISOString(),
      procured_at: new Date(new Date(d4).getTime() + 14 * 3600000 + 34 * 60000).toISOString(),
      payment_init_at: new Date(new Date(d4).getTime() + 17 * 3600000).toISOString(),
      payment_completed_at: new Date(new Date(d4).getTime() + 41 * 3600000 + 20 * 60000).toISOString(),
      actual_qty: 11.8, rate: 2225, amount: Math.round(11.8 * 2225), utr: 'SBIN260912334455'
    }
  ];

  const order = ['KSN-4472', 'KSN-4473', 'KSN-4477', 'KSN-4476', 'KSN-4475', 'KSN-4471', 'KSN-4474'];
  order.forEach((fid, i) => {
    if (fid === 'KSN-4471') return;
    const stage = i < 2 ? 'checked_in' : 'booked';
    bookings.push({
      id: 'KS-88' + (300 + i), farmer_id: fid, center_id: 'C1',
      crop_id: ['paddy', 'wheat', 'ragi', 'maize', 'paddy_a'][i % 5],
      date: d0, slot: i < 2 ? '09:00' : '10:30',
      est_qty: 8 + Math.round(Math.random() * 22),
      status: stage === 'checked_in' ? 'checked_in' : 'confirmed',
      stage, created_at: new Date(now - (3 + i) * 86400000).toISOString(),
      checked_in_at: i < 2 ? new Date(now - (26 - i * 9) * 60000).toISOString() : null
    });
  });

  const notes = [];
  const push = (phone, title, body, minsAgo, kind) => notes.push({
    id: 'SMS' + (1000 + notes.length), to: phone, title, body,
    at: new Date(now - minsAgo * 60000).toISOString(), kind: kind || 'info'
  });
  push('9845012345', 'Registration complete',
    'KRISHI SETU: Welcome RAMESH GOWDA. Farmer ID KSN-4471. Dial 1800-425-7733 for help. - KISANSETU', 26 * 1440, 'green');
  push('9845012345', 'Slot booked',
    'KRISHI SETU: Slot confirmed KS-88290. Mandya APMC, tomorrow 10:30 AM, Wheat ~18 quintal. Carry Aadhaar + bank passbook. Show QR at gate. - KISANSETU', 2 * 1140, 'green');
  push('9845012345', 'Payment initiated',
    'KRISHI SETU: Payment of Rs 56,628 initiated for KS-88231 (23.4 qtl Paddy Grade A @ Rs 2420). Credit to HDFC****9203 within 72 hrs. - KISANSETU', 3 * 1440, 'gold');
  push('9845012345', 'Payment received',
    'KRISHI SETU: Rs 26,255 credited to HDFC****9203 for KS-88104. Ref SBIN260912334455. Thank you. - KISANSETU', 8 * 1440, 'green');
  push('9845012345', 'Rate update',
    'KRISHI SETU: Wheat rate revised to Rs 2475/quintal at Mandya APMC from today. - KISANSETU', 40, 'teal');

  return {
    version: 1,
    farmers, centers: CENTERS, crops, slots: SLOTS, bookings, notes,
    disputes: [
      { id: 'DSP-2041', booking_id: 'KS-88231', farmer_id: 'KSN-4471', reason: 'Quantity mismatch',
        note: 'Weighbridge showed 24.1 quintal but record shows 23.4. Please re-check.',
        at: new Date(now - 2 * 86400000).toISOString(), status: 'open', resolution: '' },
      { id: 'DSP-2032', booking_id: 'KS-88104', farmer_id: 'KSN-4471', reason: 'Payment delay',
        note: 'Payment not received 5 days after procurement.',
        at: new Date(now - 6 * 86400000).toISOString(), status: 'resolved',
        resolution: 'Verified with PFMS. Credit confirmed on 12 Sep, ref SBIN260912334455. Farmer informed by SMS.' }
    ],
    staff_users: [
      { id: 'STAFF-MANDYA-01', pwd: 'mandya', name: 'Sudha Rao', role: 'Centre Operator', center_id: 'C1' },
      { id: 'STAFF-STATE-99', pwd: 'admin', name: 'Vivek Anand', role: 'State Procurement Officer', center_id: null }
    ],
    settings: { max_at_weighbridge: MAX_AT_WEIGHBRIDGE, no_show_after_mins: NO_SHOW_AFTER_MINS },
    audit: []
  };
}

/* ------------------------------------------------------------------ */
/* store                                                               */
/* ------------------------------------------------------------------ */
let DB = null;
let writeTimer = null;

function loadStore() {
  try {
    if (fs.existsSync(STORE_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(STORE_FILE, 'utf8'));
      if (parsed && parsed.version === 1) { DB = parsed; return; }
    }
  } catch (e) {
    console.error('[store] could not read store.json, re-seeding:', e.message);
  }
  DB = seedState();
  persistNow();
  console.log('[store] seeded demo dataset at', STORE_FILE);
}

function persistNow() {
  if (!DB) return;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const tmp = STORE_FILE + '.' + process.pid + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(DB));
    fs.renameSync(tmp, STORE_FILE);   // atomic on the same filesystem
  } catch (e) {
    console.error('[store] write failed:', e.message);
  }
}

/* debounce: many writes in one tick become one disk write */
function persist() {
  if (writeTimer) return;
  writeTimer = setTimeout(() => { writeTimer = null; persistNow(); }, 40);
}

function audit(who, action, detail) {
  DB.audit.unshift({ at: new Date().toISOString(), who, action, detail: detail || '' });
  if (DB.audit.length > 500) DB.audit.length = 500;
}

/* ------------------------------------------------------------------ */
/* SMS                                                                 */
/* ------------------------------------------------------------------ */
function sendMsg91(to, body) {
  return new Promise(resolve => {
    if (!MSG91_AUTH_KEY) return resolve({ sent: false, reason: 'MSG91_AUTH_KEY not set' });
    const payload = JSON.stringify({
      sender: MSG91_SENDER,
      route: '4',
      country: '91',
      sms: [{ message: body, to: [to] }]
    });
    const req = https.request({
      host: 'api.msg91.com', path: '/api/v5/flow/', method: 'POST',
      headers: {
        'authkey': MSG91_AUTH_KEY, 'content-type': 'application/json',
        'content-length': Buffer.byteLength(payload)
      }
    }, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ sent: res.statusCode < 300, status: res.statusCode, response: data.slice(0, 300) }));
    });
    req.on('error', e => resolve({ sent: false, reason: e.message }));
    req.setTimeout(6000, () => { req.destroy(); resolve({ sent: false, reason: 'gateway timeout' }); });
    req.write(payload); req.end();
  });
}

async function sms(to, title, body, kind) {
  const note = {
    id: 'SMS' + Date.now().toString().slice(-6) + Math.floor(Math.random() * 90 + 10),
    to, title, body, at: new Date().toISOString(), kind: kind || 'info'
  };
  DB.notes.unshift(note);
  if (DB.notes.length > 800) DB.notes.length = 800;

  let delivery = { mode: 'simulated' };
  if (SMS_PROVIDER === 'msg91') {
    delivery = Object.assign({ mode: 'msg91' }, await sendMsg91(to, body));
    note.delivered = !!delivery.sent;
  }
  note.delivery = delivery;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.appendFileSync(OUTBOX_FILE, JSON.stringify(note) + '\n');
  } catch (e) { /* outbox is a convenience, not critical */ }
  persist();
  console.log(`[sms] ${delivery.mode} → ${to} · ${title}`);
  return note;
}

/* ------------------------------------------------------------------ */
/* OTP                                                                 */
/* ------------------------------------------------------------------ */
const otps = new Map();   // key → { code, expires }
function issueOtp(key) {
  const code = String(crypto.randomInt(100000, 999999));
  otps.set(key, { code, expires: Date.now() + 5 * 60000 });
  return code;
}
function verifyOtp(key, code) {
  const rec = otps.get(key);
  if (!rec) return false;
  if (Date.now() > rec.expires) { otps.delete(key); return false; }
  if (rec.code !== String(code)) return false;
  otps.delete(key);
  return true;
}

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */
const json = (res, code, obj) => {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store'
  });
  res.end(body);
};

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', c => {
      raw += c;
      if (raw.length > 2e6) { reject(new Error('payload too large')); req.destroy(); }
    });
    req.on('end', () => {
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch (e) { reject(new Error('invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function publicState() {
  // strip staff passwords before anything leaves the server
  return Object.assign({}, DB, {
    staff_users: DB.staff_users.map(u => ({
      id: u.id, name: u.name, role: u.role, center_id: u.center_id
    }))
  });
}

function safeJoin(root, urlPath) {
  const target = path.normalize(path.join(root, urlPath));
  return target.startsWith(root) ? target : null;
}

/* ------------------------------------------------------------------ */
/* API routes                                                          */
/* ------------------------------------------------------------------ */
const routes = {
  'GET /api/health': async () => ({ ok: true, uptime: process.uptime(), sms: SMS_PROVIDER || 'simulated' }),

  'GET /api/state': async () => publicState(),

  'POST /api/state': async (body) => {
    if (!body || body.version !== 1) throw httpError(400, 'expected a version 1 dataset');
    const session = body.session || null, staff = body.staff || null;
    // keep server-side records that the browser never holds
    DB = Object.assign({}, body, {
      staff_users: DB.staff_users,
      audit: DB.audit,
      session: null, staff: null
    });
    persist();
    return { ok: true, saved_at: new Date().toISOString(), session, staff };
  },

  'POST /api/reset': async (body, req, res) => {
    DB = seedState();
    persistNow();
    audit('system', 'reset', 'demo dataset restored');
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, state: publicState() }));
    return null;   // response already sent
  },

  'POST /api/otp': async (body) => {
    const kind = body.kind === 'register' ? 'register' : 'login';
    const key = kind + ':' + String(body.id || body.phone || '').toUpperCase();
    const code = issueOtp(key);
    if (kind === 'login') {
      const f = DB.farmers.find(x => x.id === String(body.id || '').toUpperCase());
      if (f) await sms(f.phone, 'Login OTP', 'KRISHI SETU: Your login OTP is ' + code + '. Valid for 5 minutes. Do not share it. - KISANSETU', 'gold');
    } else {
      await sms(String(body.phone || ''), 'Registration OTP',
        'KRISHI SETU: Your registration OTP is ' + code + '. Valid for 5 minutes. - KISANSETU', 'gold');
    }
    // The code is echoed so the demo can run with no SMS gateway configured.
    // Delete this line once a real gateway is connected.
    return { ok: true, demo_code: SMS_PROVIDER ? undefined : code, expires_in_s: 300 };
  },

  'POST /api/webhook/farmer-login': async (body) => {
    const id = String(body.id || '').toUpperCase();
    if (!verifyOtp('login:' + id, body.otp)) throw httpError(401, 'incorrect or expired OTP');
    const f = DB.farmers.find(x => x.id === id);
    if (!f) throw httpError(404, 'no such farmer ID');
    audit(f.id, 'login', 'farmer login');
    return { ok: true, farmer: f };
  },

  'POST /api/register': async (body) => {
    const phone = String(body.phone || '').replace(/\D/g, '');
    if (!/^\d{10}$/.test(phone)) throw httpError(400, 'a 10-digit mobile number is required');
    if (DB.farmers.some(f => f.phone === phone)) throw httpError(409, 'that mobile number is already registered');
    const id = 'KSN-' + (4500 + DB.farmers.length);
    const farmer = {
      id, phone, name: String(body.name || '').trim(),
      village: String(body.village || ''), district: String(body.district || ''),
      state: String(body.state || 'Karnataka'),
      land_area: Number(body.land_area) || 0, land_type: body.land_type || 'owned',
      survey: body.survey || '', crops: Array.isArray(body.crops) ? body.crops : [],
      bank: {
        acc: String((body.bank && body.bank.acc) || ''),
        ifsc: String((body.bank && body.bank.ifsc) || '').toUpperCase(),
        holder: String((body.bank && body.bank.holder) || '')
      },
      created_at: new Date().toISOString()
    };
    DB.farmers.push(farmer);
    audit(id, 'register', farmer.name + ' from ' + farmer.village);
    persist();
    await sms(phone, 'Registration complete',
      'KRISHI SETU: Welcome ' + farmer.name.toUpperCase() + '. Your Farmer ID is ' + id +
      '. Keep it safe - you will use it to login and at the centre gate. Helpline 1800-425-7733. - KISANSETU', 'green');
    return { ok: true, farmer };
  },

  'POST /api/sms': async (body) => {
    if (!body || !body.to) throw httpError(400, 'a recipient is required');
    const note = await sms(String(body.to), String(body.title || 'Alert'), String(body.body || ''), body.kind);
    return { ok: true, note };
  },

  'GET /api/outbox': async () => ({ count: DB.notes.length, notes: DB.notes.slice(0, 100) })
};

function httpError(code, message) {
  const e = new Error(message);
  e.status = code;
  return e;
}

/* ------------------------------------------------------------------ */
/* static files                                                        */
/* ------------------------------------------------------------------ */
function serveStatic(req, res, urlPath) {
  let p = urlPath === '/' ? '/index.html' : urlPath;
  const full = safeJoin(PUBLIC_DIR, p);
  if (!full) { res.writeHead(403); return res.end('Forbidden'); }
  fs.stat(full, (err, st) => {
    if (err || !st.isFile()) {
      // unknown path → the landing page, so deep links still work
      const fallback = path.join(PUBLIC_DIR, 'index.html');
      return fs.readFile(fallback, (e2, buf) => {
        if (e2) { res.writeHead(404); return res.end('Not found'); }
        res.writeHead(200, { 'Content-Type': MIME['.html'] });
        res.end(buf);
      });
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': 'no-cache'
    });
    fs.createReadStream(full).pipe(res);
  });
}

/* ------------------------------------------------------------------ */
/* server                                                              */
/* ------------------------------------------------------------------ */
const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  const key = req.method + ' ' + u.pathname;

  res.setHeader('X-Content-Type-Options', 'nosniff');
  /* The frontend may be hosted elsewhere (Netlify) while the API runs here. */
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Max-Age', '600');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  if (u.pathname.startsWith('/api/')) {
    const handler = routes[key];
    if (!handler) return json(res, 404, { error: 'no such endpoint', path: u.pathname });
    try {
      const body = req.method === 'POST' ? await readBody(req) : {};
      const out = await handler(body, req, res);
      if (out !== null && !res.writableEnded) json(res, 200, out);
    } catch (e) {
      const code = e.status || 500;
      if (code === 500) console.error('[api]', key, e.message);
      json(res, code, { error: e.message || 'server error' });
    }
    return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') return json(res, 405, { error: 'method not allowed' });
  serveStatic(req, res, decodeURIComponent(u.pathname));
});

loadStore();
server.listen(PORT, HOST, () => {
  console.log('');
  console.log('  Krishi Setu — server running');
  console.log('  Site      http://localhost:' + PORT);
  console.log('  API       http://localhost:' + PORT + '/api/state');
  console.log('  Health    http://localhost:' + PORT + '/api/health');
  console.log('  Data      ' + STORE_FILE);
  console.log('  SMS       ' + (SMS_PROVIDER === 'msg91' ? 'MSG91 gateway' + (MSG91_AUTH_KEY ? ' (key set)' : ' (NO KEY)') : 'simulated — logged to server/data/outbox.log'));
  console.log('');
});

process.on('SIGTERM', () => { persistNow(); server.close(() => process.exit(0)); });
process.on('SIGINT', () => { persistNow(); server.close(() => process.exit(0)); });

module.exports = { server, seedState, publicState };
