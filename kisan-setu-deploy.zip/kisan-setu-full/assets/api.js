/* =====================================================================
   KRISHI SETU — server bridge

   Every read and write goes through here. If the backend answers, the
   app runs on shared server data (two phones see the same queue). If it
   does not — you opened index.html straight from disk, or the server is
   down — the app silently falls back to this browser's own storage, so
   the demo never breaks on stage.

   Nothing else in the app knows the difference.
   ===================================================================== */
(function () {
  'use strict';

  /* Absolute, so the bridge also works when the frontend is hosted somewhere
     other than the API (set window.KS_API_BASE before this file to override). */
  var BASE = (window.KS_API_BASE || (window.location && window.location.origin) || '').replace(/\/$/, '');
  var online = false;
  var pending = null;
  var listeners = [];

  function onChange(fn) { listeners.push(fn); }
  function emit() { listeners.forEach(function (fn) { try { fn(online); } catch (e) {} }); }

  /* Very old browsers have no fetch at all — treat that as "no backend". */
  function getFetch() {
    if (typeof window.fetch === 'function') return window.fetch.bind(window);
    if (typeof globalThis !== 'undefined' && typeof globalThis.fetch === 'function') return globalThis.fetch.bind(globalThis);
    return null;
  }

  function request(method, url, body) {
    var f = getFetch();
    if (!f) return Promise.reject(new Error('fetch unavailable'));
    var opts = { method: method, headers: {}, cache: 'no-store' };
    if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    return f(BASE + url, opts).then(function (r) {
      return r.text().then(function (text) {
        var data = null;
        try { data = text ? JSON.parse(text) : null; } catch (e) { /* non-JSON */ }
        if (!r.ok) {
          var err = new Error((data && data.error) || ('HTTP ' + r.status));
          err.status = r.status;
          throw err;
        }
        return data;
      });
    });
  }

  /* Pull the shared dataset. Resolves with the state, or null if offline. */
  function pull(fallbackLocal) {
    return request('GET', '/api/state').then(function (state) {
      online = true; emit();
      // the server never stores who is logged in — that stays per browser
      var local = fallbackLocal ? fallbackLocal() : null;
      state.session = local && local.session ? local.session : null;
      state.staff = local && local.staff ? local.staff : null;
      return state;
    }).catch(function () {
      online = false; emit();
      return null;
    });
  }

  /* Push the whole dataset. Debounced: a burst of edits becomes one write. */
  function push(state) {
    if (!online) return Promise.resolve(null);
    if (pending) clearTimeout(pending);
    return new Promise(function (resolve) {
      pending = setTimeout(function () {
        pending = null;
        request('POST', '/api/state', state)
          .then(function (r) { resolve(r); })
          .catch(function () { online = false; emit(); resolve(null); });
      }, 60);
    });
  }

  function reset() {
    return request('POST', '/api/reset', {}).then(function (r) {
      online = true; emit();
      return r && r.state ? r.state : null;
    }).catch(function () { online = false; emit(); return null; });
  }

  /* Ask the server to send an OTP. Falls back to a locally generated code. */
  function requestOtp(kind, idOrPhone) {
    var payload = kind === 'register' ? { kind: kind, phone: idOrPhone } : { kind: kind, id: idOrPhone };
    return request('POST', '/api/otp', payload).catch(function () {
      var code = String(Math.floor(100000 + Math.random() * 899999));
      return { ok: true, demo_code: code, local: true };
    });
  }

  function verifyLogin(id, otp) {
    return request('POST', '/api/webhook/farmer-login', { id: id, otp: otp });
  }

  function isOnline() { return online; }

  window.KSAPI = {
    pull: pull, push: push, reset: reset, requestOtp: requestOtp,
    verifyLogin: verifyLogin, isOnline: isOnline, onChange: onChange, request: request
  };
})();
