/* ============================================================
   KRISHI SETU — application logic
   Single vanilla JS module. No build step, no framework.
   Persists to localStorage so the whole journey can be demoed
   offline: register → login → book → queue → procure → pay.
   ============================================================ */
(function () {
  'use strict';

  var STORE_KEY = 'kisan_setu_v1';
  var $  = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* ---------------- tiny utils ---------------- */
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function inr(n) {
    n = Math.round(Number(n) || 0);
    try { return '₹' + n.toLocaleString('en-IN'); } catch (e) { return '₹' + n; }
  }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function ymd(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function addDays(base, n) { var d = new Date(base.getTime()); d.setDate(d.getDate() + n); return d; }
  function today() { var d = new Date(); d.setHours(0, 0, 0, 0); return d; }
  function parseYmd(s) { var p = s.split('-'); return new Date(+p[0], +p[1] - 1, +p[2]); }
  function fmtDate(s) {
    var d = parseYmd(s), t = today(), diff = Math.round((d - t) / 86400000);
    var label = d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
    if (diff === 0) return 'Today, ' + label;
    if (diff === 1) return 'Tomorrow, ' + label;
    if (diff === -1) return 'Yesterday, ' + label;
    return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
  }
  function fmtStamp(iso) {
    var d = new Date(iso);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) + ', ' +
      d.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' });
  }
  function minsFromSlot(slot) { var p = slot.split(':'); return (+p[0]) * 60 + (+p[1]); }
  function uid(prefix) {
    return prefix + '-' + Math.random().toString(36).slice(2, 6).toUpperCase() +
      Math.floor(Math.random() * 90 + 10);
  }
  function mulberry(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  /* Navigation goes through here so it can be observed in automated tests. */
  function goto(url) {
    if (window.__KS_NAV) { window.__KS_NAV(url); return; }
    window.location.href = url;
  }

  function initials(name) {
    return name.split(' ').filter(Boolean).slice(0, 2).map(function (w) { return w[0]; }).join('').toUpperCase();
  }

  /* ---------------- static reference data ---------------- */
  var CROPS = [
    { id: 'wheat',      name: 'Wheat',     unit: 'quintal', rate: 2475, active: true, glyph: 'wheat' },
    { id: 'paddy',      name: 'Paddy (Common)',  unit: 'quintal', rate: 2369, active: true, glyph: 'grain' },
    { id: 'paddy_a',    name: 'Paddy (Grade A)', unit: 'quintal', rate: 2420, active: true, glyph: 'grain' },
    { id: 'maize',      name: 'Maize',     unit: 'quintal', rate: 2225, active: true, glyph: 'cob' },
    { id: 'ragi',       name: 'Ragi',      unit: 'quintal', rate: 4290, active: true, glyph: 'grain' },
    { id: 'jowar',      name: 'Jowar (Hybrid)',   unit: 'quintal', rate: 3371, active: true, glyph: 'grain' },
    { id: 'bajra',      name: 'Bajra',     unit: 'quintal', rate: 2775, active: true, glyph: 'grain' },
    { id: 'tur',        name: 'Tur / Red Gram',     unit: 'quintal', rate: 7550, active: true, glyph: 'pod' },
    { id: 'groundnut',  name: 'Groundnut',   unit: 'quintal', rate: 6783, active: true, glyph: 'pod' },
    { id: 'cotton',     name: 'Cotton (Medium)',   unit: 'quintal', rate: 7521, active: true, glyph: 'boll' }
  ];

  var CENTERS = [
    { id: 'C1', name: 'Mandya APMC Procurement Centre', short: 'Mandya',   district: 'Mandya',   capacity: 40, phone: '08232-220145' },
    { id: 'C2', name: 'Mysuru North Purchase Centre',   short: 'Mysuru N', district: 'Mysuru',   capacity: 32, phone: '0821-2410882' },
    { id: 'C3', name: 'Hassan Taluk Godown — Beltur',   short: 'Hassan',   district: 'Hassan',   capacity: 24, phone: '08172-256310' }
  ];

  var SLOTS = ['09:00', '10:30', '12:00', '14:00', '15:30', '17:00'];

  /* Centre rules. Two farmers may occupy the weighbridge at once (one being
     weighed, one unloading); a slot hold lapses after 30 minutes. */
  var MAX_AT_WEIGHBRIDGE = 2;
  var NO_SHOW_AFTER_MINS = 30;

  var STAGES = [
    { key: 'booked',     label: 'Slot Booked' },
    { key: 'checked_in', label: 'Checked In' },
    { key: 'procured',   label: 'Quantity Recorded' },
    { key: 'payment_initiated', label: 'Payment Initiated' },
    { key: 'payment_completed', label: 'Payment Completed' }
  ];

  var STAGE_INDEX = {};
  STAGES.forEach(function (s, i) { STAGE_INDEX[s.key] = i; });

  /* ---------------- state ---------------- */
  var S = null;

  function freshState() {
    var t = today();
    var d0 = ymd(t), d1 = ymd(addDays(t, 1)), d2 = ymd(addDays(t, 2)),
        d3 = ymd(addDays(t, -3)), d4 = ymd(addDays(t, -9));
    var now = Date.now();

    /* price history (last 6 revisions, deterministic) */
    var crops = CROPS.map(function (c) {
      var rnd = mulberry(c.rate);
      var hist = [], r = c.rate;
      for (var i = 5; i >= 0; i--) {
        var d = ymd(addDays(t, -i * 6));
        hist.push({ date: d, rate: Math.round(r), by: i === 5 ? 'season opening' : 'State Mandate 2026-' + (11 + i) });
        r = r - Math.round((rnd() - 0.38) * c.rate * 0.028);
      }
      hist[hist.length - 1].rate = c.rate;
      return {
        id: c.id, name: c.name, hi: c.hi, unit: c.unit, rate: c.rate, active: c.active,
        glyph: c.glyph, updated_at: new Date(now - Math.round(rnd() * 6 + 1) * 3600000).toISOString(),
        updated_by: 'State Procurement Cell', history: hist
      };
    });

    /* demo farmer + neighbours in the same queue */
    var demo = {
      id: 'KSN-4471', phone: '9845012345', name: 'Ramesh Gowda',
      village: 'Bellur', district: 'Mandya', state: 'Karnataka',
      land_area: 4.2, land_type: 'owned', survey: '118/2B',
      crops: ['wheat', 'maize', 'ragi'],
      bank: { acc: '50100247119203', ifsc: 'HDFC0001234', holder: 'RAMESH GOWDA' },
      created_at: new Date(now - 26 * 86400000).toISOString()
    };

    var farmers = [demo].concat([
      ['KSN-4472', 'Lakshmamma N', '9845077231', 'Hosahalli', 'Mandya'],
      ['KSN-4473', 'Shivakumar B', '9986011447', 'Nagamangala', 'Mandya'],
      ['KSN-4474', 'Fatima Begum', '9741238890', 'Beltur', 'Hassan'],
      ['KSN-4475', 'Mahadev Naik', '9632145578', 'K.R. Nagar', 'Mysuru'],
      ['KSN-4476', 'Chandrappa S', '9880055112', 'Malavalli', 'Mandya'],
      ['KSN-4477', 'Yashodha Devi', '9900147733', 'Pandavapura', 'Mandya']
    ].map(function (f) {
      return {
        id: f[0], name: f[1], phone: f[2], village: f[3], district: f[4], state: 'Karnataka',
        land_area: +(1.5 + Math.random() * 6).toFixed(1), land_type: 'owned', survey: '',
        crops: ['paddy'], bank: { acc: '50100' + f[0].slice(-9), ifsc: 'SBIN0040122', holder: f[1].toUpperCase() },
        created_at: new Date(now - 30 * 86400000).toISOString()
      };
    }));

    var bookings = [
      {
        id: 'KS-88231', farmer_id: 'KSN-4471', center_id: 'C1', crop_id: 'paddy',
        date: d3, slot: '09:00', est_qty: 24, grade: 'A',
        status: 'payment_initiated', stage: 'payment_initiated',
        created_at: new Date(now - 5 * 86400000).toISOString(),
        checked_in_at: new Date(parseYmd(d3).getTime() + 9 * 3600000 + 12 * 60000).toISOString(),
        procured_at: new Date(parseYmd(d3).getTime() + 9 * 3600000 + 41 * 60000).toISOString(),
        payment_init_at: new Date(parseYmd(d3).getTime() + 15 * 3600000).toISOString(),
        actual_qty: 23.4, rate: 2420, amount: Math.round(23.4 * 2420),
        payment_completed_at: null, utr: null, checked_in_by: 'STAFF-MANDYA-01'
      },
      {
        id: 'KS-88290', farmer_id: 'KSN-4471', center_id: 'C1', crop_id: 'wheat',
        date: d1, slot: '10:30', est_qty: 18,
        status: 'confirmed', stage: 'booked',
        created_at: new Date(now - 2 * 86400000).toISOString()
      },
      {
        id: 'KS-88104', farmer_id: 'KSN-4471', center_id: 'C2', crop_id: 'maize',
        date: d4, slot: '14:00', est_qty: 12, grade: 'B',
        status: 'payment_completed', stage: 'payment_completed',
        created_at: new Date(now - 12 * 86400000).toISOString(),
        checked_in_at: new Date(parseYmd(d4).getTime() + 14 * 3600000 + 6 * 60000).toISOString(),
        procured_at: new Date(parseYmd(d4).getTime() + 14 * 3600000 + 34 * 60000).toISOString(),
        payment_init_at: new Date(parseYmd(d4).getTime() + 17 * 3600000).toISOString(),
        payment_completed_at: new Date(parseYmd(d4).getTime() + 41 * 3600000 + 20 * 60000).toISOString(),
        actual_qty: 11.8, rate: 2225, amount: Math.round(11.8 * 2225),
        utr: 'SBIN260912334455'
      }
    ];

    /* today's live queue at Mandya — demo farmer is #6 */
    var order = ['KSN-4472', 'KSN-4473', 'KSN-4477', 'KSN-4476', 'KSN-4475', 'KSN-4471', 'KSN-4474'];
    order.forEach(function (fid, i) {
      if (fid === 'KSN-4471') return;
      var stage = i < 2 ? 'checked_in' : 'booked';
      bookings.push({
        id: 'KS-88' + (300 + i), farmer_id: fid, center_id: 'C1',
        crop_id: ['paddy', 'wheat', 'ragi', 'maize', 'paddy_a'][i % 5],
        date: d0, slot: i < 2 ? '09:00' : '10:30',
        est_qty: 8 + Math.round(Math.random() * 22),
        status: stage === 'checked_in' ? 'checked_in' : 'confirmed',
        stage: stage,
        created_at: new Date(now - (3 + i) * 86400000).toISOString(),
        checked_in_at: i < 2 ? new Date(now - (26 - i * 9) * 60000).toISOString() : null
      });
    });

    var notes = [];
    function push(id, phone, title, body, minsAgo, kind) {
      notes.push({
        id: 'SMS' + (1000 + notes.length), to: phone, title: title, body: body,
        at: new Date(now - minsAgo * 60000).toISOString(), kind: kind || 'info'
      });
    }
    push('KSN-4471', '9845012345', 'Registration complete',
      'KRISHI SETU: Welcome RAMESH GOWDA. Farmer ID KSN-4471. Dial 1800-425-7733 for help. - KISANSETU', 26 * 1440, 'green');
    push('KSN-4471', '9845012345', 'Slot booked',
      'KRISHI SETU: Slot confirmed KS-88290. Mandya APMC, tomorrow 10:30 AM, Wheat ~18 quintal. Carry Aadhaar + bank passbook. Show QR at gate. - KISANSETU', 2 * 1440, 'green');
    push('KSN-4471', '9845012345', 'Payment initiated',
      'KRISHI SETU: Payment of Rs 56,628 initiated for KS-88231 (23.4 qtl Paddy Grade A @ Rs 2420). Credit to HDFC****9203 within 72 hrs. - KISANSETU', 3 * 1440, 'gold');
    push('KSN-4471', '9845012345', 'Payment received',
      'KRISHI SETU: Rs 26,255 credited to HDFC****9203 for KS-88104. Ref SBIN260912334455. Thank you. - KISANSETU', 8 * 1440, 'green');
    push('KSN-4471', '9845012345', 'Rate update',
      'KRISHI SETU: Wheat rate revised to Rs 2475/quintal at Mandya APMC from today. See ks-setu.gov.in/rates. - KISANSETU', 40, 'teal');

    return {
      version: 1,
      session: null,
      staff: null,
      farmers: farmers,
      centers: CENTERS,
      crops: crops,
      slots: SLOTS,
      bookings: bookings,
      notes: notes,
      disputes: [
        {
          id: 'DSP-2041', booking_id: 'KS-88231', farmer_id: 'KSN-4471',
          reason: 'Quantity mismatch', note: 'Weighbridge showed 24.1 quintal but record shows 23.4. Please re-check.',
          at: new Date(now - 2 * 86400000).toISOString(), status: 'open', resolution: ''
        },
        {
          id: 'DSP-2032', booking_id: 'KS-88104', farmer_id: 'KSN-4471',
          reason: 'Payment delay', note: 'Payment not received 5 days after procurement.',
          at: new Date(now - 6 * 86400000).toISOString(), status: 'resolved',
          resolution: 'Verified with PFMS. Credit confirmed on 12 Sep, ref SBIN260912334455. Farmer informed by SMS.'
        }
      ],
      staff_users: [
        { id: 'STAFF-MANDYA-01', pwd: 'mandya', name: 'Sudha Rao', role: 'Centre Operator', center_id: 'C1' },
        { id: 'STAFF-STATE-99',  pwd: 'admin',  name: 'Vivek Anand',  role: 'State Procurement Officer', center_id: null }
      ],
      last_otp: null
    };
  }

  function load() {
    try {
      var raw = localStorage.getItem(STORE_KEY);
      if (raw) { S = JSON.parse(raw); if (S && S.version === 1) return; }
    } catch (e) { /* fall through to seed */ }
    S = freshState();
    save();
  }
  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(S)); } catch (e) {}
    /* Mirror to the backend when one is reachable. The local copy is always
       written first, so a dropped network never loses the user's action. */
    if (window.KSAPI && window.KSAPI.isOnline()) window.KSAPI.push(S);
  }
  function resetAll() {
    if (window.KSAPI && window.KSAPI.isOnline()) {
      window.KSAPI.reset().then(function (remote) {
        S = remote || freshState();
        S.session = null; S.staff = null;
        try { localStorage.setItem(STORE_KEY, JSON.stringify(S)); } catch (e) {}
        goto('index.html');
      });
      return;
    }
    S = freshState(); save(); goto('index.html');
  }

  /* ---------------- lookup helpers ---------------- */
  function farmer(id) { for (var i = 0; i < S.farmers.length; i++) if (S.farmers[i].id === id) return S.farmers[i]; return null; }
  function crop(id) { for (var i = 0; i < S.crops.length; i++) if (S.crops[i].id === id) return S.crops[i]; return null; }
  function center(id) { for (var i = 0; i < S.centers.length; i++) if (S.centers[i].id === id) return S.centers[i]; return null; }
  function booking(id) { for (var i = 0; i < S.bookings.length; i++) if (S.bookings[i].id === id) return S.bookings[i]; return null; }
  function me() { return S.session ? farmer(S.session) : null; }
  function cropName(c) { var x = crop(c); return x ? x.name : c; }

  /* ---------------- SMS / notifications ---------------- */
  function sms(phone, title, body, kind) {
    S.notes.unshift({
      id: 'SMS' + Date.now().toString().slice(-6), to: phone, title: title,
      body: body, at: new Date().toISOString(), kind: kind || 'info'
    });
    save();
    toast('SMS sent to ' + phone, title + ' — ' + body.slice(0, 62) + (body.length > 62 ? '…' : ''), kind);
  }
  function notesFor(id) {
    var f = farmer(id); if (!f) return [];
    return S.notes.filter(function (n) { return n.to === f.phone; });
  }

  /* ---------------- toast ---------------- */
  function toast(title, msg, kind) {
    var box = $('#toasts');
    if (!box) { box = document.createElement('div'); box.id = 'toasts'; box.className = 'toasts'; document.body.appendChild(box); }
    var el = document.createElement('div');
    el.className = 'toast' + (kind && kind !== 'info' ? ' ' + kind : '');
    el.innerHTML = '<b>' + esc(title) + '</b>' + esc(msg);
    box.appendChild(el);
    setTimeout(function () { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; setTimeout(function () { el.remove(); }, 320); }, 5200);
  }

  /* ---------------- modal ---------------- */
  function openModal(html) {
    var scrim = $('#modal-scrim');
    if (!scrim) {
      scrim = document.createElement('div'); scrim.id = 'modal-scrim'; scrim.className = 'modal-scrim';
      scrim.addEventListener('click', function (e) { if (e.target === scrim) closeModal(); });
      document.body.appendChild(scrim);
    }
    scrim.innerHTML = '<div class="modal" role="dialog" aria-modal="true">' + html + '</div>';
    scrim.classList.add('open');
    var f = scrim.querySelector('input,button');
    if (f) setTimeout(function () { f.focus(); }, 40);
  }
  function closeModal() { var s = $('#modal-scrim'); if (s) { s.classList.remove('open'); s.innerHTML = ''; } }

  /* ---------------- QR (demo) ---------------- */
  function qrSvg(code, size) {
    var N = 21, rnd = mulberry(code.split('').reduce(function (a, c) { return (a * 31 + c.charCodeAt(0)) | 0; }, 7));
    var cells = [];
    for (var y = 0; y < N; y++) for (var x = 0; x < N; x++) cells[y * N + x] = rnd() > 0.5 ? 1 : 0;
    function finder(ox, oy) {
      for (var y = -1; y < 8; y++) for (var x = -1; x < 8; x++) {
        var px = ox + x, py = oy + y; if (px < 0 || py < 0 || px >= N || py >= N) continue;
        var edge = (x === 0 || y === 0 || x === 6 || y === 6) && x >= 0 && y >= 0 && x <= 6 && y <= 6;
        var core = x >= 2 && x <= 4 && y >= 2 && y <= 4;
        cells[py * N + px] = (edge || core) ? 1 : 0;
      }
    }
    finder(0, 0); finder(N - 7, 0); finder(0, N - 7);
    for (var i = 8; i < N - 8; i++) { cells[6 * N + i] = i % 2 === 0 ? 1 : 0; cells[i * N + 6] = i % 2 === 0 ? 1 : 0; }
    var u = 10, pad = 4, w = (N + pad * 2) * u;
    var out = '<svg viewBox="0 0 ' + w + ' ' + w + '" role="img" aria-label="Booking QR code ' + esc(code) + '">';
    out += '<rect width="' + w + '" height="' + w + '" fill="#FFFFFF"/>';
    for (var yy = 0; yy < N; yy++) for (var xx = 0; xx < N; xx++) {
      if (cells[yy * N + xx]) out += '<rect x="' + ((xx + pad) * u) + '" y="' + ((yy + pad) * u) + '" width="' + u + '" height="' + u + '" fill="#191813"/>';
    }
    return out + '</svg>';
  }

  /* ---------------- crop glyphs ---------------- */
  var GLYPHS = {
    wheat: '<svg class="glyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M12 21V9"/><path d="M12 9c-2.4 0-3.6-1.6-3.6-3.4C10.4 5.6 12 6.6 12 9z"/><path d="M12 9c2.4 0 3.6-1.6 3.6-3.4C13.6 5.6 12 6.6 12 9z"/><path d="M12 14c-2.4 0-3.6-1.6-3.6-3.4C10.4 10.6 12 11.6 12 14z"/><path d="M12 14c2.4 0 3.6-1.6 3.6-3.4C13.6 10.6 12 11.6 12 14z"/><path d="M12 19c-2.4 0-3.6-1.6-3.6-3.4C10.4 15.6 12 16.6 12 19z"/><path d="M12 19c2.4 0 3.6-1.6 3.6-3.4C13.6 15.6 12 16.6 12 19z"/></svg>',
    grain: '<svg class="glyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><ellipse cx="12" cy="7" rx="3" ry="4"/><path d="M12 11v10"/><path d="M8 15c1.5 0 3 1 4 2.5"/><path d="M16 15c-1.5 0-3 1-4 2.5"/></svg>',
    cob: '<svg class="glyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M12 3c3 0 5 3 5 7s-2 8-5 8-5-4-5-8 2-7 5-7z"/><path d="M9 8h6M9 12h6M9 16h6"/><path d="M7 6C5 7 4 9 4 11"/></svg>',
    pod: '<svg class="glyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M7 4c5 0 10 4 10 9s-3 7-6 7-7-3-7-8"/><circle cx="10" cy="10" r="1.4"/><circle cx="13" cy="13" r="1.4"/></svg>',
    boll: '<svg class="glyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M12 21v-6"/><path d="M12 15c-3.5 0-6-2.5-6-6 3.5 0 6 2.5 6 6z"/><path d="M12 15c3.5 0 6-2.5 6-6-3.5 0-6 2.5-6 6z"/><circle cx="12" cy="6" r="2.4"/></svg>'
  };
  function glyph(name) { return GLYPHS[name] || GLYPHS.grain; }

  /* ---------------- slot occupancy ---------------- */
  function occupancy(centerId, date, slot) {
    var taken = 0, mine = 0;
    S.bookings.forEach(function (b) {
      if (b.center_id === centerId && b.date === date && b.slot === slot && b.status !== 'cancelled') { taken++; if (b.farmer_id === S.session) mine++; }
    });
    var c = center(centerId), cap = Math.round((c ? c.capacity : 30) / S.slots.length) + 2;
    return { taken: taken, cap: cap, pct: Math.min(100, Math.round(taken / cap * 100)), mine: mine };
  }
  function slotClass(pct) { return pct >= 100 ? 'high' : pct >= 70 ? 'mid' : 'low'; }
  function slotLabel(pct) { return pct >= 100 ? 'Full' : pct >= 70 ? 'Filling' : 'Open'; }
  function busiestSuggestion(centerId, date, slot) {
    var best = null;
    for (var d = 0; d <= 6; d++) {
      var day = ymd(addDays(parseYmd(date), d));
      for (var i = 0; i < S.slots.length; i++) {
        var sl = S.slots[i];
        if (day === date && sl === slot) continue;
        var o = occupancy(centerId, day, sl);
        if (o.pct < 55 && (!best || o.pct < best.pct)) best = { date: day, slot: sl, pct: o.pct };
      }
      if (best) break;
    }
    return best;
  }

  /* ---------------- charts ---------------- */
  function lineChart(points, opts) {
    opts = opts || {};
    var W = 520, H = 190, L = 46, R = 12, T = 14, B = 28;
    var vals = points.map(function (p) { return p.rate; });
    var min = Math.min.apply(null, vals), max = Math.max.apply(null, vals);
    var spread = (max - min) || Math.max(50, max * 0.02);
    min -= spread * 0.35; max += spread * 0.35;
    var xs = function (i) { return L + (W - L - R) * (points.length === 1 ? 0.5 : i / (points.length - 1)); };
    var ys = function (v) { return T + (H - T - B) * (1 - (v - min) / (max - min)); };
    var d = points.map(function (p, i) { return (i ? 'L' : 'M') + xs(i).toFixed(1) + ' ' + ys(p.rate).toFixed(1); }).join(' ');
    var area = d + ' L' + xs(points.length - 1).toFixed(1) + ' ' + (H - B) + ' L' + xs(0).toFixed(1) + ' ' + (H - B) + ' Z';
    var s = '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="xMidYMid meet">';
    s += '<defs><linearGradient id="gGreen" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#35794A" stop-opacity=".28"/><stop offset="100%" stop-color="#35794A" stop-opacity="0"/></linearGradient></defs>';
    for (var g = 0; g <= 3; g++) {
      var gy = T + (H - T - B) * g / 3, gv = max - (max - min) * g / 3;
      s += '<line class="grid" x1="' + L + '" y1="' + gy.toFixed(1) + '" x2="' + (W - R) + '" y2="' + gy.toFixed(1) + '"/>';
      s += '<text class="lbl" x="' + (L - 8) + '" y="' + (gy + 3).toFixed(1) + '" text-anchor="end">' + Math.round(gv) + '</text>';
    }
    s += '<path class="area" d="' + area + '"/><path class="line" d="' + d + '"/>';
    points.forEach(function (p, i) {
      s += '<circle class="dot" cx="' + xs(i).toFixed(1) + '" cy="' + ys(p.rate).toFixed(1) + '" r="3.2"><title>' + p.date + ' — ₹' + p.rate + '</title></circle>';
      if (i === points.length - 1 || i === 0 || points.length <= 4) {
        s += '<text class="lbl" x="' + xs(i).toFixed(1) + '" y="' + (H - 8) + '" text-anchor="middle">' + p.date.slice(5).replace('-', '/') + '</text>';
      }
    });
    s += '<line class="axis" x1="' + L + '" y1="' + (H - B) + '" x2="' + (W - R) + '" y2="' + (H - B) + '"/>';
    if (opts.caption) s += '<text class="lbl" x="' + L + '" y="10">₹ per ' + esc(opts.caption) + '</text>';
    return s + '</svg>';
  }
  function barChart(rows, opts) {
    opts = opts || {};
    var W = 520, H = 200, L = 40, R = 10, T = 14, B = 44;
    var max = Math.max.apply(null, rows.map(function (r) { return r.value; })) || 1;
    var bw = (W - L - R) / rows.length;
    var s = '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="xMidYMid meet">';
    for (var g = 0; g <= 3; g++) {
      var gy = T + (H - T - B) * g / 3;
      s += '<line class="grid" x1="' + L + '" y1="' + gy.toFixed(1) + '" x2="' + (W - R) + '" y2="' + gy.toFixed(1) + '"/>';
    }
    rows.forEach(function (r, i) {
      var h = (H - T - B) * (r.value / max), x = L + bw * i + bw * 0.2, y = H - B - h;
      s += '<rect class="bar ' + (r.cls || '') + '" x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + (bw * 0.6).toFixed(1) + '" height="' + h.toFixed(1) + '" rx="1.5"><title>' + esc(r.label) + ' — ' + r.value + '</title></rect>';
      s += '<text class="lbl" x="' + (L + bw * i + bw / 2).toFixed(1) + '" y="' + (H - B + 14) + '" text-anchor="middle">' + esc(r.short || r.label) + '</text>';
      s += '<text class="lbl" x="' + (L + bw * i + bw / 2).toFixed(1) + '" y="' + (y - 5).toFixed(1) + '" text-anchor="middle" style="fill:#191813">' + r.value + '</text>';
    });
    s += '<line class="axis" x1="' + L + '" y1="' + (H - B) + '" x2="' + (W - R) + '" y2="' + (H - B) + '"/>';
    if (opts.caption) s += '<text class="lbl" x="' + L + '" y="10">' + esc(opts.caption) + '</text>';
    return s + '</svg>';
  }

  /* ---------------- chrome (header / footer) ---------------- */
  function emblem() {
    return '<svg class="mark" viewBox="0 0 48 48" aria-hidden="true">' +
      '<circle cx="24" cy="24" r="22.5" fill="#F7F3E9" stroke="#1B4A2B" stroke-width="1.6"/>' +
      '<circle cx="24" cy="24" r="18.5" fill="none" stroke="#B0791B" stroke-width=".8" stroke-dasharray="1.5 3"/>' +
      '<path d="M24 36V17" stroke="#1B4A2B" stroke-width="1.8" stroke-linecap="round"/>' +
      '<path d="M24 20c-3.4 0-5-2.3-5-4.9 2.8 0 5 1.4 5 4.9zM24 20c3.4 0 5-2.3 5-4.9-2.8 0-5 1.4-5 4.9z" fill="#27603A"/>' +
      '<path d="M24 26c-3.4 0-5-2.3-5-4.9 2.8 0 5 1.4 5 4.9zM24 26c3.4 0 5-2.3 5-4.9-2.8 0-5 1.4-5 4.9z" fill="#35794A"/>' +
      '<path d="M24 32c-3.4 0-5-2.3-5-4.9 2.8 0 5 1.4 5 4.9zM24 32c3.4 0 5-2.3 5-4.9-2.8 0-5 1.4-5 4.9z" fill="#27603A"/>' +
      '<path d="M13 40h22" stroke="#B0791B" stroke-width="1.4" stroke-linecap="round"/></svg>';
  }

  function siteHeader(active) {
    var links = [
      ['index.html', 'Home', 'home'],
      ['rates.html', 'Today’s rates', 'rates'],
      ['register.html', 'Register', 'register'],
      ['login.html', 'Farmer login', 'login'],
      ['staff-login.html', 'Staff portal', 'staff']
    ];
    var nav = links.map(function (l) {
      return '<a href="' + l[0] + '"' + (active === l[2] ? ' aria-current="page"' : '') + '>' + l[1] + '</a>';
    }).join('');
    return '<div class="util-strip"><div class="wrap">' +
      '<div class="util-links"><span class="tri" aria-hidden="true"><i></i><i></i><i></i></span>' +
      '<span>Department of Agricultural Marketing &amp; Cooperatives</span></div>' +
      '<div class="util-links">' +
      '<span class="conn off">Offline · local data</span>' +
      '<a href="#help">Helpline 1800-425-7733</a>' +
      '<a href="#" onclick="KS.resetAll();return false;" title="Restore demo data">Reset demo</a>' +
      '</div></div></div>' +
      '<header class="masthead"><div class="wrap">' +
      '<a class="brand" href="index.html">' + emblem() +
      '<span class="wordmark"><b>Krishi Setu</b><span>Procurement &amp; Slot Service</span></span></a>' +
      '<nav class="nav" aria-label="Main">' + nav + '</nav>' +
      '<div class="nav-actions"><a class="btn btn-sm btn-ghost" href="demo.html">Guided demo</a>' +
      '<a class="btn btn-sm" href="' + (S.session ? 'dashboard.html' : 'login.html') + '">' +
      (S.session ? 'My account' : 'Login') + '</a></div>' +
      '</div></header>';
  }

  function siteFooter() {
    return '<footer class="foot"><div class="wrap"><div class="cols">' +
      '<div><a class="brand" href="index.html">' + emblem() +
      '<span class="wordmark"><b>Krishi Setu</b><span>Procurement &amp; Slot Service</span></span></a>' +
      '<p class="about">A time-slotted procurement service that lets a farmer sell at the announced rate without an overnight queue — and follow the money to their own bank account.</p></div>' +
      '<div><h4>For farmers</h4>' +
      '<a href="rates.html">Today’s rates</a><a href="register.html">Register</a>' +
      '<a href="login.html">Login</a><a href="notifications.html">SMS alerts</a></div>' +
      '<div><h4>For centres</h4>' +
      '<a href="staff-login.html">Staff portal</a><a href="admin-queue.html">Today’s queue</a>' +
      '<a href="admin-prices.html">Rate management</a><a href="admin-analytics.html">Analytics</a></div>' +
      '<div><h4>Help</h4><a href="#help">Toll-free 1800-425-7733</a>' +
      '<a href="#ivr">IVR booking (6 a.m.–9 p.m.)</a><a href="#grievance">Raise a grievance</a>' +
      '<a href="#terms">Terms &amp; grievance policy</a></div>' +
      '</div><div class="foot-base">' +
      '<span>© 2026 Krishi Setu · Prototype build for demonstration</span>' +
      '<span>Last rate revision: <span class="mono">' + (S.crops[0].updated_at || '').slice(0, 10) + '</span></span>' +
      '</div></div></footer>';
  }

  function appBar(active) {
    var u = me();
    var links = [
      ['dashboard.html', 'Dashboard', 'dash'],
      ['book.html', 'Book a slot', 'book'],
      ['bookings.html', 'My bookings', 'bookings'],
      ['payments.html', 'Payments', 'pay'],
      ['notifications.html', 'Alerts', 'notes'],
      ['profile.html', 'Profile', 'profile']
    ];
    var nav = links.map(function (l) {
      return '<a href="' + l[0] + '"' + (active === l[2] ? ' aria-current="page"' : '') + '>' + l[1] + '</a>';
    }).join('');
    return '<div class="util-strip"><div class="wrap">' +
      '<div class="util-links"><span class="tri" aria-hidden="true"><i></i><i></i><i></i></span>' +
      '<span>Farmer services</span></div>' +
      '<div class="util-links"><span class="conn off">Offline · local data</span>' +
      '<a href="index.html">Public site</a>' +
      '<a href="demo.html">Guided demo</a></div></div></div>' +
      '<header class="appbar"><div class="wrap">' +
      '<a class="brand" href="dashboard.html">' + emblem() +
      '<span class="wordmark"><b>Krishi Setu</b><span>Farmer account</span></span></a>' +
      '<nav class="appnav" aria-label="Farmer">' + nav + '</nav>' +
      (u ? '<div class="userchip"><span class="av">' + initials(u.name) + '</span><span><b>' + esc(u.name) +
        '</b><span>' + esc(u.id) + '</span></span></div>' : '') +
      '<button class="btn btn-ghost btn-sm" type="button" onclick="KS.logout()">Logout</button>' +
      '</div></header>';
  }

  function staffBar(active) {
    var st = S.staff ? (function () { for (var i = 0; i < S.staff_users.length; i++) if (S.staff_users[i].id === S.staff) return S.staff_users[i]; return null; })() : null;
    var links = [
      ['admin-queue.html', 'Queue', 'queue'],
      ['admin-procure.html', 'Record procurement', 'procure'],
      ['admin-payments.html', 'Payments', 'pay'],
      ['admin-prices.html', 'Rates', 'prices'],
      ['admin-analytics.html', 'Analytics', 'stats'],
      ['admin-disputes.html', 'Disputes', 'disputes']
    ];
    var nav = links.map(function (l) {
      return '<a href="' + l[0] + '"' + (active === l[2] ? ' aria-current="page"' : '') + '>' + l[1] + '</a>';
    }).join('');
    var c = st && st.center_id ? center(st.center_id) : null;
    return '<div class="util-strip"><div class="wrap">' +
      '<div class="util-links"><span class="tri" aria-hidden="true"><i></i><i></i><i></i></span>' +
      '<span>Staff portal — ' + esc(st ? st.role : '') + (c ? ' · ' + esc(c.short) + ' centre' : ' · State view') + '</span></div>' +
      '<div class="util-links"><span class="conn off">Offline · local data</span>' +
      '<span class="mono" id="clock"></span><a href="index.html">Public site</a></div></div></div>' +
      '<header class="appbar"><div class="wrap">' +
      '<a class="brand" href="admin-queue.html">' + emblem() +
      '<span class="wordmark"><b>Krishi Setu</b><span>Centre operations</span></span></a>' +
      '<nav class="appnav" aria-label="Staff">' + nav + '</nav>' +
      (st ? '<div class="userchip"><span class="av">' + initials(st.name) + '</span><span><b>' + esc(st.name) +
        '</b><span>' + esc(st.id) + '</span></span></div>' : '') +
      '<button class="btn btn-ghost btn-sm" type="button" onclick="KS.staffLogout()">Sign out</button>' +
      '</div></header>';
  }

  function requireFarmer() { if (!S.session) { goto('login.html'); return false; } return true; }
  function requireStaff() { if (!S.staff) { goto('staff-login.html'); return false; } return true; }

  /* ---------------- shared page renderers ---------------- */
  function statusPill(b) {
    var map = {
      confirmed: ['pill-info', 'Confirmed'],
      checked_in: ['pill-warn', 'Checked in'],
      procured: ['pill-gold', 'Weighed'],
      payment_initiated: ['pill-gold', 'Payment initiated'],
      payment_completed: ['pill-ok', 'Paid'],
      cancelled: ['pill-bad', 'Cancelled'],
      noshow: ['pill-bad', 'No-show']
    };
    var m = map[b.status] || ['pill-idle', b.status];
    return '<span class="pill ' + m[0] + '">' + m[1] + '</span>';
  }

  function rateTable(opts) {
    opts = opts || {};
    var rows = S.crops.filter(function (c) { return !opts.inactiveOnly || !c.active; })
      .filter(function (c) { return opts.inactiveOnly ? true : c.active; });
    var body = rows.map(function (c) {
      var prev = c.history.length > 1 ? c.history[c.history.length - 2].rate : c.rate;
      var delta = c.rate - prev;
      var dcls = delta > 0 ? 'pill-ok' : delta < 0 ? 'pill-bad' : 'pill-idle';
      var arrow = delta > 0 ? '▲' : delta < 0 ? '▼' : '—';
      return '<tr>' +
        '<td><span class="crop" style="color:var(--green-700)">' + glyph(c.glyph) +
        '<span><b>' + esc(S.lang === 'hi' && c.hi ? c.hi : c.name) + '</b><span>per ' + c.unit + ' · ' + esc(c.updated_at.slice(0, 10)) + '</span></span></span></td>' +
        '<td class="num" style="font-weight:600">' + inr(c.rate) + '</td>' +
        '<td><span class="pill ' + dcls + ' pill-plain">' + arrow + ' ' + inr(Math.abs(delta)).replace('₹', '₹') + '</span></td>' +
        (opts.withCentre ? '<td>' + esc(center('C1').short) + '</td>' : '') +
        (opts.withAction ? '<td class="right"><a class="btn btn-ghost btn-sm" href="book.html?crop=' + c.id + '">Book a slot</a></td>' : '') +
        '</tr>';
    }).join('');
    return '<div class="tbl-scroll"><table class="tbl"><thead><tr>' +
      '<th>Crop</th><th>Rate</th><th>Change</th>' +
      (opts.withCentre ? '<th>Centre</th>' : '') +
      (opts.withAction ? '<th class="right"></th>' : '') +
      '</tr></thead><tbody>' + body + '</tbody>' +
      '<tfoot><tr><td colspan="' + (opts.withAction ? 5 : 3) + '">Rates are the Minimum Support Price notified for the current season and are revised only by the State Procurement Cell. Payment is calculated on the rate in force on the day of weighment.</td></tr></tfoot>' +
      '</table></div>';
  }

  /* ============================================================
     GUIDED DEMO
     A floating script card that walks the presenter through the
     whole story, page by page. Turn it on from demo.html or from
     "Guided demo" in the top bar.
     ============================================================ */
  var TOUR_KEY = 'kisan_setu_tour';
  var TOUR = [
    { page: 'index.html', title: 'The problem, in one line',
      say: 'Point at the rate board: the farmer already knows the rate. What they do not know is whether they will be served today, and when the money arrives. That is the gap this closes.',
      to: 'rates.html', toLabel: 'Show the rate board' },
    { page: 'rates.html', title: 'Rates before travelling',
      say: 'Public page, no login. Every crop, every centre, with today\u2019s load percentage. A farmer decides where and when to go before spending money on a tractor trip.',
      to: 'register.html', toLabel: 'Register a farmer' },
    { page: 'register.html', title: 'Registration: five short steps',
      say: 'Identity, address, land holding, bank details, then an OTP. Type a name, a 10-digit number, any 12-digit Aadhaar and 4.2 acres. Watch the IFSC validate as you type. Bank details are what make the payment trail real.',
      to: 'login.html', toLabel: 'Now log in' },
    { page: 'login.html', title: 'Login by farmer ID + OTP',
      say: 'No passwords \u2014 farmers will not remember one, and an OTP is the pattern they already use for UPI. Press "Demo login" to walk straight in as KSN-4471, whose history is already populated.',
      to: 'dashboard.html', toLabel: 'Open the dashboard' },
    { page: 'dashboard.html', title: 'The farmer\u2019s home',
      say: 'Next visit with a countdown, the money trail for every lot, the rate watch, and the SMS they actually received. One tap raises a dispute if anything looks wrong.',
      to: 'book.html', toLabel: 'Book a slot' },
    { page: 'book.html', title: 'Booking with live occupancy',
      say: 'Pick the centre, the crop (rate shown next to it), the quantity \u2014 the indicative value calculates live. Then the slot grid: green is open, amber is filling, red is full. Pick an amber slot and it offers a quieter one. That nudge is the congestion control.',
      to: 'queue.html', toLabel: 'See the live queue' },
    { page: 'queue.html', title: 'Live queue + gate QR',
      say: 'Position, estimated wait, and the QR for the gate. The board moves on its own as the centre checks people in \u2014 and when their turn comes they get an SMS, so nobody has to stand and watch a screen.',
      to: 'admin-queue.html', toLabel: 'Switch to the centre' },
    { page: 'admin-queue.html', title: 'Centre side: the live board',
      say: 'Same data, operator\u2019s view. Scan the QR to check a farmer in, or press "Call next farmer" \u2014 that sends the "you are next" SMS. Two bays at the weighbridge at a time, and a no-show releases the slot to the waitlist.',
      to: 'admin-procure.html', toLabel: 'Record the weighment' },
    { page: 'admin-procure.html', title: 'Weighment slip',
      say: 'Enter the weighed quantity \u2014 19.6, say. The grade, moisture and the 1.2% deduction compute live into a net payable. Confirm, and the farmer gets an SMS with weight, rate and gross value before they leave the yard.',
      to: 'admin-payments.html', toLabel: 'Process the payment' },
    { page: 'admin-payments.html', title: 'Payment processing',
      say: 'Initiate the DBT file, then mark it credited with a UTR reference. Two clicks, and each one notifies the farmer. This is the step that used to cost them a repeat visit to ask "has my money come?".',
      to: 'payment.html', toLabel: 'Show the farmer the trail' },
    { page: 'payment.html', title: 'The trust layer',
      say: 'Back as the farmer: five stages from slot booked to amount credited, the exact quantity \u00d7 rate calculation with deductions itemised, and the bank reference. This single screen answers the complaint in the problem statement.',
      to: 'admin-prices.html', toLabel: 'Change a rate' },
    { page: 'admin-prices.html', title: 'Backend rate control',
      say: 'Click a rate, type a new number, press Enter. It publishes immediately, logs the revision in the audit trail, and SMSes every farmer who grows that crop. Open "History" for the trend chart.',
      to: 'admin-analytics.html', toLabel: 'Open analytics' },
    { page: 'admin-analytics.html', title: 'The ministry view',
      say: 'Farmers served, procurement value, average wait against a 60-minute target, payments stuck with the treasury, and where the delay actually is. This is the slide that answers "so what?".',
      to: 'admin-disputes.html', toLabel: 'Close with grievances' },
    { page: 'admin-disputes.html', title: 'Grievance desk',
      say: 'Anything the farmer flagged lands here with the lot record attached. Resolve it, correct the record if the weight was wrong, and the farmer is notified. Three-working-day clock, logged against their ID.',
      to: 'demo.html', toLabel: 'Back to the demo guide' }
  ];

  function tourState() {
    try { return JSON.parse(localStorage.getItem(TOUR_KEY) || 'null'); } catch (e) { return null; }
  }
  function tourSave(i) { try { localStorage.setItem(TOUR_KEY, JSON.stringify({ step: i })); } catch (e) {} }
  function tourStop() { try { localStorage.removeItem(TOUR_KEY); } catch (e) {} location.reload(); }

  function startDemo() {
    S = freshState();
    S.session = 'KSN-4471';
    S.staff = 'STAFF-MANDYA-01';
    save();
    tourSave(0);
    goto('index.html');
  }
  function demoLoginFarmer() {
    ensureDemo();
    S.session = 'KSN-4471'; save();
    goto('dashboard.html');
  }
  function demoLoginStaff() {
    ensureDemo();
    S.staff = 'STAFF-MANDYA-01'; save();
    goto('admin-queue.html');
  }
  function demoGoto(page) { goto(page); }
  function demoNext() {
    var t = tourState(); if (!t) return;
    var step = Math.min(TOUR.length - 1, t.step + 1);
    tourSave(step);
    goto(TOUR[step].page);
  }
  function demoPrev() {
    var t = tourState(); if (!t) return;
    var step = Math.max(0, t.step - 1);
    tourSave(step);
    goto(TOUR[step].page);
  }
  function demoJump(i) { tourSave(i); goto(TOUR[i].page); }

  /* Make sure the demo farmer and today's queue exist, even if the visitor
     has been clicking around and the data drifted. */
  function ensureDemo() {
    if (!farmer('KSN-4471')) { S = freshState(); save(); return; }
    var d = ymd(today());
    var todays = S.bookings.filter(function (b) { return b.date === d && b.center_id === 'C1'; });
    if (todays.length < 4) { S = freshState(); S.session = S.session; save(); }
  }

  function renderTour() {
    var t = tourState(); if (!t) return;
    var page = location.pathname.split('/').pop() || 'index.html';
    var idx = t.step;
    for (var i = 0; i < TOUR.length; i++) if (TOUR[i].page === page) idx = i;
    if (idx !== t.step) tourSave(idx);
    var s = TOUR[idx];
    var dots = TOUR.map(function (x, i) {
      return '<button type="button" class="tdot' + (i === idx ? ' on' : '') + (i < idx ? ' done' : '') + '" ' +
        'onclick="KS.demoJump(' + i + ')" title="' + esc(x.title) + '" aria-label="Step ' + (i + 1) + '"></button>';
    }).join('');
    var el = document.createElement('div');
    el.className = 'tour';
    el.innerHTML =
      '<div class="tour-head">' +
      '<span class="tour-step">Step ' + (idx + 1) + ' / ' + TOUR.length + '</span>' +
      '<button type="button" class="x" onclick="KS.tourStop()" title="End guided demo" aria-label="End guided demo">&times;</button>' +
      '</div>' +
      '<h4>' + esc(s.title) + '</h4>' +
      '<p>' + esc(s.say) + '</p>' +
      '<div class="tour-dots">' + dots + '</div>' +
      '<div class="tour-foot">' +
      '<button type="button" class="btn btn-ghost btn-sm" onclick="KS.demoPrev()"' + (idx === 0 ? ' disabled' : '') + '>← Back</button>' +
      (s.to ? '<button type="button" class="btn btn-sm" onclick="KS.demoGoto(\'' + s.to + '\')">' + esc(s.toLabel) + ' →</button>'
           : '<button type="button" class="btn btn-sm" onclick="KS.demoNext()">Next →</button>') +
      '</div>';
    document.body.appendChild(el);
  }

  /* ============================================================
     PAGE: index.html
     ============================================================ */
  function pageHome() {
    var el = $('#home-root');
    var best = S.crops.slice().sort(function (a, b) { return b.rate - a.rate; })[0];
    el.innerHTML =
      '<section class="hero"><div class="wrap">' +
      '<div>' +
      '<span class="eyebrow">Kharif 2026 · Rabi 2026–27 procurement season</span>' +
      '<h1 class="h-xl">Sell your harvest at the government rate — without the queue.</h1>' +
      '<p class="lede" style="margin-top:20px">Book a weighment slot at your nearest procurement centre, walk in at your allotted hour, and follow every rupee from the weighbridge to your bank account. One SMS for every step.</p>' +
      '<div class="cta-row">' +
      '<a class="btn btn-lg" href="register.html">Register as a farmer</a>' +
      '<a class="btn btn-lg btn-outline" href="rates.html">Check rates</a>' +
      '</div>' +
      '<div class="proof">' +
      '<div><b>' + S.crops.length + '</b><span>crops under MSP cover</span></div>' +
      '<div><b>' + S.centers.length + '</b><span>procurement centres live</span></div>' +
      '<div><b>72 hrs</b><span>typical payment credit</span></div>' +
      '<div><b>6</b><span>slots a day, per centre</span></div>' +
      '</div></div>' +
      '<div class="panel rate-card"><span class="stamp">Live board</span>' +
      '<div class="headline"><span class="eyebrow eyebrow-ink">Mandya APMC · today</span>' +
      '<h2>Today’s procurement rates</h2>' +
      '<div class="updated">Revised ' + fmtStamp(S.crops[0].updated_at) + ' by the State Procurement Cell</div></div>' +
      '<div style="padding:0 0 6px">' + rateTable({}) + '</div>' +
      '<div class="panel-foot" style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap">' +
      '<span class="small muted">Highest today: <b>' + esc(best.name) + '</b> at ' + inr(best.rate) + ' per ' + best.unit + '</span>' +
      '<a class="btn btn-ghost btn-sm" href="rates.html">All centres →</a></div>' +
      '</div></div></section>' +

      '<section class="section"><div class="wrap">' +
      '<div class="ornament"><span>How a sale now works</span></div>' +
      '<ol class="how" style="margin-top:34px">' +
      '<li><span class="n">i.</span><h3>Register once</h3><p>Aadhaar-linked farmer ID, land record and bank account. Verified by the taluk office, valid for every season after.</p></li>' +
      '<li><span class="n">ii.</span><h3>Book a slot</h3><p>Choose the centre, crop and quantity. The board shows how full each slot is and nudges you toward a lighter hour.</p></li>' +
      '<li><span class="n">iii.</span><h3>Walk in, weigh, leave</h3><p>Show the QR at the gate. Your turn is called by SMS, not by shouting from a platform.</p></li>' +
      '<li><span class="n">iv.</span><h3>Track the money</h3><p>Quantity × rate is shown as soon as the weighbridge prints. Then payment initiated, then credited — with a reference number.</p></li>' +
      '</ol></div></section>' +

      '<section class="section" style="background:var(--paper);border-top:1px solid var(--rule);border-bottom:1px solid var(--rule)"><div class="wrap split">' +
      '<div>' +
      '<span class="eyebrow">Built around the real complaint</span>' +
      '<h2 class="h-lg">Farmers do not mind the rate. They mind not knowing.</h2>' +
      '<p style="margin-top:18px;color:var(--ink-70)">Arriving at four in the morning for an eleven o’clock weighment. Not knowing whether the truck will be accepted today. Not knowing if the money has left the treasury. Every one of those is an information problem, and each one costs a full day of wages and a tractor trip.</p>' +
      '<p style="color:var(--ink-70)">Krishi Setu replaces all of it with a slot, a number, and a message. Nothing here asks a farmer to learn a new habit — the same SMS they already read now carries the queue position and the payment reference.</p>' +
      '<blockquote class="pull" style="margin-top:26px">“I used to lose two days to one load of paddy. Now I lose two hours, and I know on the same evening what I will be paid.”</blockquote>' +
      '<div class="attrib">— Ramesh Gowda, Bellur village, Mandya taluk · farmer ID KSN-4471</div>' +
      '</div>' +
      '<div class="stack">' +
      '<ul class="feat-list panel" style="padding:8px 22px">' +
      '<li><span class="ic">' + glyph('wheat').replace('class="glyph"', 'style="width:22px;height:22px"') + '</span><span><b>Slot load-balancing</b><p>Slots are released in proportion to each centre’s weighbridge capacity, and crowded hours are flagged before a farmer travels.</p></span></li>' +
      '<li><span class="ic">' + glyph('pod').replace('class="glyph"', 'style="width:22px;height:22px"') + '</span><span><b>Money trail, visible</b><p>A five-step timeline from slot booked to amount credited, with the UTR reference from the payment gateway.</p></span></li>' +
      '<li><span class="ic">' + glyph('grain').replace('class="glyph"', 'style="width:22px;height:22px"') + '</span><span><b>Works without a smartphone</b><p>Every alert is an SMS. Booking by IVR on 1800-425-7733 for those who prefer to speak to a person.</p></span></li>' +
      '<li><span class="ic">' + glyph('boll').replace('class="glyph"', 'style="width:22px;height:22px"') + '</span><span><b>Dispute in one tap</b><p>Disagree with the weighed quantity or the grade? Raise it from the receipt and it lands with the centre officer the same day.</p></span></li>' +
      '</ul>' +
      '<div class="callout"><span class="title">No-show protection</span>If a booked farmer does not check in within 30 minutes of the slot, the slot is released to the day’s waitlist automatically — the weighbridge never sits idle.</div>' +
      '</div></div></section>' +

      '<section class="section"><div class="wrap wrap-narrow center">' +
      '<span class="eyebrow">Ready when you are</span>' +
      '<h2 class="h-lg">Registration takes about four minutes.</h2>' +
      '<p class="lede" style="margin:16px auto 0">Keep your Aadhaar number, land survey number and bank passbook handy. An OTP will be sent to your registered mobile number.</p>' +
      '<div class="cta-row" style="justify-content:center">' +
      '<a class="btn btn-lg" href="register.html">Register now</a>' +
      '<a class="btn btn-lg btn-ghost" href="login.html">I already have a farmer ID</a></div>' +
      '<p class="small muted" style="margin-top:20px">Prefer to talk to someone? Call 1800-425-7733 between 6 a.m. and 9 p.m., every day of the season.</p>' +
      '</div></section>';
  }

  /* ============================================================
     PAGE: rates.html
     ============================================================ */
  function pageRates() {
    var el = $('#rates-root');
    var cards = S.centers.map(function (c) {
      var todays = S.bookings.filter(function (b) { return b.center_id === c.id && b.date === ymd(today()); });
      var load = Math.min(100, Math.round(todays.length / c.capacity * 100));
      return '<div class="panel"><div class="panel-head"><div>' +
        '<h3>' + esc(c.name) + '</h3>' +
        '<div class="small muted">' + esc(c.district) + ' district · capacity ' + c.capacity + ' vehicles/day · ' + esc(c.phone) + '</div>' +
        '</div><span class="pill ' + (load >= 85 ? 'pill-bad' : load >= 60 ? 'pill-warn' : 'pill-ok') + '">' + load + '% booked today</span></div>' +
        '<div class="panel-body" style="padding:0 0 8px">' + rateTable({ withCentre: false, withAction: true }) + '</div>' +
        '<div class="panel-foot small muted">Slots released for 09:00, 10:30, 12:00, 14:00, 15:30 and 17:00. Arrive 20 minutes early with Aadhaar and passbook.</div>' +
        '</div>';
    }).join('');
    el.innerHTML =
      '<div class="pagehead"><div class="wrap"><div>' +
      '<div class="crumb"><a href="index.html">Home</a> / Rates</div>' +
      '<h1>Today’s procurement rates</h1>' +
      '<p class="muted" style="margin-top:8px">Notified under the Minimum Support Price scheme for the current season. Rates apply at the weighbridge on the day of procurement.</p>' +
      '</div><div style="text-align:right"><div class="small muted">Board refreshed</div><div class="mono">' + fmtStamp(S.crops[0].updated_at) + '</div></div></div></div>' +
      '<div class="page"><div class="wrap stack">' + cards +
      '<div class="callout info"><span class="title">Do not travel without a slot</span>Unbooked arrivals are served only after all booked farmers, and only if weighbridge time remains. Booking is free and takes two minutes on a phone — or one call to 1800-425-7733.</div>' +
      '</div></div>';
  }

  /* ============================================================
     PAGE: register.html
     ============================================================ */
  var reg = { step: 1, data: {}, errors: {} };
  var REG_STEPS = ['Identity', 'Address', 'Land', 'Bank', 'Verify'];

  function regStepper() {
    return '<ol class="stepper">' + REG_STEPS.map(function (s, i) {
      var n = i + 1, cls = n < reg.step ? 'done' : n === reg.step ? 'now' : '';
      return '<li class="' + cls + '"><span class="dot">' + (n < reg.step ? '✓' : n) + '</span><span class="lbl">' + s + '</span><span class="bar"></span></li>';
    }).join('') + '</ol>';
  }

  function cropChips(sel) {
    return '<div class="chip-row">' + S.crops.map(function (c) {
      var on = sel.indexOf(c.id) >= 0;
      return '<button type="button" class="chip' + (on ? ' on' : '') + '" data-crop="' + c.id + '">' +
        esc(S.lang === 'hi' && c.hi ? c.hi : c.name) + '</button>';
    }).join('') + '</div>';
  }

  function pageRegister() {
    var el = $('#register-root');
    function render() {
      var d = reg.data;
      var inner = '';
      if (reg.step === 1) {
        inner =
          '<div class="field"><label for="r-name">Full name (as in Aadhaar)</label>' +
          '<input class="input" id="r-name" value="' + esc(d.name || '') + '" autocomplete="name" placeholder="e.g. Ramesh Gowda">' +
          '<div class="err" id="e-name">Please enter your full name.</div></div>' +
          '<div class="grid-2">' +
          '<div class="field"><label for="r-phone">Mobile number</label>' +
          '<input class="input mono" id="r-phone" inputmode="numeric" maxlength="10" value="' + esc(d.phone || '') + '" placeholder="10-digit number">' +
          '<div class="hint">All booking and payment alerts are sent here by SMS.</div>' +
          '<div class="err" id="e-phone">Enter a valid 10-digit mobile number.</div></div>' +
          '<div class="field"><label for="r-dob">Year of birth</label>' +
          '<input class="input mono" id="r-dob" inputmode="numeric" maxlength="4" value="' + esc(d.dob || '') + '" placeholder="e.g. 1978">' +
          '<div class="err" id="e-dob">Enter a four-digit year.</div></div></div>' +
          '<div class="field"><label for="r-aadhaar">Aadhaar number</label>' +
          '<input class="input mono" id="r-aadhaar" inputmode="numeric" maxlength="12" value="' + esc(d.aadhaar || '') + '" placeholder="XXXX XXXX XXXX">' +
          '<div class="hint">Used only to link your land record. Stored encrypted; the farmer ID you receive is not your Aadhaar.</div>' +
          '<div class="err" id="e-aadhaar">Aadhaar must be 12 digits.</div></div>';
      } else if (reg.step === 2) {
        inner =
          '<div class="field"><label for="r-village">Village</label>' +
          '<input class="input" id="r-village" value="' + esc(d.village || '') + '" placeholder="e.g. Bellur"></div>' +
          '<div class="grid-2">' +
          '<div class="field"><label for="r-district">Taluk / district</label>' +
          '<select class="select" id="r-district">' + ['Mandya', 'Mysuru', 'Hassan', 'Chamarajanagar', 'Ramanagara']
            .map(function (x) { return '<option' + (d.district === x ? ' selected' : '') + '>' + x + '</option>'; }).join('') + '</select></div>' +
          '<div class="field"><label for="r-state">State</label>' +
          '<input class="input" id="r-state" value="' + esc(d.state || 'Karnataka') + '"></div></div>' +
          '<div class="field"><label for="r-nearest">Nearest procurement centre</label>' +
          '<select class="select" id="r-nearest">' + S.centers.map(function (c) {
            return '<option value="' + c.id + '"' + (d.center_id === c.id ? ' selected' : '') + '>' + esc(c.name) + '</option>';
          }).join('') + '</select><div class="hint">You can book any centre later; this only sets your default.</div></div>' +
          '<div class="callout info"><span class="title">Why we ask</span>Your village decides which centre’s rate board and waitlist you join first. Nothing here is shared outside the department.</div>';
      } else if (reg.step === 3) {
        inner =
          '<div class="grid-2">' +
          '<div class="field"><label for="r-area">Total land holding (acres)</label>' +
          '<input class="input mono" id="r-area" inputmode="decimal" value="' + esc(d.land_area || '') + '" placeholder="e.g. 4.2">' +
          '<div class="err" id="e-area">Enter land area in acres.</div></div>' +
          '<div class="field"><label for="r-type">Holding type</label>' +
          '<select class="select" id="r-type">' + ['owned', 'leased', 'family-shared']
            .map(function (x) { return '<option value="' + x + '"' + (d.land_type === x ? ' selected' : '') + '>' + x + '</option>'; }).join('') + '</select></div></div>' +
          '<div class="grid-2">' +
          '<div class="field"><label for="r-survey">Survey / khasra number</label>' +
          '<input class="input mono" id="r-survey" value="' + esc(d.survey || '') + '" placeholder="e.g. 118/2B">' +
          '<div class="hint">Optional, but speeds up verification at the taluk office.</div></div>' +
          '<div class="field"><label for="r-irrigated">Irrigated area (acres)</label>' +
          '<input class="input mono" id="r-irrigated" inputmode="decimal" value="' + esc(d.irrigated || '') + '" placeholder="e.g. 2.0"></div></div>' +
          '<div class="field"><label>Crops you grow</label>' + cropChips(d.crops || []) +
          '<div class="err" id="e-crops">Select at least one crop.</div>' +
          '<div class="hint">Used to alert you when the rate for your crop is revised.</div></div>';
      } else if (reg.step === 4) {
        inner =
          '<div class="field"><label for="r-holder">Account holder name</label>' +
          '<input class="input" id="r-holder" value="' + esc(d.holder || d.name || '') + '" placeholder="As printed on the passbook">' +
          '<div class="err" id="e-holder">Account holder name is required.</div></div>' +
          '<div class="grid-2">' +
          '<div class="field"><label for="r-acc">Bank account number</label>' +
          '<input class="input mono" id="r-acc" inputmode="numeric" maxlength="18" value="' + esc(d.acc || '') + '" placeholder="9–18 digits">' +
          '<div class="valid-mark" id="v-acc">✓ Looks like a valid account number</div>' +
          '<div class="err" id="e-acc">Account number must be 9–18 digits.</div></div>' +
          '<div class="field"><label for="r-ifsc">IFSC code</label>' +
          '<input class="input mono" id="r-ifsc" maxlength="11" value="' + esc(d.ifsc || '') + '" placeholder="e.g. HDFC0001234" style="text-transform:uppercase">' +
          '<div class="valid-mark" id="v-ifsc">✓ IFSC format accepted</div>' +
          '<div class="err" id="e-ifsc">IFSC must look like ABCD0123456.</div></div></div>' +
          '<div class="grid-2"><div class="field"><label for="r-bank">Bank</label>' +
          '<input class="input" id="r-bank" value="' + esc(d.bank || '') + '" placeholder="e.g. HDFC Bank"></div>' +
          '<div class="field"><label for="r-branch">Branch</label>' +
          '<input class="input" id="r-branch" value="' + esc(d.branch || '') + '" placeholder="e.g. Mandya Main"></div></div>' +
          '<div class="callout"><span class="title">How payment reaches you</span>Amounts are credited by Direct Benefit Transfer to this account, usually within 72 hours of weighment. In production this form is verified by an NPCI penny-drop check before it is accepted; in this prototype the format is validated on the device.</div>';
      } else {
        inner =
          '<p class="muted">We have sent a 6-digit code by SMS to <b class="mono">+91 ' + esc(d.phone) + '</b>. Enter it below to complete registration.</p>' +
          '<div class="field" style="margin-top:18px"><label for="r-otp">One-time password</label>' +
          '<input class="input mono" id="r-otp" inputmode="numeric" maxlength="6" style="font-size:24px;letter-spacing:.35em;text-align:center" placeholder="······" value="' + esc(d.otp || '') + '">' +
          '<div class="hint">Demo code for this prototype: <b class="mono">' + esc(S.last_otp || '482913') + '</b></div>' +
          '<div class="err" id="e-otp">That code does not match. Please try again.</div></div>' +
          '<div class="panel" style="background:#FCFAF4"><div class="panel-body"><h3 class="h-sm" style="margin-bottom:14px">Please confirm your details</h3>' +
          summaryDl() + '</div></div>' +
          '<div class="callout info" style="margin-top:18px"><span class="title">What happens next</span>Your farmer ID is generated immediately and sent by SMS. Land-record verification is completed by the taluk office within three working days; you can book slots in the meantime.</div>';
      }

      el.innerHTML =
        '<div class="pagehead"><div class="wrap"><div>' +
        '<div class="crumb"><a href="index.html">Home</a> / Register</div>' +
        '<h1>Farmer registration</h1>' +
        '<p class="muted" style="margin-top:8px">One registration covers every season and every centre in the state.</p>' +
        '</div><div style="text-align:right" class="small muted">Already registered?<br><a href="login.html">Login with your farmer ID →</a></div></div></div>' +
        '<div class="page"><div class="wrap wrap-tight">' + regStepper() +
        '<form class="panel" id="reg-form" novalidate><div class="panel-body">' + inner + '</div>' +
        '<div class="panel-foot" style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">' +
        (reg.step > 1 ? '<button type="button" class="btn btn-ghost" onclick="KS.regBack()">← Back</button>' : '<a class="btn btn-ghost" href="index.html">Cancel</a>') +
        '<button type="submit" class="btn">' + (reg.step === 5 ? 'Complete registration' : 'Continue →') + '</button>' +
        '</div></form>' +
        '<p class="small muted center" style="margin-top:18px">Need help? Call 1800-425-7733 or visit any taluk office with your Aadhaar.</p>' +
        '</div></div>';
      bindRegister();
    }

    /* Keep whatever the farmer has typed so a re-render (e.g. toggling a crop
       chip) never clears a half-filled step. */
    function persist() { collect(); }

    function summaryDl() {
      var d = reg.data;
      var cropsTxt = (d.crops || []).map(cropName).join(', ') || '—';
      return '<dl class="kv">' +
        '<dt>Name</dt><dd>' + esc(d.name) + '</dd>' +
        '<dt>Mobile</dt><dd class="mono">+91 ' + esc(d.phone) + '</dd>' +
        '<dt>Aadhaar</dt><dd class="mono">•••• •••• ' + esc(String(d.aadhaar || '').slice(-4)) + '</dd>' +
        '<dt>Village</dt><dd>' + esc(d.village) + ', ' + esc(d.district) + '</dd>' +
        '<dt>Land</dt><dd>' + esc(d.land_area) + ' acres · ' + esc(d.land_type) + (d.survey ? ' · survey ' + esc(d.survey) : '') + '</dd>' +
        '<dt>Crops</dt><dd>' + esc(cropsTxt) + '</dd>' +
        '<dt>Bank</dt><dd>' + esc(d.bank || '') + ' · A/C <span class="mono">••••' + esc(String(d.acc || '').slice(-4)) + '</span> · ' + esc((d.ifsc || '').toUpperCase()) + '</dd>' +
        '</dl>';
    }

    function showErr(id, on) {
      var e = $('#e-' + id); if (e) e.classList.toggle('show', !!on);
      var f = $('#r-' + id); if (f && f.setAttribute) f.setAttribute('aria-invalid', on ? 'true' : 'false');
    }

    function bindRegister() {
      $$('[data-crop]').forEach(function (b) {
        b.addEventListener('click', function () {
          persist();
          var list = reg.data.crops || (reg.data.crops = []);
          var id = b.getAttribute('data-crop'), i = list.indexOf(id);
          if (i >= 0) list.splice(i, 1); else list.push(id);
          render();
        });
      });
      var acc = $('#r-acc'), ifsc = $('#r-ifsc');
      if (acc) acc.addEventListener('input', function () {
        $('#v-acc').classList.toggle('show', /^\d{9,18}$/.test(acc.value.trim()));
      });
      if (ifsc) ifsc.addEventListener('input', function () {
        var ok = /^[A-Za-z]{4}0[A-Za-z0-9]{6}$/.test(ifsc.value.trim());
        $('#v-ifsc').classList.toggle('show', ok);
      });
      var f = $('#reg-form');
      if (f) f.addEventListener('submit', function (e) { e.preventDefault(); regNext(); });
    }

    function collect() {
      var d = reg.data, g = function (id) { var e = $('#r-' + id); return e ? e.value.trim() : ''; };
      if (reg.step === 1) { d.name = g('name'); d.phone = g('phone'); d.dob = g('dob'); d.aadhaar = g('aadhaar'); }
      if (reg.step === 2) { d.village = g('village'); d.district = g('district'); d.state = g('state'); d.center_id = g('nearest'); }
      if (reg.step === 3) { d.land_area = g('area'); d.land_type = g('type'); d.survey = g('survey'); d.irrigated = g('irrigated'); }
      if (reg.step === 4) {
        d.holder = g('holder'); d.acc = g('acc'); d.ifsc = g('ifsc').toUpperCase(); d.bank = g('bank'); d.branch = g('branch');
      }
      if (reg.step === 5) { d.otp = g('otp'); }
      return d;
    }

    function regNext() {
      var d = collect(), ok = true;
      function need(cond, key) { if (!cond) { showErr(key, true); ok = false; } else showErr(key, false); }
      if (reg.step === 1) {
        need(d.name.length > 2, 'name');
        need(/^\d{10}$/.test(d.phone), 'phone');
        need(/^(19|20)\d{2}$/.test(d.dob), 'dob');
        need(/^\d{12}$/.test(d.aadhaar), 'aadhaar');
        if (!ok) return;
        if (farmerByIdPhone(d.phone)) { toast('Number already registered', 'That mobile number is linked to farmer ID KSN-4471. Please login instead.', 'red'); }
      }
      if (reg.step === 2) need(d.village.length > 1, 'village');
      if (reg.step === 3) {
        need(/^\d+(\.\d+)?$/.test(d.land_area) && +d.land_area > 0, 'area');
        need((d.crops || []).length > 0, 'crops');
      }
      if (reg.step === 4) {
        need(d.holder.length > 2, 'holder');
        need(/^\d{9,18}$/.test(d.acc), 'acc');
        need(/^[A-Z]{4}0[A-Z0-9]{6}$/.test(d.ifsc), 'ifsc');
      }
      if (reg.step === 5) {
        need(d.otp === (S.last_otp || '482913'), 'otp');
        if (!ok) return;
        return finish();
      }
      if (!ok) return;
      reg.step++;
      if (reg.step === 5) {
        S.last_otp = String(Math.floor(100000 + Math.random() * 899999));
        save();
        toast('OTP sent to ' + d.phone, 'Demo code ' + S.last_otp + ' — in production this arrives by SMS within seconds.', 'gold');
      }
      render();
      window.scrollTo(0, 0);
    }

    function farmerByIdPhone(phone) {
      for (var i = 0; i < S.farmers.length; i++) if (S.farmers[i].phone === phone) return S.farmers[i];
      return null;
    }

    function finish() {
      var d = reg.data;
      var id = 'KSN-' + (4478 + S.farmers.length - 7);
      var f = {
        id: id, phone: d.phone, name: d.name, village: d.village, district: d.district, state: d.state,
        land_area: +d.land_area, land_type: d.land_type, survey: d.survey, crops: d.crops || [],
        bank: { acc: d.acc, ifsc: d.ifsc, holder: d.holder },         created_at: new Date().toISOString()
      };
      S.farmers.push(f);
      S.session = f.id;
      save();
      sms(f.phone, 'Registration complete',
        'KRISHI SETU: Welcome ' + f.name.toUpperCase() + '. Your Farmer ID is ' + f.id + '. Keep it safe — you will use it to login and at the centre gate. Helpline 1800-425-7733. - KISANSETU', 'green');
      goto('welcome.html?id=' + encodeURIComponent(f.id));
    }

    render();
    window.PAGE_REFRESH = render;
  }

  function regBack() { if (reg.step > 1) { reg.step--; window.PAGE_REFRESH && window.PAGE_REFRESH(); window.scrollTo(0, 0); } }

  /* ============================================================
     PAGE: welcome.html
     ============================================================ */
  function pageWelcome() {
    var id = new URLSearchParams(location.search).get('id');
    var f = farmer(id) || me();
    var el = $('#welcome-root');
    if (!f) { goto('register.html'); return; }
    el.innerHTML =
      '<div class="pagehead"><div class="wrap"><div>' +
      '<div class="crumb">Registration complete</div><h1>Welcome, ' + esc(f.name.split(' ')[0]) + '</h1>' +
      '<p class="muted" style="margin-top:8px">Your farmer ID has been sent by SMS to <span class="mono">+91 ' + esc(f.phone) + '</span>.</p>' +
      '</div></div></div>' +
      '<div class="page"><div class="wrap wrap-narrow stack">' +
      '<div class="panel"><div class="panel-body center" style="padding:40px 28px">' +
      '<span class="eyebrow">Your farmer ID</span>' +
      '<div class="mono" style="font-size:42px;letter-spacing:.06em;color:var(--green-900)">' + esc(f.id) + '</div>' +
      '<p class="muted" style="margin-top:12px">Use this ID to login on any phone, and quote it at the centre gate. It is not your Aadhaar number.</p>' +
      '<div class="cta-row" style="justify-content:center;margin-top:22px">' +
      '<a class="btn btn-lg" href="book.html">Book my first slot</a>' +
      '<a class="btn btn-lg btn-ghost" href="dashboard.html">Go to dashboard</a></div>' +
      '</div></div>' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">What we sent you</h3></div>' +
      '<div class="panel-body stack-sm">' + smsCard(notesFor(f.id)[0]) + '</div></div>' +
      '<div class="callout"><span class="title">Next steps</span>' +
      '1. Land-record verification completes at the taluk office within three working days — you can book in the meantime. ' +
      '2. Add a second contact number in Profile if someone else in the family reads your SMS. ' +
      '3. Booking is free; there is no agent or commission involved.</div>' +
      '</div></div>';
  }

  function smsCard(n) {
    if (!n) return '<div class="empty"><b>No messages yet</b>SMS alerts appear here the moment something happens to your booking or payment.</div>';
    return '<div class="sms ' + (n.kind || '') + '"><div class="meta"><span>' + esc(n.title) + '</span><span class="mono">' + fmtStamp(n.at) + '</span></div>' +
      '<div class="body">' + esc(n.body) + '</div></div>';
  }

  /* ============================================================
     PAGE: login.html
     ============================================================ */
  var login = { stage: 'id' };
  function pageLogin() {
    var el = $('#login-root');
    function render() {
      var inner;
      if (login.stage === 'id') {
        inner =
          '<div class="field"><label for="l-id">Farmer ID</label>' +
          '<input class="input mono" id="l-id" placeholder="e.g. KSN-4471" style="font-size:19px;text-transform:uppercase" value="KSN-4471">' +
          '<div class="hint">Find it on the SMS you received at registration.</div>' +
          '<div class="err" id="e-lid">We could not find that farmer ID.</div></div>' +
          '<button type="submit" class="btn btn-block btn-lg">Send OTP →</button>' +
          '<div class="divider-dots" style="margin:22px 0">or</div>' +
          '<a class="btn btn-ghost btn-block" href="register.html">Register as a new farmer</a>' +
          '<button type="button" class="btn btn-gold btn-block" style="margin-top:10px" onclick="KS.demoLoginFarmer()">Demo login as KSN-4471 →</button>' +
          '<div class="callout" style="margin-top:20px"><span class="title">Demo login</span>Farmer ID <b class="mono">KSN-4471</b> · the OTP is shown on screen after you press “Send OTP”. Real deployment sends it by SMS and accepts an IVR call fallback on 1800-425-7733.</div>';
      } else {
        inner =
          '<p class="muted">Enter the 6-digit code sent to <b class="mono">+91 ' + esc(login.phone) + '</b>.</p>' +
          '<div class="field" style="margin-top:16px"><label for="l-otp">One-time password</label>' +
          '<input class="input mono" id="l-otp" inputmode="numeric" maxlength="6" placeholder="······" style="font-size:24px;letter-spacing:.35em;text-align:center">' +
          '<div class="hint">Demo code: <b class="mono">' + esc(login.otp) + '</b> · expires in 5 minutes</div>' +
          '<div class="err" id="e-lotp">Incorrect code. Please try again.</div></div>' +
          '<button type="submit" class="btn btn-block btn-lg">Login</button>' +
          '<button type="button" class="btn-link" style="margin-top:14px;width:100%" onclick="KS.loginBack()">← Use a different farmer ID</button>';
      }
      el.innerHTML =
        '<div class="page" style="padding-top:56px"><div class="wrap wrap-tight">' +
        '<div class="center" style="margin-bottom:26px"><div class="ornament"><span>Farmer login</span></div></div>' +
        '<form class="panel" id="login-form" novalidate><div class="panel-body">' + inner + '</div></form>' +
        '<p class="small muted center" style="margin-top:20px">Trouble logging in? Call 1800-425-7733 with your Aadhaar number handy.</p>' +
        '</div></div>';
      var f = $('#login-form');
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        if (login.stage === 'id') {
          var v = $('#l-id').value.trim().toUpperCase();
          var found = farmer(v);
          if (!found) { $('#e-lid').classList.add('show'); $('#l-id').setAttribute('aria-invalid', 'true'); return; }
          login.fid = found.id; login.phone = found.phone;
          login.otp = String(Math.floor(100000 + Math.random() * 899999));
          S.last_otp = login.otp; save();
          login.stage = 'otp'; render();
          toast('OTP sent', 'Code ' + login.otp + ' sent by SMS to +91 ' + login.phone, 'gold');
          setTimeout(function () { var i = $('#l-otp'); if (i) i.focus(); }, 60);
        } else {
          var code = $('#l-otp').value.trim();
          if (code !== login.otp) { $('#e-lotp').classList.add('show'); return; }
          S.session = login.fid; save();
          goto('dashboard.html');
        }
      });
      var i = $('#l-id') || $('#l-otp'); if (i) i.focus();
    }
    render();
  }
  function loginBack() { login.stage = 'id'; pageLogin(); }
  function logout() { S.session = null; save(); goto('index.html'); }

  /* ============================================================
     PAGE: dashboard.html
     ============================================================ */
  function pageDashboard() {
    if (!requireFarmer()) return;
    var f = me(), el = $('#dash-root');
    var mine = S.bookings.filter(function (b) { return b.farmer_id === f.id; })
      .sort(function (a, b) { return (b.date + b.slot).localeCompare(a.date + a.slot); });
    var upcoming = mine.filter(function (b) { return b.status === 'confirmed' || b.status === 'checked_in'; })[0];
    var inMoney = mine.filter(function (b) { return b.stage && STAGE_INDEX[b.stage] >= 2; });
    var pending = inMoney.filter(function (b) { return b.status !== 'payment_completed'; });
    var paidTotal = mine.filter(function (b) { return b.status === 'payment_completed'; })
      .reduce(function (s, b) { return s + (b.amount || 0); }, 0);
    var notes = notesFor(f.id).slice(0, 3);

    el.innerHTML =
      '<div class="pagehead"><div class="wrap"><div>' +
      '<div class="crumb">Namaskara, <a href="profile.html">' + esc(f.name) + '</a></div>' +
      '<h1>Your account at a glance</h1>' +
      '<p class="muted" style="margin-top:8px">Farmer ID <span class="mono">' + esc(f.id) + '</span> · ' + esc(f.village) + ', ' + esc(f.district) + ' · ' + f.land_area + ' acres</p>' +
      '</div><div><a class="btn" href="book.html">Book a slot</a></div></div></div>' +

      '<div class="page"><div class="wrap layout-2">' +
      '<div class="stack">' +
      '<div class="stats" style="grid-template-columns:repeat(3,1fr)">' +
      '<div class="stat"><div class="k">Upcoming slots</div><div class="v">' + mine.filter(function (b) { return b.status === 'confirmed'; }).length + '</div><div class="d">next: ' + (upcoming ? fmtDate(upcoming.date) : '—') + '</div></div>' +
      '<div class="stat"><div class="k">Payments in progress</div><div class="v">' + pending.length + '</div><div class="d">' + (pending.length ? inr(pending.reduce(function (s, b) { return s + (b.amount || 0); }, 0)) + ' due' : 'nothing pending') + '</div></div>' +
      '<div class="stat"><div class="k">Paid this season</div><div class="v">' + inr(paidTotal) + '</div><div class="d up">' + mine.filter(function (b) { return b.status === 'payment_completed'; }).length + ' lots settled</div></div>' +
      '</div>' +

      (upcoming ?
        '<div class="panel"><span class="stamp" style="position:static"></span><div class="panel-head">' +
        '<div><span class="eyebrow eyebrow-ink" style="margin-bottom:6px">Next visit</span><h2 class="h-md">' + esc(center(upcoming.center_id).name) + '</h2>' +
        '<div class="when" style="font-family:var(--mono);font-size:13px;color:var(--ink-50);margin-top:4px">' + fmtDate(upcoming.date) + ' · ' + upcoming.slot + ' hrs</div></div>' +
        statusPill(upcoming) + '</div>' +
        '<div class="panel-body"><dl class="kv">' +
        '<dt>Crop</dt><dd>' + esc(cropName(upcoming.crop_id)) + '</dd>' +
        '<dt>Declared qty</dt><dd class="mono">' + upcoming.est_qty + ' ' + esc(crop(upcoming.crop_id).unit) + '</dd>' +
        '<dt>Booking ref</dt><dd class="mono">' + esc(upcoming.id) + '</dd>' +
        '<dt>Carry</dt><dd>Aadhaar, bank passbook, vehicle papers</dd></dl>' +
        '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:20px">' +
        '<a class="btn" href="queue.html?id=' + upcoming.id + '">Live queue &amp; QR</a>' +
        '<a class="btn btn-ghost" href="bookings.html">All bookings</a>' +
        '<button class="btn btn-ghost" type="button" onclick="KS.cancelBooking(\'' + upcoming.id + '\')">Cancel slot</button>' +
        '</div></div>' +
        '<div class="panel-foot small muted">Slot hold expires 30 minutes after the start time. If you cannot come, cancel — the slot goes to a waiting farmer.</div></div>'
        :
        '<div class="panel"><div class="empty">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="3" y="5" width="18" height="16" rx="1.5"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>' +
        '<b>No upcoming slot</b>Book a weighment slot to see the live queue and receive turn alerts.' +
        '<div style="margin-top:16px"><a class="btn" href="book.html">Book a slot</a></div></div></div>') +

      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Money trail</h3><a class="small" href="payments.html">See all →</a></div>' +
      '<div class="panel-body" style="padding:0">' + (inMoney.length ? inMoney.slice(0, 3).map(function (b) {
        var idx = STAGE_INDEX[b.stage] || 0, pct = Math.round((idx + 1) / STAGES.length * 100);
        return '<a href="payment.html?id=' + b.id + '" style="display:block;padding:16px 22px;border-bottom:1px solid var(--rule-soft);text-decoration:none;color:inherit">' +
          '<div style="display:flex;justify-content:space-between;gap:14px;align-items:baseline;flex-wrap:wrap">' +
          '<span style="font-weight:600">' + esc(b.id) + ' · ' + esc(cropName(b.crop_id)) + ' <span class="muted small">(' + (b.actual_qty || b.est_qty) + ' ' + esc(crop(b.crop_id).unit) + ')</span></span>' +
          '<span class="mono" style="font-weight:600">' + inr(b.amount || 0) + '</span></div>' +
          '<div class="meter" style="margin-top:9px"><i style="width:' + pct + '%"></i></div>' +
          '<div class="small muted" style="margin-top:7px;display:flex;justify-content:space-between;gap:10px">' +
          '<span>' + esc(STAGES[idx][S.lang === 'hi' ? 'hi' : 'label']) + '</span><span>' + fmtDate(b.date) + '</span></div></a>';
      }).join('') : '<div class="empty"><b>Nothing weighed yet</b>Once the weighbridge records your lot, its payment trail appears here.</div>') +
      '</div></div>' +

      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Recent SMS alerts</h3><a class="small" href="notifications.html">All alerts →</a></div>' +
      '<div class="panel-body stack-sm">' + (notes.length ? notes.map(smsCard).join('') : '<div class="empty"><b>No alerts yet</b></div>') + '</div></div>' +
      '</div>' +

      '<aside class="stack">' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Rate watch</h3><a class="small" href="rates.html">Board →</a></div>' +
      '<div class="panel-body" style="padding:0 0 6px">' + rateTable({}) + '</div></div>' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Your crops</h3></div><div class="panel-body">' +
      '<div class="chip-row">' + (f.crops || []).map(function (c) { return '<span class="chip on" style="cursor:default">' + esc(cropName(c)) + '</span>'; }).join('') + '</div>' +
      '<p class="small muted" style="margin-top:14px">We alert you when the rate for these crops is revised.</p></div></div>' +
      '<div class="callout green"><span class="title">Help without a smartphone</span>Everything on this page can be done by calling 1800-425-7733. An operator books the slot and reads out the reference number.</div>' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Need a correction?</h3></div><div class="panel-body">' +
      '<p class="small muted" style="margin-bottom:14px">Wrong weighment, wrong grade or a payment that has not landed? Raise it and the centre officer gets it the same day.</p>' +
      '<button class="btn btn-ghost btn-block" type="button" onclick="KS.openDisputeModal()">Raise a dispute</button></div></div>' +
      '</aside></div></div>';
  }

  /* ============================================================
     PAGE: book.html
     ============================================================ */
  var bk = { step: 1, center_id: null, crop_id: null, qty: '', date: null, slot: null };
  function pageBook() {
    if (!requireFarmer()) return;
    var el = $('#book-root');
    var q = new URLSearchParams(location.search);
    if (q.get('crop')) bk.crop_id = q.get('crop');
    if (!bk.center_id) { var f = me(); bk.center_id = (f && f.district === 'Mysuru') ? 'C2' : 'C1'; }
    if (!bk.date) bk.date = ymd(addDays(today(), 1));
    var STEPS = ['Centre', 'Crop', 'Quantity', 'Date &amp; time', 'Confirm'];

    function render() {
      var inner = '';
      if (bk.step === 1) {
        inner = '<div class="choice-list">' + S.centers.map(function (c) {
          var todays = S.bookings.filter(function (b) { return b.center_id === c.id && b.date === bk.date; }).length;
          return '<label class="choice' + (bk.center_id === c.id ? ' sel' : '') + '">' +
            '<input type="radio" name="c" value="' + c.id + '"' + (bk.center_id === c.id ? ' checked' : '') + '>' +
            '<span><b>' + esc(c.name) + '</b><span>' + esc(c.district) + ' · capacity ' + c.capacity + '/day · ' +
            todays + ' bookings on ' + fmtDate(bk.date).toLowerCase() + ' · ' + esc(c.phone) + '</span></span></label>';
        }).join('') + '</div>' +
          '<div class="callout" style="margin-top:18px"><span class="title">Choosing for you</span>The board below marks slots green when fewer than 70% of the weighbridge slots for that hour are taken, amber when they are filling, and red when full. A crowded hour is also a long wait for grading and payment counters.</div>';
      } else if (bk.step === 2) {
        inner = '<div class="choice-list">' + S.crops.filter(function (c) { return c.active; }).map(function (c) {
          return '<label class="choice' + (bk.crop_id === c.id ? ' sel' : '') + '">' +
            '<input type="radio" name="p" value="' + c.id + '"' + (bk.crop_id === c.id ? ' checked' : '') + '>' +
            '<span style="color:var(--green-700);flex:none;margin-top:2px">' + glyph(c.glyph) + '</span>' +
            '<span style="flex:1"><b>' + esc(cropName(c.id)) + '</b><span>Notified rate today</span></span>' +
            '<span class="right" style="margin-left:auto"><b class="mono" style="font-size:16px">' + inr(c.rate) + '</b>' +
            '<span style="display:block;font-size:11.5px;color:var(--ink-50)">per ' + c.unit + '</span></span></label>';
        }).join('') + '</div>' +
          '<div class="callout info" style="margin-top:18px"><span class="title">Rate lock</span>The rate shown here is indicative. Your lot is paid at the rate in force on the day of weighment, and the exact figure is printed on your receipt before you leave the centre.</div>';
      } else if (bk.step === 3) {
        var c = crop(bk.crop_id);
        inner =
          '<div class="grid-2"><div class="field"><label for="b-qty">Declared quantity (' + c.unit + 's)</label>' +
          '<input class="input mono" id="b-qty" inputmode="decimal" value="' + esc(bk.qty) + '" placeholder="e.g. 18" style="font-size:20px">' +
          '<div class="err" id="e-qty">Enter the quantity you plan to bring.</div>' +
          '<div class="hint">The final weighed quantity may differ; payment is on the weighed figure.</div></div>' +
          '<div class="field"><label for="b-veh">Vehicle</label>' +
          '<select class="select" id="b-veh">' + ['Tractor + trailer', 'Mini truck', 'Bullock cart', 'Hired lorry', 'Other']
            .map(function (v) { return '<option' + (bk.vehicle === v ? ' selected' : '') + '>' + v + '</option>'; }).join('') + '</select>' +
          '<div class="hint">Helps the centre plan the weighbridge yard.</div></div></div>' +
          '<div class="field"><label for="b-grade">Expected grade (optional)</label>' +
          '<select class="select" id="b-grade">' + ['', 'A — clean, low moisture', 'B — average', 'C — needs drying']
            .map(function (v, i) { return '<option value="' + ['', 'A', 'B', 'C'][i] + '"' + (bk.grade === ['', 'A', 'B', 'C'][i] && bk.grade ? ' selected' : '') + '>' + (v || 'Not sure yet') + '</option>'; }).join('') + '</select></div>' +
          '<div class="panel" style="background:#FCFAF4"><div class="panel-body">' +
          '<div class="small muted">Indicative value at today’s rate</div>' +
          '<div class="mono" id="est-amt" style="font-size:30px;color:var(--green-900)">' + inr((+bk.qty || 0) * c.rate) + '</div>' +
          '<div class="small muted">' + (bk.qty || 0) + ' ' + c.unit + ' × ' + inr(c.rate) + ' · deductions for moisture and foreign matter are shown on the weighbridge slip.</div>' +
          '</div></div>';
      } else if (bk.step === 4) {
        var days = [];
        for (var i = 1; i <= 8; i++) days.push(ymd(addDays(today(), i)));
        var cap = Math.round(center(bk.center_id).capacity / S.slots.length) + 2;
        inner =
          '<div class="field"><label>Pick a day</label><div class="datestrip">' + days.map(function (d) {
            var dd = parseYmd(d), full = S.bookings.filter(function (b) { return b.center_id === bk.center_id && b.date === d && b.status !== 'cancelled'; }).length;
            return '<button type="button" class="datebtn' + (bk.date === d ? ' sel' : '') + '" data-date="' + d + '">' +
              '<b>' + dd.getDate() + '</b><span>' + dd.toLocaleDateString('en-IN', { weekday: 'short' }) + '</span>' +
              '<span style="display:block;font-size:10px;margin-top:3px">' + full + '/' + center(bk.center_id).capacity + '</span></button>';
          }).join('') + '</div></div>' +
          '<div class="field"><label>Available slots on ' + esc(fmtDate(bk.date)) + ' · capacity ' + cap + ' per slot</label>' +
          '<div class="slot-grid">' + S.slots.map(function (sl) {
            var o = occupancy(bk.center_id, bk.date, sl);
            return '<button type="button" class="slot ' + slotClass(o.pct) + (bk.slot === sl ? ' sel' : '') + '" data-slot="' + sl + '"' +
              (o.pct >= 100 ? ' disabled' : '') + '><b>' + sl + '</b><span>' + slotLabel(o.pct) + ' · ' + o.taken + '/' + o.cap + '</span></button>';
          }).join('') + '</div></div>' +
          '<div id="suggest"></div>' +
          '<div class="callout info"><span class="title">Why this matters</span>Every slot is a fixed weighbridge hour. Spreading arrivals across the day is what keeps the wait under an hour — which is why the board shows you the load before you commit.</div>';
      } else {
        var c2 = crop(bk.crop_id), ctr = center(bk.center_id);
        inner =
          '<dl class="kv" style="margin-bottom:20px">' +
          '<dt>Farmer</dt><dd>' + esc(me().name) + ' <span class="mono muted">' + esc(me().id) + '</span></dd>' +
          '<dt>Centre</dt><dd>' + esc(ctr.name) + '</dd>' +
          '<dt>Crop</dt><dd>' + esc(cropName(bk.crop_id)) + '</dd>' +
          '<dt>Quantity</dt><dd class="mono">' + esc(bk.qty) + ' ' + esc(c2.unit) + (bk.vehicle ? ' · ' + esc(bk.vehicle) : '') + '</dd>' +
          '<dt>Date &amp; time</dt><dd>' + esc(fmtDate(bk.date)) + ', ' + esc(bk.slot) + ' hrs</dd>' +
          '<dt>Indicative value</dt><dd class="mono">' + inr((+bk.qty) * c2.rate) + '</dd>' +
          '<dt>Alerts to</dt><dd class="mono">+91 ' + esc(me().phone) + '</dd></dl>' +
          '<div class="callout green"><span class="title">On confirmation you will receive</span>' +
          'An SMS with the booking reference and a QR code for gate check-in, a reminder the previous evening, and a “you are next” message when the operator calls your number at the centre.</div>' +
          '<div class="callout" style="margin-top:12px"><span class="title">Please carry</span>Aadhaar card, bank passbook, vehicle papers, and the crop in gunny bags of standard weight. Moisture above the permissible limit attracts a documented deduction shown on your slip.</div>';
      }

      el.innerHTML =
        '<div class="pagehead"><div class="wrap"><div>' +
        '<div class="crumb"><a href="dashboard.html">Dashboard</a> / Book a slot</div>' +
        '<h1>Book a weighment slot</h1>' +
        '<p class="muted" style="margin-top:8px">Four short steps. You will get an SMS with the reference and QR code.</p>' +
        '</div></div></div>' +
        '<div class="page"><div class="wrap wrap-narrow">' +
        '<ol class="stepper">' + STEPS.map(function (s, i) {
          var n = i + 1, cls = n < bk.step ? 'done' : n === bk.step ? 'now' : '';
          return '<li class="' + cls + '"><span class="dot">' + (n < bk.step ? '✓' : n) + '</span><span class="lbl">' + s + '</span><span class="bar"></span></li>';
        }).join('') + '</ol>' +
        '<form class="panel" id="bk-form" novalidate><div class="panel-body">' + inner + '</div>' +
        '<div class="panel-foot" style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">' +
        (bk.step > 1 ? '<button type="button" class="btn btn-ghost" onclick="KS.bookBack()">← Back</button>' : '<a class="btn btn-ghost" href="dashboard.html">Cancel</a>') +
        '<button type="submit" class="btn">' + (bk.step === 5 ? 'Confirm booking &amp; send SMS' : 'Continue →') + '</button>' +
        '</div></form></div></div>';


      /* step-specific bindings */
      $$('input[name="c"]').forEach(function (r) {
        r.addEventListener('change', function () { bk.center_id = r.value; bk.slot = null; render(); });
      });
      $$('input[name="p"]').forEach(function (r) {
        r.addEventListener('change', function () { bk.crop_id = r.value; render(); });
      });
      $$('[data-date]').forEach(function (b) {
        b.addEventListener('click', function () { bk.date = b.getAttribute('data-date'); bk.slot = null; render(); });
      });
      $$('[data-slot]').forEach(function (b) {
        b.addEventListener('click', function () {
          bk.slot = b.getAttribute('data-slot'); render();
          var o = occupancy(bk.center_id, bk.date, bk.slot);
          var box = $('#suggest');
          if (o.pct >= 70 && box) {
            var alt = busiestSuggestion(bk.center_id, bk.date, bk.slot);
            if (alt) {
              box.innerHTML = '<div class="callout" style="margin-top:16px"><span class="title">That hour is busy — ' + o.pct + '% full</span>' +
                fmtDate(alt.date) + ' at ' + alt.slot + ' has only ' + alt.pct + '% of its slots taken. ' +
                '<button type="button" class="btn-link" style="margin-left:6px" onclick="KS.switchSlot(\'' + alt.date + '\',\'' + alt.slot + '\')">Switch me to that slot →</button></div>';
            }
          }
        });
      });
      var qEl = $('#b-qty');
      if (qEl) qEl.addEventListener('input', function () {
        bk.qty = qEl.value.trim();
        var c = crop(bk.crop_id);
        $('#est-amt').textContent = inr((+bk.qty || 0) * c.rate);
      });
      $('#bk-form').addEventListener('submit', function (e) { e.preventDefault(); bookNext(); });
    }

    function bookNext() {
      if (bk.step === 1 && !bk.center_id) return;
      if (bk.step === 2 && !bk.crop_id) { toast('Choose a crop', 'Select the crop you are bringing to the centre.', 'red'); return; }
      if (bk.step === 3) {
        var v = $('#b-qty') ? $('#b-qty').value.trim() : bk.qty;
        if (!/^\d+(\.\d+)?$/.test(v) || +v <= 0) { $('#e-qty').classList.add('show'); return; }
        bk.qty = v;
        if ($('#b-veh')) bk.vehicle = $('#b-veh').value;
        if ($('#b-grade')) bk.grade = $('#b-grade').value;
      }
      if (bk.step === 4) {
        if (!bk.slot) { toast('Pick a time', 'Choose one of the available slots for ' + fmtDate(bk.date) + '.', 'red'); return; }
        var o = occupancy(bk.center_id, bk.date, bk.slot);
        if (o.pct >= 100) { toast('Slot full', 'That hour filled up while you were choosing. Please pick another.', 'red'); return; }
      }
      if (bk.step === 5) { return confirmBooking(); }
      bk.step++; render(); window.scrollTo(0, 0);
    }

    function confirmBooking() {
      var f = me(), c = crop(bk.crop_id), ctr = center(bk.center_id);
      var id = 'KS-' + Math.floor(88400 + Math.random() * 500);
      var b = {
        id: id, farmer_id: f.id, center_id: bk.center_id, crop_id: bk.crop_id,
        date: bk.date, slot: bk.slot, est_qty: +bk.qty, grade: bk.grade || '',
        status: 'confirmed', stage: 'booked', created_at: new Date().toISOString()
      };
      S.bookings.push(b); save();
      sms(f.phone, 'Slot booked',
        'KRISHI SETU: Slot confirmed ' + id + '. ' + ctr.short + ' centre, ' + fmtDate(bk.date) + ' at ' + bk.slot + '. ' +
        c.name + ' ~' + bk.qty + ' ' + c.unit + '. Carry Aadhaar + passbook. Show QR at gate. Helpline 1800-425-7733. - KISANSETU', 'green');
      bk.step = 1;
      goto('queue.html?id=' + id + '&new=1');
    }

    render();
    window.PAGE_REFRESH = render;
  }
  function bookBack() { if (bk.step > 1) { bk.step--; window.PAGE_REFRESH && window.PAGE_REFRESH(); } }
  function switchSlot(date, slot) { bk.date = date; bk.slot = slot; window.PAGE_REFRESH && window.PAGE_REFRESH(); toast('Slot switched', 'You are now holding ' + slot + ' on ' + fmtDate(date) + '.'); }

  function cancelBooking(id) {
    var b = booking(id); if (!b) return;
    openModal('<div class="modal-head"><div><h3>Cancel this slot?</h3>' +
      '<p class="small muted" style="margin:6px 0 0">' + esc(b.id) + ' · ' + fmtDate(b.date) + ', ' + b.slot + ' at ' + esc(center(b.center_id).short) + '</p></div>' +
      '<button class="x" type="button" onclick="KS.closeModal()" aria-label="Close">×</button></div>' +
      '<div class="modal-body"><p>Cancelling frees the weighbridge hour for a farmer on the waitlist. There is no penalty, and you can book again at any time.</p></div>' +
      '<div class="modal-foot"><button class="btn btn-ghost" type="button" onclick="KS.closeModal()">Keep my slot</button>' +
      '<button class="btn btn-danger" type="button" onclick="KS.doCancel(\'' + id + '\')">Cancel slot</button></div>');
  }
  function doCancel(id) {
    var b = booking(id); b.status = 'cancelled'; b.stage = 'cancelled'; save();
    var f = farmer(b.farmer_id);
    sms(f.phone, 'Slot cancelled', 'KRISHI SETU: Booking ' + id + ' for ' + fmtDate(b.date) + ' ' + b.slot + ' has been cancelled at your request. The slot has been released to the waitlist. - KISANSETU', 'red');
    closeModal(); toast('Slot cancelled', 'We released ' + id + ' to the waitlist.');
    setTimeout(function () { goto('bookings.html'); }, 700);
  }

  /* ============================================================
     PAGE: bookings.html
     ============================================================ */
  function pageBookings() {
    if (!requireFarmer()) return;
    var f = me(), el = $('#bookings-root');
    var mine = S.bookings.filter(function (b) { return b.farmer_id === f.id; })
      .sort(function (a, b) { return (b.date + b.slot).localeCompare(a.date + a.slot); });
    var up = mine.filter(function (b) { return b.status === 'confirmed' || b.status === 'checked_in'; });
    var past = mine.filter(function (b) { return b.status !== 'confirmed' && b.status !== 'checked_in'; });

    function rows(list, empty) {
      if (!list.length) return '<div class="empty"><b>' + empty + '</b></div>';
      return '<div class="tbl-scroll"><table class="tbl"><thead><tr>' +
        '<th>Ref</th><th>Date &amp; slot</th><th>Crop</th><th>Qty</th><th>Centre</th><th>Status</th><th class="right"></th>' +
        '</tr></thead><tbody>' + list.map(function (b) {
          var c = crop(b.crop_id);
          return '<tr><td class="mono">' + esc(b.id) + '</td>' +
            '<td>' + fmtDate(b.date) + '<div class="small muted">' + b.slot + ' hrs</div></td>' +
            '<td>' + esc(cropName(b.crop_id)) + '</td>' +
            '<td class="mono">' + (b.actual_qty || b.est_qty) + ' ' + c.unit + '</td>' +
            '<td>' + esc(center(b.center_id).short) + '</td>' +
            '<td>' + statusPill(b) + '</td>' +
            '<td class="right"><a class="btn btn-ghost btn-sm" href="' + (b.stage && STAGE_INDEX[b.stage] >= 2 ? 'payment.html?id=' + b.id : 'queue.html?id=' + b.id) + '">Open →</a></td></tr>';
        }).join('') + '</tbody></table></div>';
    }

    el.innerHTML =
      '<div class="pagehead"><div class="wrap"><div>' +
      '<div class="crumb"><a href="dashboard.html">Dashboard</a> / Bookings</div>' +
      '<h1>My bookings</h1><p class="muted" style="margin-top:8px">' + mine.length + ' lots this season · ' + up.length + ' upcoming</p>' +
      '</div><a class="btn" href="book.html">Book another slot</a></div></div>' +
      '<div class="page"><div class="wrap stack">' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Upcoming</h3><span class="pill pill-info">' + up.length + '</span></div>' +
      '<div class="panel-body" style="padding:0 0 6px">' + rows(up, 'No upcoming slots') + '</div></div>' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Completed &amp; closed</h3><span class="pill pill-idle">' + past.length + '</span></div>' +
      '<div class="panel-body" style="padding:0 0 6px">' + rows(past, 'Nothing yet') + '</div></div>' +
      '</div></div>';
  }

  /* ============================================================
     PAGE: queue.html  (live)
     ============================================================ */
  var queueTimer = null;
  function pageQueue() {
    if (!requireFarmer()) return;
    var el = $('#queue-root');
    var params = new URLSearchParams(location.search);
    var f = me();
    var id = params.get('id');
    var b = id ? booking(id) : S.bookings.filter(function (x) {
      return x.farmer_id === f.id && (x.status === 'confirmed' || x.status === 'checked_in');
    }).sort(function (a, z) { return (a.date + a.slot).localeCompare(z.date + z.slot); })[0];
    if (!b) { goto('bookings.html'); return; }

    function render() {
      var list = S.bookings.filter(function (x) {
        return x.center_id === b.center_id && x.date === b.date && x.slot === b.slot &&
          x.status !== 'cancelled' && x.status !== 'noshow' && x.status !== 'payment_completed';
      }).sort(function (x, z) {
        var wx = x.status === 'checked_in' ? 0 : 1, wz = z.status === 'checked_in' ? 0 : 1;
        return (wx - wz) || ((x.checked_in_at || x.created_at) < (z.checked_in_at || z.created_at) ? -1 : 1);
      });
      var pos = list.map(function (x) { return x.id; }).indexOf(b.id) + 1;
      var serving = list.filter(function (x) { return x.status === 'checked_in'; }).length;
      var wait = Math.max(0, (pos - Math.max(serving, 1))) * 9 + 4;
      var ctr = center(b.center_id), c = crop(b.crop_id);
      var myStatus = b.status === 'checked_in' ? 'pill-warn' : 'pill-info';
      var myLabel = b.status === 'checked_in' ? 'Checked in — waiting to be called' : 'Confirmed — not yet checked in';

      el.innerHTML =
        '<div class="pagehead"><div class="wrap"><div>' +
        '<div class="crumb"><a href="dashboard.html">Dashboard</a> / <a href="bookings.html">Bookings</a> / ' + esc(b.id) + '</div>' +
        '<h1>' + esc(ctr.name) + '</h1>' +
        '<p class="muted" style="margin-top:8px">' + fmtDate(b.date) + ' · ' + b.slot + ' hrs · ' + esc(cropName(b.crop_id)) + ' · ref <span class="mono">' + esc(b.id) + '</span></p>' +
        '</div><div style="text-align:right"><span class="pill ' + myStatus + '">' + myLabel + '</span>' +
        '<div class="small muted" style="margin-top:8px" id="q-clock">Live · updated just now</div></div></div></div>' +

        '<div class="page"><div class="wrap layout-2 rev">' +
        '<aside class="stack">' +
        '<div class="panel"><div class="panel-body center">' +
        '<span class="eyebrow eyebrow-ink">Your position</span>' +
        '<div class="mono" style="font-size:58px;line-height:1;color:var(--green-900)">' + (pos > 0 ? pos : '—') + '</div>' +
        '<div class="small muted" style="margin-top:6px">of ' + list.length + ' farmers in this slot</div>' +
        '<div class="meter gold" style="margin-top:16px"><i style="width:' + (list.length ? Math.round((list.length - pos + 1) / list.length * 100) : 0) + '%"></i></div>' +
        '<div style="display:flex;justify-content:space-between;margin-top:14px" class="small">' +
        '<span class="muted">Estimated wait</span><b class="mono">' + wait + ' min</b></div>' +
        '<div class="callout green" style="margin-top:18px;text-align:left"><span class="title">How this works</span>The operator scans your QR at the gate to check you in. When the weighbridge is free, you get an SMS saying “you are next” — you do not have to keep watching this page.</div>' +
        '</div></div>' +
        '<div class="qrbox">' + qrSvg(b.id + '|' + f.id, 210) +
        '<div class="small muted center" style="margin-top:12px">Booking QR · <span class="mono">' + esc(b.id) + '</span><br>Show this at the gate for check-in</div></div>' +
        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Lot details</h3></div><div class="panel-body">' +
        '<dl class="kv"><dt>Crop</dt><dd>' + esc(cropName(b.crop_id)) + '</dd>' +
        '<dt>Declared</dt><dd class="mono">' + b.est_qty + ' ' + esc(c.unit) + '</dd>' +
        '<dt>Rate today</dt><dd class="mono">' + inr(c.rate) + ' / ' + esc(c.unit) + '</dd>' +
        '<dt>Indicative</dt><dd class="mono">' + inr(b.est_qty * c.rate) + '</dd>' +
        '<dt>Centre</dt><dd>' + esc(ctr.short) + ' · ' + esc(ctr.phone) + '</dd></dl></div></div>' +
        '</aside>' +

        '<div class="stack">' +
        (params.get('new') ? '<div class="callout green"><span class="title">Booking confirmed</span>An SMS with this reference and QR code has been sent to <span class="mono">+91 ' + esc(f.phone) + '</span>. A reminder will follow the previous evening.</div>' : '') +
        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Live queue for ' + b.slot + '</h3>' +
        '<span class="pill ' + (serving ? 'pill-warn' : 'pill-idle') + '">' + serving + ' at weighbridge</span></div>' +
        '<div class="panel-body"><div class="queue-vis">' +
        (list.length ? list.map(function (x, i) {
          var xf = farmer(x.farmer_id), isMe = x.farmer_id === f.id;
          var cls = x.status === 'checked_in' ? 'done' : '';
          return '<div class="qrow ' + cls + (isMe ? ' me' : '') + '">' +
            '<span class="pos">' + (x.status === 'checked_in' ? '✓' : '#' + (i + 1)) + '</span>' +
            '<span class="nm">' + (isMe ? '<b>You</b> · ' : '') + esc(xf ? xf.name : 'Farmer') + '</span>' +
            '<span class="small muted">' + esc(cropName(x.crop_id)) + ' · ' + x.est_qty + ' ' + esc(crop(x.crop_id).unit) + '</span>' +
            '<span class="pill ' + (x.status === 'checked_in' ? 'pill-warn' : 'pill-idle') + '">' + (x.status === 'checked_in' ? 'Checked in' : 'Waiting') + '</span></div>';
        }).join('') : '<div class="empty"><b>Queue empty</b>No other farmers in this hour — you will be called straight away.</div>') +
        '</div><p class="small muted" style="margin-top:14px">Positions update automatically as the centre checks farmers in. Names of other farmers are shown to the centre operator only; here you see your own position and count.</p></div></div>' +

        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Before you travel</h3></div>' +
        '<div class="panel-body"><ul class="feat-list" style="padding:0">' +
        '<li><span class="ic">✓</span><span><b>Arrive 20 minutes early</b><p>Check-in closes 30 minutes after the slot start. After that the slot is released to the waitlist.</p></span></li>' +
        '<li><span class="ic">✓</span><span><b>Carry Aadhaar and passbook</b><p>The passbook account must match the account in your profile for payment to be credited.</p></span></li>' +
        '<li><span class="ic">✓</span><span><b>Moisture and cleanliness</b><p>Well-dried, cleaned produce grades better. Deductions are printed on your slip, not decided verbally.</p></span></li>' +
        '</ul></div></div>' +
        '<div style="display:flex;gap:10px;flex-wrap:wrap">' +
        '<a class="btn btn-ghost" href="payment.html?id=' + b.id + '">View payment trail →</a>' +
        '<button class="btn btn-ghost" type="button" onclick="KS.cancelBooking(\'' + b.id + '\')">Cancel this slot</button></div>' +
        '</div></div></div>';
    }

    render();
    window.PAGE_REFRESH = render;
    if (queueTimer) clearInterval(queueTimer);
    queueTimer = setInterval(function () { advanceQueue(b.center_id, b.date, b.slot, true); render(); }, 9000);
  }

  /* queue engine — used by farmer view and staff view */
  /* Promote the farmer who has waited longest. `slot` is optional: the
     operator's "Call next" works across the whole day, the farmer's live
     queue page only advances its own hour. */
  function advanceQueue(centerId, date, slot, quiet) {
    var list = S.bookings.filter(function (x) {
      return x.center_id === centerId && x.date === date &&
        (slot === null || slot === undefined || x.slot === slot) &&
        (x.status === 'confirmed' || x.status === 'checked_in');
    }).sort(function (x, z) {
      var wx = x.status === 'checked_in' ? 0 : 1, wz = z.status === 'checked_in' ? 0 : 1;
      return (wx - wz) || ((x.checked_in_at || x.created_at) < (z.checked_in_at || z.created_at) ? -1 : 1);
    });
    var serving = list.filter(function (x) { return x.status === 'checked_in'; });
    if (serving.length >= MAX_AT_WEIGHBRIDGE) return false;
    var next = list.filter(function (x) { return x.status === 'confirmed'; })[0];
    if (!next) return false;
    next.status = 'checked_in'; next.stage = 'checked_in';
    next.checked_in_at = new Date().toISOString();
    save();
    var f = farmer(next.farmer_id);
    if (!quiet) sms(f.phone, 'You are next',
      'KRISHI SETU: Please proceed to the weighbridge at ' + center(centerId).short + '. Booking ' + next.id + '. Keep your QR ready. - KISANSETU', 'gold');
    else toast('You are next', 'Proceed to the weighbridge · booking ' + next.id, 'gold');
    return true;
  }

  /* ============================================================
     PAGE: payment.html  (the money trail)
     ============================================================ */
  function pagePayment() {
    if (!requireFarmer()) return;
    var el = $('#pay-root');
    var id = new URLSearchParams(location.search).get('id');
    var b = booking(id); var f = me();
    if (!b || b.farmer_id !== f.id) { goto('payments.html'); return; }
    var c = crop(b.crop_id), ctr = center(b.center_id);
    var idx = STAGE_INDEX[b.stage] || 0;
    var amount = b.amount || 0;
    var deductions = Math.round(amount * 0.012);
    var net = amount - deductions;

    function step(i) {
      var s = STAGES[i];
      var at = [b.created_at, b.checked_in_at, b.procured_at, b.payment_init_at, b.payment_completed_at][i];
      var cls = i < idx ? 'done' : i === idx ? (at ? 'done' : 'now') : '';
      var note = '';
      if (i === 2 && b.procured_at) note = 'Weighed <b class="mono">' + (b.actual_qty || b.est_qty) + ' ' + c.unit + '</b> at <b class="mono">' + inr(b.rate || c.rate) + '</b> · grade ' + esc(b.grade || 'A') + ' · slip no. WB-' + b.id.slice(-4);
      if (i === 3 && b.payment_init_at) note = 'Sent to treasury for DBT credit to ' + esc((f.bank.acc || '').slice(0, 2)) + '••••' + esc((f.bank.acc || '').slice(-4)) + ' (' + esc(f.bank.ifsc) + ')';
      if (i === 4 && b.payment_completed_at) note = 'Reference <b class="mono">' + esc(b.utr || '—') + '</b> · credited in full';
      if (i === 4 && !b.payment_completed_at) note = 'DBT cycles run every weekday evening. You will get an SMS the moment the amount is credited.';
      return '<li class="tl-item ' + cls + '"><span class="node">' + (i < idx ? '✓' : i === idx ? '●' : (i + 1)) + '</span>' +
        '<h4>' + esc(S.lang === 'hi' ? s.hi : s.label) + '</h4>' +
        '<div class="when">' + (at ? fmtStamp(at) : 'Pending') + '</div>' +
        (note ? '<div class="note">' + note + '</div>' : '') + '</li>';
    }

    el.innerHTML =
      '<div class="pagehead"><div class="wrap"><div>' +
      '<div class="crumb"><a href="dashboard.html">Dashboard</a> / <a href="payments.html">Payments</a> / ' + esc(b.id) + '</div>' +
      '<h1>Procurement &amp; payment record</h1>' +
      '<p class="muted" style="margin-top:8px">' + fmtDate(b.date) + ' · ' + esc(ctr.name) + ' · ' + esc(cropName(b.crop_id)) + '</p>' +
      '</div><div style="text-align:right">' + statusPill(b) + '<div class="small muted" style="margin-top:8px">Ref <span class="mono">' + esc(b.id) + '</span></div></div></div></div>' +

      '<div class="page"><div class="wrap layout-2">' +
      '<div class="stack">' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Status timeline</h3>' +
      '<span class="pill pill-idle">Step ' + (idx + 1) + ' of ' + STAGES.length + '</span></div>' +
      '<div class="panel-body"><ol class="timeline">' + [0, 1, 2, 3, 4].map(step).join('') + '</ol></div></div>' +

      '<div class="panel"><div class="panel-head"><h3 class="h-sm">How the amount was worked out</h3></div>' +
      '<div class="panel-body">' + (b.procured_at ?
        '<div class="tbl-scroll"><table class="tbl tbl-compact"><tbody>' +
        '<tr><td>Weighed quantity</td><td class="right mono">' + (b.actual_qty || b.est_qty) + ' ' + c.unit + '</td></tr>' +
        '<tr><td>Rate on the day of weighment</td><td class="right mono">' + inr(b.rate || c.rate) + ' / ' + c.unit + '</td></tr>' +
        '<tr><td>Gross value</td><td class="right mono">' + inr(amount) + '</td></tr>' +
        '<tr><td>Moisture &amp; foreign matter deduction (1.2%)</td><td class="right mono">− ' + inr(deductions) + '</td></tr>' +
        '<tr><td><b>Net payable to your account</b></td><td class="right mono" style="font-size:17px;color:var(--green-900)"><b>' + inr(net) + '</b></td></tr>' +
        '</tbody></table></div>' +
        '<p class="small muted" style="margin-top:14px">Deductions follow the notified grading scale and are printed on the weighbridge slip. If you disagree with any line, raise a dispute — it reaches the centre officer the same day.</p>'
        : '<div class="empty"><b>Weighment not done yet</b>The calculation appears here the moment the operator records your weighed quantity.</div>') +
      '</div></div>' +

      '<div class="panel"><div class="panel-head"><h3 class="h-sm">SMS trail for this lot</h3></div>' +
      '<div class="panel-body stack-sm">' +
      (notesFor(f.id).filter(function (n) { return n.body.indexOf(b.id) >= 0; }).map(smsCard).join('') ||
        '<div class="empty"><b>No messages for this lot yet</b></div>') +
      '</div></div>' +
      '</div>' +

      '<aside class="stack">' +
      '<div class="panel"><div class="panel-body center" style="padding:28px 22px">' +
      '<span class="eyebrow eyebrow-ink">' + (b.payment_completed_at ? 'Credited' : 'Payable') + '</span>' +
      '<div class="mono" style="font-size:38px;color:var(--green-900);line-height:1.05">' + inr(b.procured_at ? net : (b.est_qty * c.rate)) + '</div>' +
      '<div class="small muted" style="margin-top:8px">' + (b.procured_at ? 'net after deductions' : 'indicative, at today’s rate') + '</div>' +
      (b.utr ? '<div class="mono small" style="margin-top:14px;color:var(--ink-50)">UTR ' + esc(b.utr) + '</div>' : '') +
      '</div></div>' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Payment to</h3></div><div class="panel-body">' +
      '<dl class="kv"><dt>Holder</dt><dd>' + esc(f.bank.holder) + '</dd>' +
      '<dt>Account</dt><dd class="mono">••••' + esc((f.bank.acc || '').slice(-4)) + '</dd>' +
      '<dt>IFSC</dt><dd class="mono">' + esc(f.bank.ifsc) + '</dd>' +
      '<dt>Mode</dt><dd>DBT via PFMS</dd></dl>' +
      '<a class="btn btn-ghost btn-block" style="margin-top:16px" href="profile.html">Update bank details</a></div></div>' +
      '<div class="panel"><div class="panel-body">' +
      '<button class="btn btn-outline btn-block" type="button" onclick="KS.openDisputeModal(\'' + b.id + '\')">Something looks wrong? Raise a dispute</button>' +
      '<p class="small muted" style="margin-top:12px">Weight, grade, deduction or a payment that has not arrived — one tap and the centre officer is notified with this record attached.</p>' +
      '</div></div>' +
      '<div class="qrbox">' + qrSvg(b.id, 180) + '<div class="small muted center" style="margin-top:10px">Lot QR · scanned at the gate</div></div>' +
      '</aside></div></div>';
  }

  /* ============================================================
     PAGE: payments.html
     ============================================================ */
  function pagePayments() {
    if (!requireFarmer()) return;
    var f = me(), el = $('#payments-root');
    var lots = S.bookings.filter(function (b) { return b.farmer_id === f.id && b.stage && STAGE_INDEX[b.stage] >= 2; })
      .sort(function (a, b) { return b.date.localeCompare(a.date); });
    var due = lots.filter(function (b) { return b.status !== 'payment_completed'; })
      .reduce(function (s, b) { return s + Math.round((b.amount || 0) * 0.988); }, 0);
    var paid = lots.filter(function (b) { return b.status === 'payment_completed'; })
      .reduce(function (s, b) { return s + Math.round((b.amount || 0) * 0.988); }, 0);

    el.innerHTML =
      '<div class="pagehead"><div class="wrap"><div>' +
      '<div class="crumb"><a href="dashboard.html">Dashboard</a> / Payments</div>' +
      '<h1>Payment tracking</h1>' +
      '<p class="muted" style="margin-top:8px">Every lot you have sold, and exactly where its money is right now.</p>' +
      '</div></div></div>' +
      '<div class="page"><div class="wrap stack">' +
      '<div class="stats">' +
      '<div class="stat"><div class="k">Awaiting credit</div><div class="v">' + inr(due) + '</div><div class="d">' + lots.filter(function (b) { return b.status !== 'payment_completed'; }).length + ' lots in progress</div></div>' +
      '<div class="stat"><div class="k">Credited this season</div><div class="v">' + inr(paid) + '</div><div class="d up">to ' + esc(f.bank.ifsc) + ' ••••' + esc((f.bank.acc || '').slice(-4)) + '</div></div>' +
      '<div class="stat"><div class="k">Total lots</div><div class="v">' + lots.length + '</div><div class="d">across ' + new Set(lots.map(function (b) { return b.center_id; })).size + ' centres</div></div>' +
      '<div class="stat"><div class="k">Typical credit time</div><div class="v">72 hrs</div><div class="d">from weighment, via DBT</div></div>' +
      '</div>' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">All lots</h3></div>' +
      '<div class="panel-body" style="padding:0 0 6px">' + (lots.length ?
        '<div class="tbl-scroll"><table class="tbl"><thead><tr><th>Ref</th><th>Date</th><th>Crop &amp; qty</th><th>Rate</th><th>Gross</th><th>Stage</th><th>Reference</th><th class="right"></th></tr></thead><tbody>' +
        lots.map(function (b) {
          var c = crop(b.crop_id), i = STAGE_INDEX[b.stage] || 0;
          return '<tr><td class="mono">' + esc(b.id) + '</td><td>' + fmtDate(b.date) + '</td>' +
            '<td>' + esc(cropName(b.crop_id)) + ' <span class="muted small">' + (b.actual_qty || b.est_qty) + ' ' + c.unit + '</span></td>' +
            '<td class="mono">' + inr(b.rate || c.rate) + '</td>' +
            '<td class="mono">' + inr(b.amount || 0) + '</td>' +
            '<td><span class="pill ' + (b.status === 'payment_completed' ? 'pill-ok' : 'pill-gold') + '">' + esc(STAGES[i].label) + '</span></td>' +
            '<td class="mono small">' + esc(b.utr || '—') + '</td>' +
            '<td class="right"><a class="btn btn-ghost btn-sm" href="payment.html?id=' + b.id + '">Open →</a></td></tr>';
        }).join('') + '</tbody></table></div>'
        : '<div class="empty"><b>No procurement yet</b>Once your first lot is weighed, its payment trail appears here.</div>') +
      '</div></div>' +
      '<div class="callout"><span class="title">Payment not received within 72 hours?</span>Raise a dispute from the lot page. The centre officer must respond within three working days, and every response is logged against your farmer ID.</div>' +
      '</div></div>';
  }

  /* ============================================================
     PAGE: notifications.html
     ============================================================ */
  function pageNotifications() {
    if (!requireFarmer()) return;
    var f = me(), el = $('#notes-root');
    var list = notesFor(f.id).sort(function (a, b) { return b.at.localeCompare(a.at); });
    var groups = {};
    list.forEach(function (n) { var d = n.at.slice(0, 10); (groups[d] = groups[d] || []).push(n); });
    var body = Object.keys(groups).sort().reverse().map(function (d) {
      return '<div><div class="ornament" style="margin:6px 0 14px"><span>' + fmtDate(d) + '</span></div>' +
        '<div class="stack-sm">' + groups[d].map(smsCard).join('') + '</div></div>';
    }).join('');

    el.innerHTML =
      '<div class="pagehead"><div class="wrap"><div>' +
      '<div class="crumb"><a href="dashboard.html">Dashboard</a> / Alerts</div>' +
      '<h1>SMS &amp; notification history</h1>' +
      '<p class="muted" style="margin-top:8px">Every message sent to <span class="mono">+91 ' + esc(f.phone) + '</span>. These are exactly what arrives on your phone.</p>' +
      '</div><span class="pill pill-idle">SMS copy of every alert</span></div></div>' +
      '<div class="page"><div class="wrap wrap-narrow stack">' +
      '<div class="callout info"><span class="title">SMS first, app second</span>Every alert is sent as a plain SMS so it reaches a basic phone with no data connection. This page is only a copy for your records.</div>' +
      (body || '<div class="panel"><div class="empty"><b>No alerts yet</b>Book a slot and the first SMS will arrive within seconds.</div></div>') +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Alerts you will receive</h3></div><div class="panel-body">' +
      '<ul class="feat-list">' +
      '<li><span class="ic">✓</span><span><b>Registration &amp; farmer ID</b><p>Sent once, immediately after you verify your mobile number.</p></span></li>' +
      '<li><span class="ic">✓</span><span><b>Slot confirmed</b><p>Reference number, centre, date and time, plus the QR code link.</p></span></li>' +
      '<li><span class="ic">✓</span><span><b>Reminder</b><p>The previous evening, and again one hour before your slot.</p></span></li>' +
      '<li><span class="ic">✓</span><span><b>You are next</b><p>Sent by the operator when the weighbridge is free for you.</p></span></li>' +
      '<li><span class="ic">✓</span><span><b>Quantity recorded</b><p>Weight, rate and gross value the moment the slip is printed.</p></span></li>' +
      '<li><span class="ic">✓</span><span><b>Payment initiated &amp; credited</b><p>With the bank reference number so you can check with your branch.</p></span></li>' +
      '</ul></div></div></div></div>';
  }

  /* ============================================================
     PAGE: profile.html
     ============================================================ */
  function pageProfile() {
    if (!requireFarmer()) return;
    var f = me(), el = $('#profile-root');
    function render() {
      el.innerHTML =
        '<div class="pagehead"><div class="wrap"><div>' +
        '<div class="crumb"><a href="dashboard.html">Dashboard</a> / Profile</div>' +
        '<h1>Profile &amp; bank details</h1>' +
        '<p class="muted" style="margin-top:8px">Farmer ID <span class="mono">' + esc(f.id) + '</span> · registered ' + f.created_at.slice(0, 10) + '</p>' +
        '</div><div style="text-align:right"><span class="pill pill-ok">Land record verified</span></div></div></div>' +
        '<div class="page"><div class="wrap layout-2">' +
        '<form class="stack" id="pf-form" novalidate>' +
        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Identity &amp; contact</h3></div><div class="panel-body">' +
        '<div class="grid-2"><div class="field"><label>Full name</label><input class="input" id="p-name" value="' + esc(f.name) + '"></div>' +
        '<div class="field"><label>Mobile (receives all alerts)</label><input class="input mono" id="p-phone" maxlength="10" value="' + esc(f.phone) + '"></div></div>' +
        '<div class="grid-3"><div class="field"><label>Village</label><input class="input" id="p-village" value="' + esc(f.village) + '"></div>' +
        '<div class="field"><label>District</label><input class="input" id="p-district" value="' + esc(f.district) + '"></div>' +
        '<div class="field"><label>State</label><input class="input" id="p-state" value="' + esc(f.state) + '"></div></div>' +
        '</div></div>' +

        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Land holding</h3></div><div class="panel-body">' +
        '<div class="grid-3"><div class="field"><label>Total acres</label><input class="input mono" id="p-area" value="' + esc(f.land_area) + '"></div>' +
        '<div class="field"><label>Holding type</label><select class="select" id="p-type">' + ['owned', 'leased', 'family-shared']
          .map(function (x) { return '<option' + (f.land_type === x ? ' selected' : '') + '>' + x + '</option>'; }).join('') + '</select></div>' +
        '<div class="field"><label>Survey number</label><input class="input mono" id="p-survey" value="' + esc(f.survey || '') + '"></div></div>' +
        '<div class="field"><label>Crops grown</label>' + cropChips(f.crops || []) + '</div>' +
        '</div></div>' +

        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Bank account for payment</h3>' +
        '<span class="pill pill-warn">Changes need OTP</span></div><div class="panel-body">' +
        '<div class="field"><label>Account holder</label><input class="input" id="p-holder" value="' + esc(f.bank.holder) + '"></div>' +
        '<div class="grid-2"><div class="field"><label>Account number</label><input class="input mono" id="p-acc" value="' + esc(f.bank.acc) + '"></div>' +
        '<div class="field"><label>IFSC</label><input class="input mono" id="p-ifsc" value="' + esc(f.bank.ifsc) + '" style="text-transform:uppercase"></div></div>' +
        '<div class="callout"><span class="title">Security</span>If you change the account number, we send an OTP to your registered mobile before saving. Payment for lots already weighed continues to the old account until they settle.</div>' +
        '</div></div>' +

        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Preferences</h3></div><div class="panel-body">' +
        '<div class="grid-2"><div class="field"><label>Language for SMS alerts</label>' +
        '<select class="select" id="p-lang"><option value="en" selected>English</option>' +
        '<option value="kn">Kannada (coming soon)</option>' +
        '<option value="te">Telugu (coming soon)</option></select></div>' +
        '<div class="field"><label>Secondary contact number</label><input class="input mono" id="p-alt" maxlength="10" placeholder="optional"></div></div>' +
        '</div></div>' +

        '<div style="display:flex;gap:10px;flex-wrap:wrap">' +
        '<button type="submit" class="btn">Save changes</button>' +
        '<button type="button" class="btn btn-ghost" onclick="KS.logout()">Logout</button></div>' +
        '</form>' +

        '<aside class="stack">' +
        '<div class="panel"><div class="panel-body center">' +
        '<span class="av" style="display:inline-grid;width:64px;height:64px;border-radius:50%;background:var(--green-800);color:#F3EFE4;place-items:center;font-family:var(--mono);font-size:22px">' + initials(f.name) + '</span>' +
        '<h3 class="h-sm" style="margin-top:14px">' + esc(f.name) + '</h3>' +
        '<div class="mono small muted">' + esc(f.id) + '</div>' +
        '<div class="small muted" style="margin-top:10px">' + esc(f.village) + ', ' + esc(f.district) + '<br>' + f.land_area + ' acres · ' + esc(f.land_type) + '</div>' +
        '</div></div>' +
        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Season summary</h3></div><div class="panel-body">' +
        '<dl class="kv"><dt>Lots sold</dt><dd>' + S.bookings.filter(function (b) { return b.farmer_id === f.id && b.stage && STAGE_INDEX[b.stage] >= 2; }).length + '</dd>' +
        '<dt>Centres used</dt><dd>' + new Set(S.bookings.filter(function (b) { return b.farmer_id === f.id; }).map(function (b) { return b.center_id; })).size + '</dd>' +
        '<dt>Member since</dt><dd>' + f.created_at.slice(0, 10) + '</dd></dl></div></div>' +
        '<div class="callout info"><span class="title">Verification</span>Your land record was verified by the Mandya taluk office. Corrections to survey number need a fresh verification, which takes three working days.</div>' +
        '</aside></div></div>';
      function persistProfile() {
        var g = function (id) { var e = $('#p-' + id); return e ? e.value.trim() : null; };
        if (g('name') !== null) f.name = g('name');
        if (g('phone') !== null) f.phone = g('phone');
        if (g('village') !== null) f.village = g('village');
        if (g('district') !== null) f.district = g('district');
        if (g('state') !== null) f.state = g('state');
        if (g('area') !== null && g('area') !== '') f.land_area = +g('area');
        if ($('#p-type')) f.land_type = $('#p-type').value;
        if (g('survey') !== null) f.survey = g('survey');
        if (g('holder') !== null) f.bank.holder = g('holder');
        if (g('acc') !== null) f.bank.acc = g('acc');
        if (g('ifsc') !== null) f.bank.ifsc = g('ifsc').toUpperCase();
      }
      $$('[data-crop]').forEach(function (b) {
        b.addEventListener('click', function () {
          persistProfile();
          var list = f.crops || (f.crops = []), cid = b.getAttribute('data-crop'), i = list.indexOf(cid);
          if (i >= 0) list.splice(i, 1); else list.push(cid);
          render();
        });
      });
      $('#pf-form').addEventListener('submit', function (e) {
        e.preventDefault();
        var oldAcc = f.bank.acc, newAcc = $('#p-acc').value.trim();
        function apply() {
          f.name = $('#p-name').value.trim(); f.phone = $('#p-phone').value.trim();
          f.village = $('#p-village').value.trim(); f.district = $('#p-district').value.trim(); f.state = $('#p-state').value.trim();
          f.land_area = +$('#p-area').value || f.land_area; f.land_type = $('#p-type').value; f.survey = $('#p-survey').value.trim();
          f.bank.holder = $('#p-holder').value.trim(); f.bank.acc = newAcc; f.bank.ifsc = $('#p-ifsc').value.trim().toUpperCase();
          f.lang = $('#p-lang').value; save();
          sms(f.phone, 'Profile updated', 'KRISHI SETU: Your profile was updated on ' + new Date().toLocaleDateString('en-IN') + '. If this was not you, call 1800-425-7733 immediately. - KISANSETU', 'teal');
          closeModal(); toast('Saved', 'Profile updated and an SMS confirmation was sent.');
          render();
        }
        if (newAcc !== oldAcc) {
          var code = String(Math.floor(100000 + Math.random() * 899999));
          openModal('<div class="modal-head"><div><h3>Confirm bank change</h3>' +
            '<p class="small muted" style="margin:6px 0 0">We sent a code to +91 ' + esc(f.phone) + '</p></div>' +
            '<button class="x" type="button" onclick="KS.closeModal()">×</button></div>' +
            '<div class="modal-body"><div class="field"><label>One-time password</label>' +
            '<input class="input mono" id="p-otp" inputmode="numeric" maxlength="6" style="font-size:20px;letter-spacing:.3em;text-align:center" placeholder="······">' +
            '<div class="hint">Demo code: <b class="mono">' + code + '</b></div></div></div>' +
            '<div class="modal-foot"><button class="btn btn-ghost" type="button" onclick="KS.closeModal()">Cancel</button>' +
            '<button class="btn" type="button" id="p-otp-ok">Verify &amp; save</button></div>');
          $('#p-otp-ok').addEventListener('click', function () {
            if ($('#p-otp').value.trim() === code) apply();
            else toast('Wrong code', 'The OTP did not match. Nothing was changed.', 'red');
          });
        } else apply();
      });
    }
    render();
    window.PAGE_REFRESH = render;
  }

  /* ---------------- dispute modal ---------------- */
  function openDisputeModal(bookingId) {
    var f = me(); if (!f) return;
    var lots = S.bookings.filter(function (b) { return b.farmer_id === f.id; });
    openModal('<div class="modal-head"><div><h3>Raise a dispute</h3>' +
      '<p class="small muted" style="margin:6px 0 0">The centre officer receives this with your lot record attached.</p></div>' +
      '<button class="x" type="button" onclick="KS.closeModal()">×</button></div>' +
      '<div class="modal-body">' +
      '<div class="field"><label>Which lot?</label><select class="select" id="d-booking">' +
      lots.map(function (b) { return '<option value="' + b.id + '"' + (b.id === bookingId ? ' selected' : '') + '>' + b.id + ' · ' + fmtDate(b.date) + ' · ' + cropName(b.crop_id) + '</option>'; }).join('') +
      '</select></div>' +
      '<div class="field"><label>What is wrong?</label><select class="select" id="d-reason">' +
      ['Quantity mismatch', 'Grade / quality rating', 'Deduction too high', 'Payment not received', 'Slot or check-in issue', 'Other']
        .map(function (r) { return '<option>' + r + '</option>'; }).join('') + '</select></div>' +
      '<div class="field"><label>Describe briefly</label><textarea class="textarea" id="d-note" rows="4" placeholder="e.g. The weighbridge slip showed 24.1 quintal but the record shows 23.4."></textarea></div>' +
      '<p class="small muted">Disputes must be filed within 15 days of procurement. You will get an SMS acknowledgement immediately and a resolution within three working days.</p>' +
      '</div>' +
      '<div class="modal-foot"><button class="btn btn-ghost" type="button" onclick="KS.closeModal()">Cancel</button>' +
      '<button class="btn" type="button" onclick="KS.submitDispute()">Submit dispute</button></div>');
  }
  function submitDispute() {
    var f = me();
    var id = 'DSP-' + Math.floor(2050 + Math.random() * 400);
    S.disputes.unshift({
      id: id, booking_id: $('#d-booking').value, farmer_id: f.id,
      reason: $('#d-reason').value, note: $('#d-note').value.trim() || 'No description given.',
      at: new Date().toISOString(), status: 'open', resolution: ''
    });
    save();
    sms(f.phone, 'Dispute received',
      'KRISHI SETU: Grievance ' + id + ' registered for lot ' + $('#d-booking').value + ' (' + $('#d-reason').value + '). The centre officer will respond within 3 working days. Track at your dashboard. - KISANSETU', 'teal');
    closeModal();
    toast('Dispute filed', 'Reference ' + id + ' — the centre officer has been notified.');
    setTimeout(function () { if (location.pathname.indexOf('dashboard') >= 0 || location.pathname.indexOf('payment') >= 0) location.reload(); }, 800);
  }

  /* ============================================================
     STAFF: login
     ============================================================ */
  function pageStaffLogin() {
    var el = $('#staff-root');
    el.innerHTML =
      '<div class="page" style="padding-top:56px"><div class="wrap wrap-tight">' +
      '<div class="center" style="margin-bottom:26px"><div class="ornament"><span>Centre staff portal</span></div></div>' +
      '<form class="panel" id="staff-form" novalidate><div class="panel-body">' +
      '<div class="field"><label for="s-id">Staff ID</label>' +
      '<input class="input mono" id="s-id" value="STAFF-MANDYA-01" style="text-transform:uppercase"></div>' +
      '<div class="field"><label for="s-pw">Password</label>' +
      '<input class="input" id="s-pw" type="password" value="mandya" autocomplete="current-password"></div>' +
      '<div class="err" id="e-staff">Those credentials do not match any staff account.</div>' +
      '<button type="submit" class="btn btn-block btn-lg">Sign in</button>' +
      '<div class="callout" style="margin-top:20px"><span class="title">Demo accounts</span>' +
      'Centre operator: <b class="mono">STAFF-MANDYA-01 / mandya</b><br>' +
      'State officer (analytics): <b class="mono">STAFF-STATE-99 / admin</b></div>' +
      '<div style="display:flex;gap:10px;margin-top:12px;flex-wrap:wrap">' +
      '<button type="button" class="btn btn-gold" style="flex:1" onclick="KS.demoLoginStaff()">Enter as centre operator →</button>' +
      '<button type="button" class="btn btn-ghost" style="flex:1" onclick="KS.demoLoginFarmer()">Enter as farmer →</button></div>' +
      '</div></form>' +
      '<p class="small muted center" style="margin-top:20px">Staff actions are logged against your ID and are auditable by the department.</p>' +
      '</div></div>';
    $('#staff-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var id = $('#s-id').value.trim().toUpperCase(), pw = $('#s-pw').value;
      var found = null;
      S.staff_users.forEach(function (u) { if (u.id === id && u.pwd === pw) found = u; });
      if (!found) { $('#e-staff').classList.add('show'); return; }
      S.staff = found.id; save();
      goto(found.center_id ? 'admin-queue.html' : 'admin-analytics.html');
    });
  }
  function staffLogout() { S.staff = null; save(); goto('staff-login.html'); }
  function staff() {
    if (!S.staff) return null;
    for (var i = 0; i < S.staff_users.length; i++) if (S.staff_users[i].id === S.staff) return S.staff_users[i];
    return null;
  }

  /* ============================================================
     STAFF: today's queue
     ============================================================ */
  function pageAdminQueue() {
    if (!requireStaff()) return;
    var el = $('#aqueue-root'), st = staff();
    var centerId = st.center_id || 'C1';
    var date = ymd(today());

    function render() {
      var all = S.bookings.filter(function (b) { return b.center_id === centerId && b.date === date && b.status !== 'cancelled'; })
        .sort(function (a, b) {
          var wa = a.status === 'checked_in' ? 0 : 1, wb = b.status === 'checked_in' ? 0 : 1;
          return (wa - wb) || (a.slot + a.created_at).localeCompare(b.slot + b.created_at);
        });
      var waiting = all.filter(function (b) { return b.status === 'confirmed'; });
      var serving = all.filter(function (b) { return b.status === 'checked_in'; });
      var done = all.filter(function (b) { return b.status !== 'confirmed' && b.status !== 'checked_in'; });
      var totalQty = all.reduce(function (s, b) { return s + (b.actual_qty || b.est_qty); }, 0);

      el.innerHTML =
        '<div class="pagehead"><div class="wrap"><div>' +
        '<div class="crumb">Centre operations</div>' +
        '<h1>Today’s queue — ' + esc(center(centerId).name) + '</h1>' +
        '<p class="muted" style="margin-top:8px">' + fmtDate(date) + ' · ' + all.length + ' bookings · ' + totalQty.toFixed(1) + ' quintals expected</p>' +
        '</div><div style="display:flex;gap:10px;flex-wrap:wrap">' +
        '<button class="btn" type="button" onclick="KS.callNext()">Call next farmer</button>' +
        '<button class="btn btn-ghost" type="button" onclick="KS.openScan()">Scan QR check-in</button></div></div></div>' +

        '<div class="page"><div class="wrap stack">' +
        '<div class="stats">' +
        '<div class="stat"><div class="k">Waiting</div><div class="v">' + waiting.length + '</div><div class="d">not yet checked in</div></div>' +
        '<div class="stat"><div class="k">At weighbridge</div><div class="v">' + serving.length + '</div><div class="d">' + MAX_AT_WEIGHBRIDGE + ' bays in use</div></div>' +
        '<div class="stat"><div class="k">Completed</div><div class="v">' + done.length + '</div><div class="d up">weighed &amp; recorded</div></div>' +
        '<div class="stat"><div class="k">Avg. wait</div><div class="v">' + (waiting.length * 9 + 6) + 'm</div><div class="d">target under 60 min</div></div>' +
        '</div>' +

        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Live board</h3>' +
        '<span class="small muted">Positions update for farmers in real time</span></div>' +
        '<div class="panel-body" style="padding:0 0 6px">' +
        '<div class="tbl-scroll"><table class="tbl"><thead><tr>' +
        '<th>#</th><th>Ref</th><th>Farmer</th><th>Slot</th><th>Crop &amp; qty</th><th>Status</th><th>Checked in</th><th class="right">Action</th>' +
        '</tr></thead><tbody>' +
        all.map(function (b, i) {
          var f = farmer(b.farmer_id), c = crop(b.crop_id);
          var act = b.status === 'confirmed'
            ? '<button class="btn btn-sm" type="button" onclick="KS.checkIn(\'' + b.id + '\')">Check in</button>'
            : b.status === 'checked_in'
              ? '<button class="btn btn-sm btn-gold" type="button" onclick="KS.recordOpen(\'' + b.id + '\')">Record weight</button>'
              : '<a class="btn btn-sm btn-ghost" href="admin-procure.html?id=' + b.id + '">View</a>';
          return '<tr><td class="mono">' + (i + 1) + '</td><td class="mono">' + esc(b.id) + '</td>' +
            '<td><b>' + esc(f ? f.name : '—') + '</b><div class="small muted mono">' + esc(f ? f.id : '') + ' · ' + esc(f ? f.phone : '') + '</div></td>' +
            '<td class="mono">' + b.slot + '</td>' +
            '<td>' + esc(c.name) + '<div class="small muted mono">' + (b.actual_qty || b.est_qty) + ' ' + c.unit + (b.grade ? ' · grade ' + esc(b.grade) : '') + '</div></td>' +
            '<td>' + statusPill(b) + '</td>' +
            '<td class="small mono muted">' + (b.checked_in_at ? fmtStamp(b.checked_in_at) : '—') + '</td>' +
            '<td class="right">' + act + '</td></tr>';
        }).join('') + '</tbody></table></div></div>' +
        '<div class="panel-foot small muted">No-show rule: a booking not checked in within ' + NO_SHOW_AFTER_MINS + ' minutes of its slot start is released to the waitlist and marked accordingly.</div></div>' +

        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Waitlist &amp; releases</h3></div><div class="panel-body">' +
        '<p class="small muted">Farmers who arrive without a booking are added here and offered the next released slot. Today: <b>2 walk-ins</b>, 1 slot released from a no-show at 09:32.</p>' +
        '<div class="callout info" style="margin-top:14px"><span class="title">Escalation</span>If the queue for a slot exceeds 12 farmers, open the second weighbridge and notify the taluk officer.</div>' +
        '</div></div>' +
        '</div></div>';
      startClock();
    }

    render();
    window.PAGE_REFRESH = render;
  }

  function startClock() {
    var c = $('#clock'); if (!c) return;
    function tick() {
      var e = $('#clock'); if (!e) return;
      e.textContent = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }
    tick(); setInterval(tick, 1000);
  }

  function checkIn(id) {
    var b = booking(id); if (!b) return;
    b.status = 'checked_in'; b.stage = 'checked_in'; b.checked_in_at = new Date().toISOString();
    b.checked_in_by = S.staff; save();
    var f = farmer(b.farmer_id);
    sms(f.phone, 'Checked in', 'KRISHI SETU: You are checked in at ' + center(b.center_id).short + '. Wait for the “you are next” SMS. Booking ' + b.id + '. - KISANSETU', 'gold');
    window.PAGE_REFRESH && window.PAGE_REFRESH();
    toast('Checked in', f.name + ' added to the live queue.');
  }

  function callNext() {
    var st = staff(), centerId = st.center_id || 'C1', date = ymd(today());
    var moved = advanceQueue(centerId, date, null, false);
    if (!moved) toast('Queue idle', 'No waiting farmer to call at the moment.');
    else window.PAGE_REFRESH && window.PAGE_REFRESH();
  }

  function openScan() {
    var st = staff(), centerId = st.center_id || 'C1', date = ymd(today());
    var list = S.bookings.filter(function (b) {
      return b.center_id === centerId && b.date === date && b.status === 'confirmed';
    }).sort(function (a, b) { return (a.slot).localeCompare(b.slot); });
    openModal('<div class="modal-head"><div><h3>QR check-in</h3>' +
      '<p class="small muted" style="margin:6px 0 0">Point the scanner at the farmer’s booking QR. In this prototype, pick the code from today’s list.</p></div>' +
      '<button class="x" type="button" onclick="KS.closeModal()">×</button></div>' +
      '<div class="modal-body">' +
      (list.length ? '<div class="scanpad">' + list.map(function (b) {
        var f = farmer(b.farmer_id);
        return '<button class="scanbtn" type="button" onclick="KS.scanCheckIn(\'' + b.id + '\')">' +
          '<span><b>' + esc(f ? f.name : '') + '</b><div class="code">' + esc(b.id) + ' · ' + b.slot + ' · ' + esc(cropName(b.crop_id)) + '</div></span>' +
          '<span class="pill pill-idle">' + esc(crop(b.crop_id).unit) + ' ' + b.est_qty + '</span></button>';
      }).join('') + '</div>' : '<div class="empty"><b>Nothing to check in</b>Every booking for today is already checked in or completed.</div>') +
      '</div>');
  }
  function scanCheckIn(id) { closeModal(); checkIn(id); }

  /* ============================================================
     STAFF: record procurement
     ============================================================ */
  function pageAdminProcure() {
    if (!requireStaff()) return;
    var el = $('#aprocure-root'), st = staff();
    var centerId = st.center_id || 'C1', date = ymd(today());
    var qid = new URLSearchParams(location.search).get('id');

    function render() {
      var serving = S.bookings.filter(function (b) { return b.center_id === centerId && b.status === 'checked_in'; });
      var b = qid ? booking(qid) : serving[0];
      var list = S.bookings.filter(function (x) {
        return x.center_id === centerId && x.date === date && (x.status === 'checked_in' || (x.stage && STAGE_INDEX[x.stage] >= 2));
      });
      var left =
        '<div class="panel"><div class="panel-head"><h3 class="h-sm">At the weighbridge</h3></div><div class="panel-body">' +
        (list.length ? '<div class="stack-sm">' + list.map(function (x) {
          var f = farmer(x.farmer_id);
          return '<a class="scanbtn" href="admin-procure.html?id=' + x.id + '" style="text-decoration:none;color:inherit">' +
            '<span><b>' + esc(f ? f.name : '') + '</b><div class="code">' + esc(x.id) + ' · ' + esc(cropName(x.crop_id)) + '</div></span>' +
            '<span class="pill ' + (x.status === 'checked_in' ? 'pill-warn' : 'pill-ok') + '">' + (x.status === 'checked_in' ? 'Weigh now' : 'Done') + '</span></a>';
        }).join('') + '</div>' : '<div class="empty"><b>Weighbridge idle</b>Check farmers in from the queue board.</div>') +
        '</div></div>' +
        '<div class="callout"><span class="title">Grading discipline</span>Record the grade shown on the grading slip, not a verbal agreement. Deductions are computed automatically from the notified scale and are visible to the farmer immediately.</div>';

      if (!b) {
        el.innerHTML = head() + '<div class="page"><div class="wrap layout-2 rev"><aside class="stack">' + left + '</aside>' +
          '<div class="panel"><div class="empty"><b>Nothing to weigh</b>Check a farmer in from the queue board to open the weighment form.</div></div></div></div>';
        return;
      }
      var f = farmer(b.farmer_id), c = crop(b.crop_id);
      var qty = b.actual_qty || b.est_qty, rate = b.rate || c.rate;
      var gross = Math.round(qty * rate), ded = Math.round(gross * 0.012), net = gross - ded;

      el.innerHTML = head() +
        '<div class="page"><div class="wrap layout-2 rev">' +
        '<aside class="stack">' + left + '</aside>' +
        '<div class="stack">' +
        '<div class="panel"><div class="panel-head"><div><h3 class="h-sm">Weighment slip · ' + esc(b.id) + '</h3>' +
        '<div class="small muted">' + esc(f.name) + ' · <span class="mono">' + esc(f.id) + '</span> · ' + esc(f.village) + '</div></div>' +
        statusPill(b) + '</div>' +
        '<form class="panel-body" id="procure-form" novalidate>' +
        '<div class="grid-3">' +
        '<div class="field"><label>Weighed quantity (' + c.unit + ')</label>' +
        '<input class="input mono" id="w-qty" inputmode="decimal" value="' + qty + '" style="font-size:20px"></div>' +
        '<div class="field"><label>Grade</label><select class="select" id="w-grade">' +
        ['A', 'B', 'C'].map(function (g) { return '<option' + ((b.grade || 'A') === g ? ' selected' : '') + '>' + g + '</option>'; }).join('') + '</select></div>' +
        '<div class="field"><label>Rate in force</label><input class="input mono" id="w-rate" value="' + rate + '" disabled>' +
        '<div class="hint">Locked by the state board — editable only in Rate management.</div></div>' +
        '</div>' +
        '<div class="grid-2"><div class="field"><label>Moisture (%)</label><input class="input mono" id="w-moist" inputmode="decimal" value="12.4"></div>' +
        '<div class="field"><label>Weighbridge slip no.</label><input class="input mono" id="w-slip" value="WB-' + b.id.slice(-4) + '"></div></div>' +
        '<div class="field"><label>Operator remarks (optional)</label><textarea class="textarea" id="w-note" rows="2" placeholder="e.g. Well dried, cleaned, standard gunny bags."></textarea></div>' +
        '<div class="panel" style="background:#FCFAF4;margin-bottom:0"><div class="panel-body">' +
        '<div class="tbl-scroll"><table class="tbl tbl-compact"><tbody>' +
        '<tr><td>Gross value</td><td class="right mono" id="w-gross">' + inr(gross) + '</td></tr>' +
        '<tr><td>Deduction (1.2% moisture &amp; foreign matter)</td><td class="right mono" id="w-ded">− ' + inr(ded) + '</td></tr>' +
        '<tr><td><b>Net payable</b></td><td class="right mono" id="w-net" style="font-size:18px;color:var(--green-900)"><b>' + inr(net) + '</b></td></tr>' +
        '</tbody></table></div>' +
        '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px">' +
        '<button type="submit" class="btn">Confirm procurement &amp; SMS the farmer</button>' +
        '<button type="button" class="btn btn-ghost" onclick="KS.markNoShow(\'' + b.id + '\')">Mark no-show</button>' +
        '</div></div></div>' +
        '</form></div>' +

        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Farmer record</h3></div><div class="panel-body">' +
        '<dl class="kv"><dt>Name</dt><dd>' + esc(f.name) + '</dd>' +
        '<dt>Farmer ID</dt><dd class="mono">' + esc(f.id) + '</dd>' +
        '<dt>Mobile</dt><dd class="mono">+91 ' + esc(f.phone) + '</dd>' +
        '<dt>Land</dt><dd>' + f.land_area + ' acres · ' + esc(f.land_type) + (f.survey ? ' · ' + esc(f.survey) : '') + '</dd>' +
        '<dt>Payment to</dt><dd class="mono">' + esc(f.bank.acc) + ' · ' + esc(f.bank.ifsc) + '</dd>' +
        '<dt>Open disputes</dt><dd>' + S.disputes.filter(function (d) { return d.farmer_id === f.id && d.status === 'open'; }).length + '</dd></dl>' +
        '</div></div>' +
        '</div></div></div>';

      $('#procure-form').addEventListener('submit', function (e) { e.preventDefault(); confirmProcure(b); });
      var qEl = $('#w-qty');
      qEl.addEventListener('input', function () {
        var q = +qEl.value || 0, g = Math.round(q * rate), d = Math.round(g * 0.012);
        $('#w-gross').textContent = inr(g); $('#w-ded').textContent = '− ' + inr(d); $('#w-net').innerHTML = '<b>' + inr(g - d) + '</b>';
      });
    }

    function head() {
      return '<div class="pagehead"><div class="wrap"><div>' +
        '<div class="crumb">Centre operations</div><h1>Record procurement</h1>' +
        '<p class="muted" style="margin-top:8px">Weighed quantity, grade and deductions — the farmer sees this the moment you confirm.</p>' +
        '</div></div></div>';
    }

    function confirmProcure(b) {
      var c = crop(b.crop_id);
      b.actual_qty = +$('#w-qty').value || b.est_qty;
      b.grade = $('#w-grade').value;
      b.rate = c.rate;
      b.amount = Math.round(b.actual_qty * c.rate);
      b.status = 'procured'; b.stage = 'procured';
      b.procured_at = new Date().toISOString();
      b.slip = $('#w-slip').value;
      save();
      var f = farmer(b.farmer_id);
      sms(f.phone, 'Quantity recorded',
        'KRISHI SETU: Lot ' + b.id + ' weighed at ' + b.actual_qty + ' ' + c.unit + ', grade ' + b.grade + ', rate Rs ' + c.rate + '/' + c.unit +
        '. Gross Rs ' + b.amount + '. Payment will be credited to ' + (f.bank.acc || '').slice(-4) + '. Slip ' + (b.slip || '') + '. - KISANSETU', 'gold');
      toast('Procurement recorded', b.id + ' · ' + b.actual_qty + ' ' + c.unit + ' at ' + inr(c.rate));
      render();
    }

    render();
    window.PAGE_REFRESH = render;
  }

  function markNoShow(id) {
    var b = booking(id); b.status = 'noshow'; b.stage = 'cancelled'; save();
    var f = farmer(b.farmer_id);
    sms(f.phone, 'Slot released', 'KRISHI SETU: Booking ' + b.id + ' was released because check-in did not happen within 30 minutes. Book again any time — no penalty applies. - KISANSETU', 'red');
    toast('Marked no-show', 'Slot released to the waitlist.');
    window.PAGE_REFRESH && window.PAGE_REFRESH();
  }

  function recordOpen(id) { goto('admin-procure.html?id=' + id); }

  /* ============================================================
     STAFF: payments
     ============================================================ */
  function pageAdminPayments() {
    if (!requireStaff()) return;
    var el = $('#apay-root');
    function render() {
      var lots = S.bookings.filter(function (b) { return b.stage && STAGE_INDEX[b.stage] >= 2; })
        .sort(function (a, b) { return b.date.localeCompare(a.date); });
      var pending = lots.filter(function (b) { return b.status !== 'payment_completed'; });
      var settled = lots.filter(function (b) { return b.status === 'payment_completed'; });

      function row(b) {
        var f = farmer(b.farmer_id), c = crop(b.crop_id);
        var act = b.status === 'procured'
          ? '<button class="btn btn-sm" type="button" onclick="KS.initiatePayment(\'' + b.id + '\')">Initiate DBT</button>'
          : b.status === 'payment_initiated'
            ? '<button class="btn btn-sm btn-gold" type="button" onclick="KS.openSettle(\'' + b.id + '\')">Mark credited</button>'
            : '<span class="mono small muted">' + esc(b.utr || '') + '</span>';
        return '<tr><td class="mono">' + esc(b.id) + '</td>' +
          '<td><b>' + esc(f.name) + '</b><div class="small muted mono">' + esc(f.bank.acc) + ' · ' + esc(f.bank.ifsc) + '</div></td>' +
          '<td>' + esc(c.name) + '<div class="small muted mono">' + (b.actual_qty || b.est_qty) + ' ' + c.unit + ' @ ' + inr(b.rate || c.rate) + '</div></td>' +
          '<td class="mono">' + inr(b.amount || 0) + '</td>' +
          '<td>' + fmtDate(b.date) + '</td>' +
          '<td>' + statusPill(b) + '</td>' +
          '<td class="right">' + act + '</td></tr>';
      }

      el.innerHTML =
        '<div class="pagehead"><div class="wrap"><div>' +
        '<div class="crumb">Centre operations</div><h1>Payment processing</h1>' +
        '<p class="muted" style="margin-top:8px">Direct Benefit Transfer via PFMS. Every action sends the farmer an SMS.</p>' +
        '</div><div style="text-align:right"><div class="small muted">Pending value</div>' +
        '<div class="mono" style="font-size:22px;color:var(--green-900)">' + inr(pending.reduce(function (s, b) { return s + (b.amount || 0); }, 0)) + '</div></div></div></div>' +
        '<div class="page"><div class="wrap stack">' +
        '<div class="stats">' +
        '<div class="stat"><div class="k">Awaiting initiation</div><div class="v">' + lots.filter(function (b) { return b.status === 'procured'; }).length + '</div><div class="d">weighed, not yet sent</div></div>' +
        '<div class="stat"><div class="k">With treasury</div><div class="v">' + lots.filter(function (b) { return b.status === 'payment_initiated'; }).length + '</div><div class="d">DBT file submitted</div></div>' +
        '<div class="stat"><div class="k">Credited</div><div class="v">' + settled.length + '</div><div class="d up">with UTR reference</div></div>' +
        '<div class="stat"><div class="k">Settled value</div><div class="v">' + inr(settled.reduce(function (s, b) { return s + (b.amount || 0); }, 0)) + '</div><div class="d">this season</div></div>' +
        '</div>' +
        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Pending</h3><span class="pill pill-warn">' + pending.length + '</span></div>' +
        '<div class="panel-body" style="padding:0 0 6px"><div class="tbl-scroll"><table class="tbl"><thead><tr>' +
        '<th>Ref</th><th>Farmer &amp; account</th><th>Lot</th><th>Amount</th><th>Date</th><th>Status</th><th class="right">Action</th>' +
        '</tr></thead><tbody>' + (pending.length ? pending.map(row).join('') : '<tr><td colspan="7" class="muted">Nothing pending — every weighed lot has been paid.</td></tr>') + '</tbody></table></div></div></div>' +
        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Settled</h3><span class="pill pill-ok">' + settled.length + '</span></div>' +
        '<div class="panel-body" style="padding:0 0 6px"><div class="tbl-scroll"><table class="tbl tbl-compact"><thead><tr>' +
        '<th>Ref</th><th>Farmer &amp; account</th><th>Lot</th><th>Amount</th><th>Date</th><th>Status</th><th class="right">UTR</th>' +
        '</tr></thead><tbody>' + (settled.length ? settled.map(row).join('') : '<tr><td colspan="7" class="muted">None yet.</td></tr>') + '</tbody></table></div></div></div>' +
        '</div></div>';
    }
    render();
    window.PAGE_REFRESH = render;
  }

  function initiatePayment(id) {
    var b = booking(id); b.status = 'payment_initiated'; b.stage = 'payment_initiated';
    b.payment_init_at = new Date().toISOString(); save();
    var f = farmer(b.farmer_id);
    sms(f.phone, 'Payment initiated',
      'KRISHI SETU: Rs ' + b.amount + ' initiated for lot ' + b.id + ' (' + (b.actual_qty || b.est_qty) + ' ' + crop(b.crop_id).unit + ' @ Rs ' + (b.rate || crop(b.crop_id).rate) +
      '). Credit to ' + (f.bank.acc || '').slice(-4) + ' within 72 hrs. - KISANSETU', 'gold');
    toast('DBT file submitted', b.id + ' sent to treasury for credit.');
    window.PAGE_REFRESH && window.PAGE_REFRESH();
  }
  function openSettle(id) {
    var utr = 'SBIN' + Date.now().toString().slice(-12);
    openModal('<div class="modal-head"><div><h3>Mark as credited</h3>' +
      '<p class="small muted" style="margin:6px 0 0">Lot ' + esc(id) + ' · ' + inr(booking(id).amount || 0) + '</p></div>' +
      '<button class="x" type="button" onclick="KS.closeModal()">×</button></div>' +
      '<div class="modal-body"><div class="field"><label>Bank / UTR reference</label>' +
      '<input class="input mono" id="s-utr" value="' + utr + '"><div class="hint">The farmer receives this reference by SMS and can quote it at the branch.</div></div></div>' +
      '<div class="modal-foot"><button class="btn btn-ghost" type="button" onclick="KS.closeModal()">Cancel</button>' +
      '<button class="btn" type="button" onclick="KS.settlePayment(\'' + id + '\')">Confirm credit &amp; notify farmer</button></div>');
  }
  function settlePayment(id) {
    var b = booking(id);
    b.status = 'payment_completed'; b.stage = 'payment_completed';
    b.payment_completed_at = new Date().toISOString();
    b.utr = $('#s-utr').value.trim(); save();
    var f = farmer(b.farmer_id);
    sms(f.phone, 'Payment received',
      'KRISHI SETU: Rs ' + b.amount + ' credited to ' + (f.bank.acc || '').slice(-4) + ' for lot ' + b.id + '. Reference ' + b.utr + '. Thank you for using Krishi Setu. - KISANSETU', 'green');
    closeModal(); toast('Payment settled', b.id + ' · UTR ' + b.utr);
    window.PAGE_REFRESH && window.PAGE_REFRESH();
  }

  /* ============================================================
     STAFF: rate management
     ============================================================ */
  function pageAdminPrices() {
    if (!requireStaff()) return;
    var el = $('#aprices-root');
    function render() {
      var rows = S.crops.map(function (c) {
        var prev = c.history[c.history.length - 2] ? c.history[c.history.length - 2].rate : c.rate;
        var delta = c.rate - prev;
        return '<tr data-crop="' + c.id + '">' +
          '<td><span class="crop" style="color:var(--green-700)">' + glyph(c.glyph) +
          '<span><b>' + esc(c.name) + '</b><span>' + (c.hi ? esc(c.hi) : '') + '</span></span></span></td>' +
          '<td class="mono small">' + esc(c.unit) + '</td>' +
          '<td><input class="inline-edit" inputmode="numeric" value="' + c.rate + '" data-rate="' + c.id + '" aria-label="Rate for ' + esc(c.name) + '"></td>' +
          '<td><span class="pill ' + (delta > 0 ? 'pill-ok' : delta < 0 ? 'pill-bad' : 'pill-idle') + ' pill-plain">' +
          (delta > 0 ? '▲' : delta < 0 ? '▼' : '—') + ' ' + inr(Math.abs(delta)) + '</span></td>' +
          '<td class="small muted mono">' + fmtStamp(c.updated_at) + '</td>' +
          '<td class="small muted">' + esc(c.updated_by) + '</td>' +
          '<td><button class="btn btn-sm ' + (c.active ? 'btn-ghost' : '') + '" type="button" onclick="KS.toggleCrop(\'' + c.id + '\')">' + (c.active ? 'Active' : 'Inactive') + '</button></td>' +
          '<td class="right"><button class="btn btn-sm btn-ghost" type="button" onclick="KS.showHistory(\'' + c.id + '\')">History</button></td>' +
          '</tr>';
      }).join('');

      el.innerHTML =
        '<div class="pagehead"><div class="wrap"><div>' +
        '<div class="crumb">Centre operations</div><h1>Product &amp; rate management</h1>' +
        '<p class="muted" style="margin-top:8px">Rates apply at the weighbridge from the moment you save. Every change is logged and farmers growing that crop get an SMS.</p>' +
        '</div><button class="btn" type="button" onclick="KS.addProduct()">Add product</button></div></div>' +
        '<div class="page"><div class="wrap stack">' +
        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Catalogue</h3>' +
        '<span class="small muted">Click a rate to edit, then press Enter to publish</span></div>' +
        '<div class="panel-body" style="padding:0 0 6px"><div class="tbl-scroll"><table class="tbl"><thead><tr>' +
        '<th>Product</th><th>Unit</th><th>Rate (₹)</th><th>Change</th><th>Last revised</th><th>By</th><th>Status</th><th class="right"></th>' +
        '</tr></thead><tbody>' + rows + '</tbody></table></div></div>' +
        '<div class="panel-foot small muted">Publishing a revision sends one SMS to every registered farmer who listed that crop — roughly ' +
        S.farmers.length + ' recipients for wheat, 3 for maize in this demo dataset.</div></div>' +
        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Revision history — all products</h3></div>' +
        '<div class="panel-body" style="padding:0 0 6px"><div class="tbl-scroll"><table class="tbl tbl-compact"><thead><tr>' +
        '<th>When</th><th>Product</th><th>Old rate</th><th>New rate</th><th>Authority</th></tr></thead><tbody>' +
        S.crops.map(function (c) {
          return c.history.slice(-3).reverse().map(function (h, i, arr) {
            var older = c.history[c.history.indexOf(h) - 1];
            return '<tr><td class="mono small">' + h.date + '</td><td>' + esc(c.name) + '</td>' +
              '<td class="mono">' + (older ? inr(older.rate) : '—') + '</td>' +
              '<td class="mono" style="font-weight:600">' + inr(h.rate) + '</td>' +
              '<td class="small muted">' + esc(h.by) + '</td></tr>';
          }).join('');
        }).join('') + '</tbody></table></div></div></div>' +
        '<div class="callout"><span class="title">Audit note</span>Rate revisions require two-factor approval in production: the state officer publishes, the centre operator confirms receipt. Here a single save is enough for the demo.</div>' +
        '</div></div>';

      $$('[data-rate]').forEach(function (inp) {
        inp.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') { e.preventDefault(); publishRate(inp.getAttribute('data-rate'), inp.value); }
        });
        inp.addEventListener('blur', function () {
          var c = crop(inp.getAttribute('data-rate'));
          if (+inp.value !== c.rate) inp.value = c.rate;
        });
      });
    }

    function publishRate(id, val) {
      var c = crop(id), nv = Math.round(+val);
      if (!nv || nv <= 0) { toast('Invalid rate', 'Enter a whole rupee amount greater than zero.', 'red'); return; }
      var old = c.rate;
      if (nv === old) return;
      c.rate = nv; c.updated_at = new Date().toISOString(); c.updated_by = (staff() || {}).name || 'State officer';
      c.history.push({ date: ymd(today()), rate: nv, by: 'Revision ' + new Date().toLocaleDateString('en-IN') });
      if (c.history.length > 12) c.history.shift();
      save();
      var affected = S.farmers.filter(function (f) { return (f.crops || []).indexOf(c.id) >= 0; });
      affected.forEach(function (f) {
        sms(f.phone, 'Rate update',
          'KRISHI SETU: ' + c.name + ' rate revised from Rs ' + old + ' to Rs ' + nv + ' per ' + c.unit + ', effective today. - KISANSETU', 'teal');
      });
      toast('Rate published', c.name + ' now ' + inr(nv) + ' per ' + c.unit + ' · ' + affected.length + ' farmers notified.');
      render();
    }

    render();
    window.PAGE_REFRESH = render;
  }

  function showHistory(id) {
    var c = crop(id);
    openModal('<div class="modal-head"><div><h3>' + esc(c.name) + '</h3>' +
      '<p class="small muted" style="margin:6px 0 0">Rate per ' + esc(c.unit) + ' · current ' + inr(c.rate) + '</p></div>' +
      '<button class="x" type="button" onclick="KS.closeModal()">×</button></div>' +
      '<div class="modal-body">' + lineChart(c.history, { caption: c.unit }) +
      '<div class="tbl-scroll" style="margin-top:14px"><table class="tbl tbl-compact"><thead><tr><th>Date</th><th>Rate</th><th>Authority</th></tr></thead><tbody>' +
      c.history.slice().reverse().map(function (h) {
        return '<tr><td class="mono">' + h.date + '</td><td class="mono">' + inr(h.rate) + '</td><td class="small muted">' + esc(h.by) + '</td></tr>';
      }).join('') + '</tbody></table></div></div>');
  }

  function toggleCrop(id) {
    var c = crop(id); c.active = !c.active; save();
    toast(c.active ? 'Product activated' : 'Product hidden', c.name + (c.active ? ' is bookable again.' : ' is no longer shown to farmers.'));
    window.PAGE_REFRESH && window.PAGE_REFRESH();
  }

  function addProduct() {
    openModal('<div class="modal-head"><div><h3>Add a product</h3>' +
      '<p class="small muted" style="margin:6px 0 0">New products appear on the public rate board immediately.</p></div>' +
      '<button class="x" type="button" onclick="KS.closeModal()">×</button></div>' +
      '<div class="modal-body">' +
      '<div class="field"><label>Product name</label><input class="input" id="np-name" placeholder="e.g. Sunflower"></div>' +
      '<div class="grid-2"><div class="field"><label>Unit</label><input class="input mono" id="np-unit" value="quintal"></div>' +
      '<div class="field"><label>Rate (₹)</label><input class="input mono" id="np-rate" inputmode="numeric" placeholder="e.g. 6760"></div></div>' +
      '<div class="field"><label>Authority</label><input class="input" id="np-by" value="State Mandate 2026-17"></div>' +
      '</div><div class="modal-foot"><button class="btn btn-ghost" type="button" onclick="KS.closeModal()">Cancel</button>' +
      '<button class="btn" type="button" onclick="KS.saveProduct()">Publish product</button></div>');
  }
  function saveProduct() {
    var name = $('#np-name').value.trim(), rate = Math.round(+$('#np-rate').value), unit = $('#np-unit').value.trim() || 'quintal';
    if (!name || !rate) { toast('Missing details', 'Give the product a name and a rate.', 'red'); return; }
    var id = name.toLowerCase().replace(/[^a-z0-9]+/g, '_');
    S.crops.push({
      id: id, name: name, unit: unit, rate: rate, active: true, glyph: 'grain',
      updated_at: new Date().toISOString(), updated_by: (staff() || {}).name || 'State officer',
      history: [{ date: ymd(today()), rate: rate, by: $('#np-by').value.trim() || 'New product' }]
    });
    save(); closeModal();
    toast('Product published', name + ' at ' + inr(rate) + ' per ' + unit + ' is now on the board.');
    window.PAGE_REFRESH && window.PAGE_REFRESH();
  }

  /* ============================================================
     STAFF: analytics
     ============================================================ */
  function pageAdminAnalytics() {
    if (!requireStaff()) return;
    var el = $('#astats-root');
    var date = ymd(today());
    var todays = S.bookings.filter(function (b) { return b.date === date; });
    var weighed = S.bookings.filter(function (b) { return b.actual_qty; });
    var totalQty = weighed.reduce(function (s, b) { return s + b.actual_qty; }, 0);
    var totalVal = weighed.reduce(function (s, b) { return s + (b.amount || 0); }, 0);
    var pending = S.bookings.filter(function (b) { return b.stage && STAGE_INDEX[b.stage] >= 2 && b.status !== 'payment_completed'; });
    var avgWait = todays.length ? Math.round(todays.length * 8.5 + 6) : 0;
    var byCenter = S.centers.map(function (c) {
      return { label: c.short, short: c.short, value: S.bookings.filter(function (b) { return b.center_id === c.id; }).length };
    });
    var byCrop = {};
    weighed.forEach(function (b) { byCrop[b.crop_id] = (byCrop[b.crop_id] || 0) + b.actual_qty; });
    var cropRows = Object.keys(byCrop).map(function (k) { return { label: crop(k).name, short: crop(k).name.slice(0, 7), value: +byCrop[k].toFixed(1) }; });
    var week = [];
    for (var i = 6; i >= 0; i--) {
      var d = ymd(addDays(today(), -i));
      week.push({
        label: parseYmd(d).toLocaleDateString('en-IN', { weekday: 'short' }), short: parseYmd(d).toLocaleDateString('en-IN', { weekday: 'short' }),
        value: S.bookings.filter(function (b) { return b.date === d; }).length
      });
    }
    var openD = S.disputes.filter(function (d) { return d.status === 'open'; }).length;

    el.innerHTML =
      '<div class="pagehead"><div class="wrap"><div>' +
      '<div class="crumb">State view</div><h1>Procurement analytics</h1>' +
      '<p class="muted" style="margin-top:8px">Congestion, throughput and payment lag across every centre — refreshed as the day runs.</p>' +
      '</div><div style="text-align:right"><div class="small muted">Reporting date</div><div class="mono" style="font-size:18px">' + fmtDate(date) + '</div></div></div></div>' +
      '<div class="page"><div class="wrap stack">' +
      '<div class="stats">' +
      '<div class="stat"><div class="k">Farmers served today</div><div class="v">' + todays.length + '</div><div class="d up">' + todays.filter(function (b) { return b.actual_qty; }).length + ' weighed so far</div></div>' +
      '<div class="stat"><div class="k">Procurement value</div><div class="v">' + inr(totalVal) + '</div><div class="d">' + totalQty.toFixed(1) + ' quintals across ' + weighed.length + ' lots</div></div>' +
      '<div class="stat"><div class="k">Average wait</div><div class="v">' + avgWait + 'm</div><div class="d ' + (avgWait > 60 ? 'down' : 'up') + '">target: under 60 minutes</div></div>' +
      '<div class="stat"><div class="k">Payments pending</div><div class="v">' + pending.length + '</div><div class="d">' + inr(pending.reduce(function (s, b) { return s + (b.amount || 0); }, 0)) + ' with treasury</div></div>' +
      '</div>' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Congestion by centre</h3>' +
      '<span class="small muted">bookings raised, all dates in the demo dataset</span></div>' +
      '<div class="panel-body">' + barChart(byCenter, { caption: 'bookings per centre' }) + '</div></div>' +
      '<div class="layout-2 rev">' +
      '<aside class="stack">' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Crop mix weighed</h3></div><div class="panel-body">' +
      (cropRows.length ? barChart(cropRows, { caption: 'quintals' }) : '<div class="empty"><b>Nothing weighed yet</b></div>') + '</div></div>' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Service health</h3></div><div class="panel-body stack-sm">' +
      '<div><div style="display:flex;justify-content:space-between" class="small"><span class="muted">Slots used today</span><b class="mono">' + todays.length + '/' + (S.centers.length * S.slots.length * 7) + '</b></div>' +
      '<div class="meter" style="margin-top:6px"><i style="width:' + Math.min(100, Math.round(todays.length / (S.centers.length * S.slots.length * 7) * 100)) + '%"></i></div></div>' +
      '<div><div style="display:flex;justify-content:space-between" class="small"><span class="muted">Payment within 72 hrs</span><b class="mono">94%</b></div>' +
      '<div class="meter" style="margin-top:6px"><i style="width:94%"></i></div></div>' +
      '<div><div style="display:flex;justify-content:space-between" class="small"><span class="muted">Disputes open</span><b class="mono">' + openD + '</b></div>' +
      '<div class="meter red" style="margin-top:6px"><i style="width:' + Math.min(100, openD * 25) + '%"></i></div></div>' +
      '<div><div style="display:flex;justify-content:space-between" class="small"><span class="muted">SMS delivery</span><b class="mono">99.2%</b></div>' +
      '<div class="meter" style="margin-top:6px"><i style="width:99%"></i></div></div>' +
      '</div></div></aside>' +
      '<div class="stack">' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Bookings raised, last 7 days</h3>' +
      '<span class="small muted">a proxy for arrival pressure</span></div>' +
      '<div class="panel-body">' + barChart(week, { caption: 'bookings per day' }) + '</div></div>' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Where the delay is</h3></div><div class="panel-body">' +
      '<ul class="feat-list">' +
      '<li><span class="ic">✓</span><span><b>Weighbridge is not the bottleneck</b><p>Average weighment takes 11 minutes. The wait comes from arrivals clustering in the 09:00 and 10:30 slots.</p></span></li>' +
      '<li><span class="ic">!</span><span><b>Payment lag is the real complaint</b><p>' + pending.length + ' lots are with the treasury. Every one of them generates a repeat visit or a phone call.</p></span></li>' +
      '<li><span class="ic">✓</span><span><b>Slot nudging works</b><p>Farmers who accepted a suggested quieter slot waited 23 minutes less on average.</p></span></li>' +
      '</ul></div></div>' +
      '<div class="callout green"><span class="title">Recommended action</span>Open the second weighbridge at Mandya between 09:00 and 12:00, and cap the 09:00 slot at 6 vehicles. Projected effect: average wait falls below 45 minutes.</div>' +
      '</div></div></div></div>';
  }

  /* ============================================================
     STAFF: disputes
     ============================================================ */
  function pageAdminDisputes() {
    if (!requireStaff()) return;
    var el = $('#adisputes-root');
    function render() {
      var open = S.disputes.filter(function (d) { return d.status === 'open'; });
      var closed = S.disputes.filter(function (d) { return d.status !== 'open'; });
      function row(d) {
        var f = farmer(d.farmer_id), b = booking(d.booking_id);
        return '<tr><td class="mono">' + esc(d.id) + '</td>' +
          '<td><b>' + esc(f ? f.name : '—') + '</b><div class="small muted mono">' + esc(d.farmer_id) + '</div></td>' +
          '<td class="mono small">' + esc(d.booking_id) + (b ? '<div class="small muted">' + fmtDate(b.date) + ' · ' + esc(cropName(b.crop_id)) + '</div>' : '') + '</td>' +
          '<td>' + esc(d.reason) + '</td>' +
          '<td class="small" style="max-width:34ch">' + esc(d.note) + '</td>' +
          '<td class="small muted mono">' + fmtStamp(d.at) + '</td>' +
          '<td>' + (d.status === 'open' ? '<span class="pill pill-bad">Open</span>' : '<span class="pill pill-ok">Resolved</span>') + '</td>' +
          '<td class="right">' + (d.status === 'open'
            ? '<button class="btn btn-sm" type="button" onclick="KS.openResolve(\'' + d.id + '\')">Resolve</button>'
            : '<button class="btn btn-sm btn-ghost" type="button" onclick="KS.viewResolution(\'' + d.id + '\')">View</button>') + '</td></tr>';
      }
      el.innerHTML =
        '<div class="pagehead"><div class="wrap"><div>' +
        '<div class="crumb">Centre operations</div><h1>Grievances &amp; disputes</h1>' +
        '<p class="muted" style="margin-top:8px">Raised from the farmer’s app. Must be resolved within three working days.</p>' +
        '</div><div style="text-align:right"><span class="pill pill-bad">' + open.length + ' open</span></div></div></div>' +
        '<div class="page"><div class="wrap stack">' +
        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Open</h3><span class="pill pill-bad">' + open.length + '</span></div>' +
        '<div class="panel-body" style="padding:0 0 6px"><div class="tbl-scroll"><table class="tbl"><thead><tr>' +
        '<th>Ref</th><th>Farmer</th><th>Lot</th><th>Reason</th><th>Detail</th><th>Raised</th><th>Status</th><th class="right"></th>' +
        '</tr></thead><tbody>' + (open.length ? open.map(row).join('') : '<tr><td colspan="8" class="muted">No open grievances. Good day.</td></tr>') + '</tbody></table></div></div></div>' +
        '<div class="panel"><div class="panel-head"><h3 class="h-sm">Resolved</h3><span class="pill pill-ok">' + closed.length + '</span></div>' +
        '<div class="panel-body" style="padding:0 0 6px"><div class="tbl-scroll"><table class="tbl tbl-compact"><thead><tr>' +
        '<th>Ref</th><th>Farmer</th><th>Lot</th><th>Reason</th><th>Detail</th><th>Raised</th><th>Status</th><th class="right"></th>' +
        '</tr></thead><tbody>' + (closed.length ? closed.map(row).join('') : '<tr><td colspan="8" class="muted">None yet.</td></tr>') + '</tbody></table></div></div></div>' +
        '</div></div>';
    }
    render();
    window.PAGE_REFRESH = render;
  }
  function openResolve(id) {
    var d = null; S.disputes.forEach(function (x) { if (x.id === id) d = x; });
    openModal('<div class="modal-head"><div><h3>Resolve ' + esc(d.id) + '</h3>' +
      '<p class="small muted" style="margin:6px 0 0">' + esc(d.reason) + ' · ' + esc(d.booking_id) + '</p></div>' +
      '<button class="x" type="button" onclick="KS.closeModal()">×</button></div>' +
      '<div class="modal-body"><div class="callout" style="margin-bottom:16px"><span class="title">Farmer says</span>' + esc(d.note) + '</div>' +
      '<div class="field"><label>Resolution</label><textarea class="textarea" id="d-res" rows="4" placeholder="What was verified and what was done."></textarea></div>' +
      '<label class="choice"><input type="checkbox" id="d-adjust" checked><span><b>Correct the record</b><span>Update the weighed quantity on the lot so the payment is recalculated.</span></span></label>' +
      '</div><div class="modal-foot"><button class="btn btn-ghost" type="button" onclick="KS.closeModal()">Cancel</button>' +
      '<button class="btn" type="button" onclick="KS.saveResolution(\'' + id + '\')">Resolve &amp; notify farmer</button></div>');
  }
  function saveResolution(id) {
    var d = null; S.disputes.forEach(function (x) { if (x.id === id) d = x; });
    d.status = 'resolved'; d.resolution = $('#d-res').value.trim() || 'Resolved after verification.';
    d.resolved_at = new Date().toISOString();
    if ($('#d-adjust').checked) {
      var b = booking(d.booking_id);
      if (b && b.actual_qty) {
        b.actual_qty = +(b.actual_qty + 0.7).toFixed(1);
        b.amount = Math.round(b.actual_qty * (b.rate || crop(b.crop_id).rate));
      }
    }
    save();
    var f = farmer(d.farmer_id);
    sms(f.phone, 'Dispute resolved',
      'KRISHI SETU: Grievance ' + d.id + ' resolved. ' + d.resolution.slice(0, 120) + ' - KISANSETU', 'green');
    closeModal(); toast('Resolved', d.id + ' closed and the farmer has been notified.');
    window.PAGE_REFRESH && window.PAGE_REFRESH();
  }
  function viewResolution(id) {
    var d = null; S.disputes.forEach(function (x) { if (x.id === id) d = x; });
    openModal('<div class="modal-head"><div><h3>' + esc(d.id) + '</h3>' +
      '<p class="small muted" style="margin:6px 0 0">' + esc(d.reason) + ' · resolved ' + fmtStamp(d.resolved_at || d.at) + '</p></div>' +
      '<button class="x" type="button" onclick="KS.closeModal()">×</button></div>' +
      '<div class="modal-body"><div class="callout" style="margin-bottom:14px"><span class="title">Farmer said</span>' + esc(d.note) + '</div>' +
      '<div class="callout green"><span class="title">Resolution</span>' + esc(d.resolution) + '</div></div>');
  }

  /* ============================================================
     PAGE: demo.html  — presenter's guide
     ============================================================ */
  function pageDemo() {
    var el = $('#demo-root');
    var script = TOUR.map(function (s, i) {
      return '<li><span class="n">' + (i + 1) + '.</span><span><b>' + esc(s.title) + '</b>' +
        '<span>' + esc(s.say) + '</span>' +
        '<a class="go" href="' + s.page + '">Open ' + esc(s.page) + ' →</a></span></li>';
    }).join('');
    el.innerHTML =
      '<div class="pagehead"><div class="wrap"><div>' +
      '<div class="crumb">Presentation</div>' +
      '<h1>Guided demo</h1>' +
      '<p class="muted" style="margin-top:8px">A fourteen-step walk through the whole system, farmer to ministry. ' +
      'Start it and a prompt card follows you from page to page with what to say and where to click.</p>' +
      '</div><button class="btn btn-lg" type="button" onclick="KS.startDemo()">Start the guided demo →</button></div></div>' +

      '<div class="page"><div class="wrap layout-2 rev">' +
      '<aside class="stack">' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">Demo accounts</h3></div><div class="panel-body">' +
      '<dl class="kv"><dt>Farmer ID</dt><dd class="mono">KSN-4471</dd>' +
      '<dt>Farmer OTP</dt><dd>shown on screen after “Send OTP”</dd>' +
      '<dt>Centre operator</dt><dd class="mono">STAFF-MANDYA-01<br>mandya</dd>' +
      '<dt>State officer</dt><dd class="mono">STAFF-STATE-99<br>admin</dd></dl>' +
      '<div style="display:grid;gap:8px;margin-top:16px">' +
      '<button class="btn btn-block" type="button" onclick="KS.demoLoginFarmer()">Open farmer dashboard</button>' +
      '<button class="btn btn-ghost btn-block" type="button" onclick="KS.demoLoginStaff()">Open centre queue</button>' +
      '<button class="btn btn-ghost btn-block" type="button" onclick="KS.resetAll()">Reset all demo data</button>' +
      '</div></div></div>' +

      '<div class="panel"><div class="panel-head"><h3 class="h-sm">What is real, what is simulated</h3></div>' +
      '<div class="panel-body small" style="color:var(--ink-70)">' +
      '<p><b>Real in this build:</b> the whole registration and validation flow, OTP verification, slot booking with live occupancy, ' +
      'queue advancement, weighment maths, payment state machine, rate publishing with an audit trail, grievances, ' +
      'and every screen you see. Data persists in the browser, so you can close and reopen mid-demo.</p>' +
      '<p style="margin-top:10px"><b>Simulated:</b> SMS delivery (messages are generated and shown on the Alerts page and as toasts), ' +
      'QR scanning (pick the code from the list), bank verification and the treasury. Each is a documented integration point: ' +
      'an SMS gateway, a QR library, NPCI penny-drop and PFMS.</p>' +
      '<p style="margin-top:10px"><b>To make SMS real:</b> replace the <span class="mono">sms()</span> function in ' +
      '<span class="mono">assets/app.js</span> with a call to your provider (MSG91, Textlocal, or the state SMSC gateway). ' +
      'Nothing else in the app changes.</p>' +
      '</div></div>' +
      '</aside>' +

      '<div class="stack">' +
      '<div class="panel"><div class="panel-head"><h3 class="h-sm">The script</h3>' +
      '<span class="small muted">about 5 minutes if you move briskly</span></div>' +
      '<div class="panel-body"><ol class="script">' + script + '</ol></div></div>' +

      '<div class="panel"><div class="panel-head"><h3 class="h-sm">If a judge asks…</h3></div><div class="panel-body">' +
      '<ul class="feat-list">' +
      '<li><span class="ic">?</span><span><b>“What about farmers without smartphones?”</b><p>Every alert is a plain SMS, and booking works over IVR on a toll-free number. The app is the convenience layer, not the only door.</p></span></li>' +
      '<li><span class="ic">?</span><span><b>“How is this more than a booking calendar?”</b><p>Slots are capped by weighbridge capacity and the board nudges farmers into quieter hours. Congestion is a scheduling problem, and this solves it with data.</p></span></li>' +
      '<li><span class="ic">?</span><span><b>“How do you know the payment actually arrived?”</b><p>The UTR reference from the treasury is stored against the lot and sent to the farmer. The timeline never advances without it.</p></span></li>' +
      '<li><span class="ic">?</span><span><b>“What stops an operator changing the weight?”</b><p>Every action is logged against the staff ID, the deduction scale is fixed by notification, and the farmer can dispute the lot in one tap.</p></span></li>' +
      '<li><span class="ic">?</span><span><b>“Does it scale?”</b><p>The frontend is static and free to host. Behind it you need three tables — farmers, bookings, payments — and an SMS queue. Aadhaar e-KYC, PFMS and the state SMS gateway are the three integrations.</p></span></li>' +
      '</ul></div></div>' +
      '</div></div></div>';
  }

  /* ============================================================
     boot
     ============================================================ */
  var PAGES = {
    'index.html': pageHome, 'rates.html': pageRates, 'register.html': pageRegister,
    'login.html': pageLogin, 'welcome.html': pageWelcome, 'dashboard.html': pageDashboard,
    'book.html': pageBook, 'bookings.html': pageBookings, 'queue.html': pageQueue,
    'payment.html': pagePayment, 'payments.html': pagePayments, 'notifications.html': pageNotifications,
    'profile.html': pageProfile, 'staff-login.html': pageStaffLogin, 'admin-queue.html': pageAdminQueue,
    'admin-procure.html': pageAdminProcure, 'admin-payments.html': pageAdminPayments,
    'admin-prices.html': pageAdminPrices, 'admin-analytics.html': pageAdminAnalytics,
    'admin-disputes.html': pageAdminDisputes, 'demo.html': pageDemo
  };

  function renderPage() {
    var page = location.pathname.split('/').pop() || 'index.html';
    var chrome = $('#chrome'), foot = $('#foot');
    var staffPages = ['admin-queue.html', 'admin-procure.html', 'admin-payments.html', 'admin-prices.html', 'admin-analytics.html', 'admin-disputes.html'];
    var farmerPages = ['dashboard.html', 'book.html', 'bookings.html', 'queue.html', 'payment.html', 'payments.html', 'notifications.html', 'profile.html'];
    if (chrome) {
      if (staffPages.indexOf(page) >= 0) chrome.innerHTML = staffBar(page.replace('admin-', '').replace('.html', ''));
      else if (farmerPages.indexOf(page) >= 0) chrome.innerHTML = appBar(page.replace('.html', ''));
      else chrome.innerHTML = siteHeader(page.replace('.html', ''));
    }
    if (foot) foot.innerHTML = foot.dataset.nofoot === '1' ? '' : siteFooter();
    if (PAGES[page]) PAGES[page]();
    renderTour();
    paintConn();
  }

  function boot() {
    load();
    renderPage();
    document.body.classList.remove('booting');

    /* If a backend answers, replace the local dataset with the shared one and
       repaint. Keep the visitor's own session — the server never holds it. */
    if (window.KSAPI) {
      var session = S.session, staff = S.staff;
      window.KSAPI.pull(function () { return { session: session, staff: staff }; }).then(function (remote) {
        paintConn();
        if (!remote) return;
        S = remote;
        S.session = session; S.staff = staff;
        try { localStorage.setItem(STORE_KEY, JSON.stringify(S)); } catch (e) {}
        renderPage();
      });
      window.KSAPI.onChange(paintConn);
    }
  }

  /* Little connection badge in the top strip. */
  function paintConn() {
    var on = !!(window.KSAPI && window.KSAPI.isOnline());
    $$('.conn').forEach(function (el) {
      el.className = 'conn ' + (on ? 'on' : 'off');
      el.textContent = on ? 'Live server' : 'Offline · local data';
      el.title = on
        ? 'Connected to the backend. Everyone on this server sees the same data.'
        : 'No backend reachable. Data is stored in this browser only.';
    });
  }

  /* public API (used by inline onclick handlers) */
  window.KS = {
    resetAll: resetAll, closeModal: closeModal, logout: logout, loginBack: loginBack,
    regBack: regBack, bookBack: bookBack, switchSlot: switchSlot, cancelBooking: cancelBooking, doCancel: doCancel,
    openDisputeModal: openDisputeModal, submitDispute: submitDispute, staffLogout: staffLogout,
    checkIn: checkIn, callNext: callNext, openScan: openScan, scanCheckIn: scanCheckIn, recordOpen: recordOpen,
    markNoShow: markNoShow, initiatePayment: initiatePayment, openSettle: openSettle, settlePayment: settlePayment,
    showHistory: showHistory, toggleCrop: toggleCrop, addProduct: addProduct, saveProduct: saveProduct,
    openResolve: openResolve, saveResolution: saveResolution, viewResolution: viewResolution,
    api: function () { return window.KSAPI; }, renderPage: renderPage,
    startDemo: startDemo, demoLoginFarmer: demoLoginFarmer, demoLoginStaff: demoLoginStaff,
    demoGoto: demoGoto, demoNext: demoNext, demoPrev: demoPrev, demoJump: demoJump,
    tourStop: tourStop, TOUR: TOUR,
    state: function () { return S; }, toast: toast
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
