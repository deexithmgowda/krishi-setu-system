# Krishi Setu — farmer procurement & slot booking (prototype)

A classic, print-inspired web prototype for MSP procurement: farmers register,
book a weighment slot, watch a live queue, and follow the payment to their bank
account. Centres run check-in, weighment, DBT payments, rate revisions,
analytics and grievance handling.

## Run it

**Frontend only** (data stays in each browser, fine for a single-screen demo):
open `index.html`, or `python3 -m http.server 8000`.

**With the backend** (shared data — two phones see the same queue):

    node server/index.js      → http://localhost:3000

Zero dependencies, nothing to install. Node 18+ only. The badge in the top
bar reads **Live server** when the backend answers and **Offline · local
data** when it does not. See `BACKEND.txt`.

## Files

    index.html               landing page + public rate board
    rates.html               today's rates, per centre
    register.html            5-step registration (identity, address, land, bank, OTP)
    login.html               farmer ID + OTP
    welcome.html             farmer ID issued
    dashboard.html           upcoming slot, money trail, rate watch, alerts
    book.html                centre > crop > quantity > date/time (with load nudging)
    bookings.html            all lots
    queue.html               live position, estimated wait, booking QR
    payment.html             5-stage timeline + the quantity x rate calculation
    payments.html            every lot and where its money is
    notifications.html       copy of every SMS sent
    profile.html             identity, land, bank (OTP on bank change), language
    demo.html                presenter's guide: 14-step script + one-click logins
    staff-login.html         staff sign-in
    admin-queue.html         live board, QR check-in, call next
    admin-procure.html       weighment slip: quantity, grade, deductions, net
    admin-payments.html      initiate DBT, mark credited, UTR reference
    admin-prices.html        rate revisions, history chart, add/hide products
    admin-analytics.html     congestion, throughput, payment lag, service health
    admin-disputes.html      grievance queue and resolution
    assets/style.css         the whole design system
    assets/api.js            bridge to the backend, with offline fallback
    assets/app.js            state, flows, demo data, charts, QR
    server/index.js          the backend: HTTP API + static hosting, no deps
    server/data/store.json   the dataset (created on first run)
    BACKEND.txt              how to run, deploy and extend the backend

## Presenting it

Open `demo.html` and press **Start the guided demo**. A prompt card follows
you through 14 steps with what to say and where to click, and starting the
demo signs you in as both the farmer and the centre operator with a clean
dataset. Press the X on the card to end it.

## Demo accounts

    Farmer:  KSN-4471            (OTP shown on screen)
    Staff:   STAFF-MANDYA-01 / mandya    (centre operator)
    Staff:   STAFF-STATE-99  / admin     (state officer)

"Reset demo" in the top bar restores the sample dataset.

## Notes for going to production

* The backend stores the whole dataset in `server/data/store.json` with
  atomic writes. Swap `loadStore()` / `persistNow()` for Postgres and
  nothing else changes.
* SMS is simulated and rendered on the Notifications page — connect an
  SMS provider (MSG91, Textlocal, or the state SMSC gateway).
* `qrSvg()` draws a demo code — swap for a real QR encoder before scanning.
* Interface is English only.
* Bank details are format-validated only; production needs an NPCI penny-drop
  verification step.
