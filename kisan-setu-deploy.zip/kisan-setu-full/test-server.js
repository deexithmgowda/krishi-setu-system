/* Backend integration test.
   Spawns the REAL server (server/index.js) on a free port, hits its HTTP API,
   and then loads the real frontend against it inside jsdom to prove the
   browser and the server agree. */
const fs = require('fs');
const path = require('path');
const net = require('net');
const { spawn } = require('child_process');
const { JSDOM, VirtualConsole } = require('jsdom');

// works whether the tests sit beside the app (combined folder)
// or one level above it (kisan-setu/ sub-folder)
const ROOT = fs.existsSync(path.join(__dirname, 'assets/app.js'))
  ? __dirname
  : path.join(__dirname, 'kisan-setu');
const API = fs.readFileSync(path.join(ROOT, 'assets/api.js'), 'utf8');
const APP = fs.readFileSync(path.join(ROOT, 'assets/app.js'), 'utf8');
const STORE = path.join(ROOT, 'server/data/store.json');

let failures = 0; const fails = [];
function check(name, cond, extra) {
  if (cond) console.log('  ok   ' + name);
  else { failures++; fails.push(name + (extra ? ' — ' + extra : '')); console.log('  FAIL ' + name + (extra ? ' — ' + extra : '')); }
}

function freePort() {
  return new Promise(res => {
    const s = net.createServer();
    s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => res(p)); });
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function api(base, method, url, body) {
  const r = await fetch(base + url, {
    method, headers: body ? { 'content-type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined
  });
  const text = await r.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (e) {}
  return { status: r.status, data, text };
}

(async () => {
  // start from a clean dataset so the test is deterministic
  if (fs.existsSync(STORE)) fs.unlinkSync(STORE);

  const port = await freePort();
  const base = 'http://127.0.0.1:' + port;
  const child = spawn(process.execPath, [path.join(ROOT, 'server/index.js')], {
    env: Object.assign({}, process.env, { PORT: String(port), HOST: '127.0.0.1' }),
    stdio: ['ignore', 'pipe', 'pipe']
  });
  const logs = [];
  child.stdout.on('data', d => logs.push(String(d)));
  child.stderr.on('data', d => logs.push('[err] ' + String(d)));

  // wait for it to listen
  let up = false;
  for (let i = 0; i < 60; i++) {
    try { const h = await api(base, 'GET', '/api/health'); if (h.status === 200) { up = true; break; } } catch (e) {}
    await sleep(150);
  }
  check('server boots and answers /api/health', up, logs.join('').slice(0, 300));
  if (!up) { child.kill(); process.exit(1); }

  console.log('\n== api ==');
  const health = await api(base, 'GET', '/api/health');
  check('health reports simulated SMS by default', health.data.sms === 'simulated', JSON.stringify(health.data));

  const st = await api(base, 'GET', '/api/state');
  check('GET /api/state returns the seeded dataset',
    st.status === 200 && st.data.farmers.length === 7 && st.data.crops.length === 10 && st.data.bookings.length === 9,
    'farmers=' + st.data.farmers.length + ' crops=' + st.data.crops.length + ' bookings=' + st.data.bookings.length);
  check('state has no staff passwords', st.data.staff_users.every(u => u.pwd === undefined),
    JSON.stringify(st.data.staff_users[0]));
  check('state includes the demo farmer', st.data.farmers.some(f => f.id === 'KSN-4471'));
  check("state includes today's live queue",
    st.data.bookings.some(b => b.date === new Date().toISOString().slice(0, 10) && b.center_id === 'C1'));

  const missing = await api(base, 'GET', '/api/nope');
  check('unknown endpoint returns 404 JSON', missing.status === 404 && !!missing.data.error);

  console.log('\n== registration over HTTP ==');
  const dup = await api(base, 'POST', '/api/register', { name: 'Dup', phone: '9845012345' });
  check('duplicate mobile number rejected with 409', dup.status === 409, 'status=' + dup.status);
  const badPhone = await api(base, 'POST', '/api/register', { name: 'Bad', phone: '12345' });
  check('invalid mobile number rejected with 400', badPhone.status === 400, 'status=' + badPhone.status);
  const reg = await api(base, 'POST', '/api/register', {
    name: 'Kavya Murthy', phone: '9972012398', village: 'Kodihalli', district: 'Mandya',
    land_area: 3.5, crops: ['wheat'], bank: { acc: '501009912345', ifsc: 'hdfc0001234', holder: 'KAVYA MURTHY' }
  });
  check('registration succeeds over HTTP', reg.status === 200 && /^KSN-\d+$/.test(reg.data.farmer.id), JSON.stringify(reg.data));
  check('IFSC is normalised to upper case', reg.data.farmer.bank.ifsc === 'HDFC0001234');
  const after = await api(base, 'GET', '/api/state');
  check('new farmer is visible to every other client',
    after.data.farmers.some(f => f.phone === '9972012398'));
  check('registration SMS is in the shared outbox',
    after.data.notes.some(n => n.to === '9972012398' && /Farmer ID/.test(n.body)));

  console.log('\n== otp + login webhook ==');
  const otpRes = await api(base, 'POST', '/api/otp', { kind: 'login', id: 'KSN-4471' });
  check('OTP issued', otpRes.status === 200 && /^\d{6}$/.test(otpRes.data.demo_code), JSON.stringify(otpRes.data));
  const wrong = await api(base, 'POST', '/api/webhook/farmer-login', { id: 'KSN-4471', otp: '000000' });
  check('wrong OTP rejected with 401', wrong.status === 401, 'status=' + wrong.status);
  const right = await api(base, 'POST', '/api/webhook/farmer-login', { id: 'KSN-4471', otp: otpRes.data.demo_code });
  check('correct OTP signs the farmer in', right.status === 200 && right.data.farmer.id === 'KSN-4471');
  const reuse = await api(base, 'POST', '/api/webhook/farmer-login', { id: 'KSN-4471', otp: otpRes.data.demo_code });
  check('OTP cannot be reused', reuse.status === 401, 'status=' + reuse.status);
  check('OTP SMS was generated', after.data.notes.length >= 5);

  console.log('\n== shared state across two clients ==');
  // client A books a slot, client B must see it
  const stateA = (await api(base, 'GET', '/api/state')).data;
  const tomorrow = (() => { const d = new Date(); d.setDate(d.getDate() + 1); return d.toISOString().slice(0, 10); })();
  stateA.bookings.push({
    id: 'KS-99001', farmer_id: 'KSN-4471', center_id: 'C2', crop_id: 'ragi',
    date: tomorrow, slot: '12:00', est_qty: 30, status: 'confirmed', stage: 'booked',
    created_at: new Date().toISOString()
  });
  const saved = await api(base, 'POST', '/api/state', stateA);
  check('POST /api/state accepted', saved.status === 200 && saved.data.ok === true);
  const stateB = (await api(base, 'GET', '/api/state')).data;
  check('client B sees the booking client A made', stateB.bookings.some(b => b.id === 'KS-99001'));
  check('client B does not inherit client A session', stateB.session === null && stateB.staff === null);
  check('staff passwords survived the sync',
    fs.existsSync(STORE) && /"pwd":"mandya"/.test(fs.readFileSync(STORE, 'utf8')));

  const badState = await api(base, 'POST', '/api/state', { hello: 'world' });
  check('malformed state rejected with 400', badState.status === 400, 'status=' + badState.status);

  console.log('\n== sms endpoint + outbox ==');
  const smsRes = await api(base, 'POST', '/api/sms', { to: '9845012345', title: 'Test', body: 'Backend SMS test', kind: 'teal' });
  check('POST /api/sms accepted', smsRes.status === 200 && smsRes.data.ok === true);
  const outbox = await api(base, 'GET', '/api/outbox');
  check('message landed in the outbox', outbox.data.notes.some(n => n.body === 'Backend SMS test'));
  const outboxFile = path.join(ROOT, 'server/data/outbox.log');
  check('message appended to outbox.log on disk',
    fs.existsSync(outboxFile) && /Backend SMS test/.test(fs.readFileSync(outboxFile, 'utf8')));
  const noTo = await api(base, 'POST', '/api/sms', { body: 'x' });
  check('SMS without a recipient rejected', noTo.status === 400, 'status=' + noTo.status);

  console.log('\n== reset ==');
  const reset = await api(base, 'POST', '/api/reset', {});
  check('POST /api/reset restores the seed',
    reset.status === 200 && reset.data.state.farmers.length === 7 && reset.data.state.bookings.length === 9,
    'farmers=' + reset.data.state.farmers.length);
  check('reset removes the test booking', !reset.data.state.bookings.some(b => b.id === 'KS-99001'));

  console.log('\n== static hosting ==');
  for (const p of ['/', '/index.html', '/demo.html', '/assets/app.js', '/assets/api.js', '/assets/style.css', '/admin-queue.html']) {
    const r = await fetch(base + p);
    check('serves ' + p, r.status === 200, 'status=' + r.status);
  }
  // %2F stays encoded in the request line, so this reaches the server's own join check
  const traversal = await fetch(base + '/..%2Fserver%2Fdata%2Fstore.json');
  const travText = await traversal.text();
  check('path traversal is blocked', traversal.status === 403 || !/"pwd"/.test(travText),
    'status=' + traversal.status);

  console.log('\n== the real frontend against the real server ==');
  {
    const errors = [];
    const vc = new VirtualConsole();
    vc.on('jsdomError', e => errors.push(e.message));
    const dom = new JSDOM(fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8'), {
      url: base + '/index.html', runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc,
      beforeParse(w) {
        w.scrollTo = () => {};
        w.fetch = (u, o) => fetch(u, o);       // real network to the real server
      }
    });
    for (const src of [API, APP]) {
      const sc = dom.window.document.createElement('script');
      sc.textContent = src;
      dom.window.document.body.appendChild(sc);
    }
    dom.window.document.dispatchEvent(new dom.window.Event('DOMContentLoaded', { bubbles: true, cancelable: true }));
    await sleep(600);   // let the async pull resolve

    check('frontend detects the backend', dom.window.KSAPI.isOnline() === true);
    const badge = dom.window.document.querySelector('.conn');
    check('connection badge reads "Live server"', badge && /Live server/.test(badge.textContent),
      badge && badge.textContent);
    check('frontend loaded the shared dataset', dom.window.KS.state().farmers.length === 7,
    'farmers=' + dom.window.KS.state().farmers.length);
    check('no JS errors against the live server', errors.length === 0, errors.join(' | '));

    // make a change in the browser and confirm it reaches the server
    const stt = dom.window.KS.state();
    stt.bookings.push({
      id: 'KS-99002', farmer_id: 'KSN-4471', center_id: 'C1', crop_id: 'maize',
      date: tomorrow, slot: '14:00', est_qty: 12, status: 'confirmed', stage: 'booked',
      created_at: new Date().toISOString()
    });
    dom.window.KS.state = () => stt;      // not needed, but harmless
    await dom.window.KSAPI.push(stt);
    await sleep(250);
    const serverAfter = (await api(base, 'GET', '/api/state')).data;
    check('a browser change reaches the server', serverAfter.bookings.some(b => b.id === 'KS-99002'));
    dom.window.close();
  }

  child.kill('SIGTERM');
  await sleep(300);
  console.log('\n' + (failures ? failures + ' FAILURE(S):\n - ' + fails.join('\n - ') : 'All backend checks passed.'));
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
