/* Smoke + journey test for the Krishi Setu prototype.
   Runs the real assets/app.js inside jsdom (a real DOM), not a re-implementation. */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

// works whether the tests sit beside the app (combined folder)
// or one level above it (kisan-setu/ sub-folder)
const ROOT = fs.existsSync(path.join(__dirname, 'assets/app.js'))
  ? __dirname
  : path.join(__dirname, 'kisan-setu');
const API = fs.readFileSync(path.join(ROOT, 'assets/api.js'), 'utf8');
const APP = fs.readFileSync(path.join(ROOT, 'assets/app.js'), 'utf8');

const PAGES = [
  'index.html', 'rates.html', 'register.html', 'login.html', 'welcome.html',
  'dashboard.html', 'book.html', 'bookings.html', 'queue.html', 'payment.html',
  'payments.html', 'notifications.html', 'profile.html', 'staff-login.html',
  'admin-queue.html', 'admin-procure.html', 'admin-payments.html',
  'admin-prices.html', 'admin-analytics.html', 'admin-disputes.html', 'demo.html'
];

let failures = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) console.log('  ok   ' + name);
  else { failures++; fails.push(name + (extra ? ' — ' + extra : '')); console.log('  FAIL ' + name + (extra ? ' — ' + extra : '')); }
}

function makeDom(pageWithQs, store, opts = {}) {
  const base = pageWithQs.split('?')[0];
  const qs = pageWithQs.indexOf('?') >= 0 ? pageWithQs.slice(pageWithQs.indexOf('?')) : '';
  const url = 'https://ks.test/' + base + qs;
  const errors = [];
  const nav = { target: null };
  const vc = new (require('jsdom').VirtualConsole)();
  vc.on('jsdomError', e => {
    // the app navigates through KS.goto(); a reload after a dispute is expected too
    if (/navigation to another Document/.test(e.message)) return;
    errors.push('jsdomError: ' + e.message);
  });
  const dom = new JSDOM(fs.readFileSync(path.join(ROOT, base), 'utf8'), {
    url,
    runScripts: 'dangerously',
    pretendToBeVisual: true,
    virtualConsole: vc,
    beforeParse(window) {
      try { window.localStorage.setItem('kisan_setu_v1', JSON.stringify(store)); } catch (e) {}
      window.addEventListener('error', e => errors.push(e.message));
      window.__KS_NAV = (u) => { nav.target = u; window.__navLast = u; };
      // jsdom has no fetch and no network: these tests exercise offline mode
      window.fetch = (u) => Promise.reject(new TypeError('Failed to fetch ' + u));
      window.scrollTo = () => {};
      // track timers so we can clear them and let the process exit
      window.__timers = [];
      const si = window.setInterval.bind(window);
      window.setInterval = function (fn, ms) { const id = si(fn, ms); window.__timers.push(id); return id; };
    }
  });
  for (const src of [API, APP]) {
    const script = dom.window.document.createElement('script');
    script.textContent = src;
    dom.window.document.body.appendChild(script);
  }
  // jsdom keeps readyState at "loading" while the <link> stylesheet is unfetched,
  // so DOMContentLoaded never fires on its own — fire it, like a real browser would.
  dom.window.document.dispatchEvent(new dom.window.Event('DOMContentLoaded', { bubbles: true, cancelable: true }));
  dom.window.__nav = () => nav.target;
  return { dom, win: dom.window, doc: dom.window.document, errors, nav };
}
function nav0(win) { return win.__navLast; }
function _unused() {
}

function store(win) { return JSON.parse(win.localStorage.getItem('kisan_setu_v1')); }
function close(win) { (win.__timers || []).forEach(t => win.clearInterval(t)); win.close(); }

/* ---------- 1. every page boots and renders ---------- */
console.log('\n== page boot ==');
const withSession = (st, who) => Object.assign({}, st, who === 'staff'
  ? { staff: 'STAFF-MANDYA-01', session: 'KSN-4471' }
  : { session: 'KSN-4471' });

let seed = null;
PAGES.forEach(p => {
  const who = p.indexOf('admin-') === 0 ? 'staff' : 'farmer';
  const page = p === 'payment.html' ? 'payment.html?id=KS-88231' : p;
  const { win, doc, errors } = makeDom(page, seed ? withSession(seed, who) : {});
  if (!seed) seed = store(win);
  const bodyText = doc.body.textContent.replace(/\s+/g, ' ').trim();
  const roots = [...doc.querySelectorAll('[id$="-root"]')];
  const rendered = roots.length === 0 || roots.some(r => r.innerHTML.trim().length > 200);
  check(p + ' renders', rendered, 'root html length ' + roots.map(r => r.innerHTML.length).join(','));
  check(p + ' has masthead/appbar', /Krishi Setu/.test(doc.body.innerHTML));
  check(p + ' no JS errors', errors.length === 0, errors.join(' | '));
  check(p + ' has footer', /Helpline|1800-425-7733|Krishi Setu/.test(doc.getElementById('foot').innerHTML));
  const hindi = (doc.body.textContent + doc.body.innerHTML).match(/[\u0900-\u097F\u0C80-\u0CFF]+/g);
  check(p + ' contains no Hindi text', !hindi, hindi && hindi.join(','));
  check(p + ' has no language toggle', !doc.querySelector('.lang-toggle'));
  check(p + ' degrades to offline without a backend',
    !!doc.querySelector('.conn') && /Offline/.test(doc.querySelector('.conn').textContent));
  close(win);
});

/* ---------- 2. registration journey ---------- */
console.log('\n== registration ==');
{
  const { win, doc, errors, nav } = makeDom('register.html', seed);
  const KS = win.KS;
  const $ = s => doc.querySelector(s);
  const set = (s, v) => { $(s).value = v; };
  const regSubmit = () => doc.querySelector('#reg-form')
    .dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));
  // step 1
  set('#r-name', 'Kavya Murthy'); set('#r-phone', '9972012398'); set('#r-dob', '1986'); set('#r-aadhaar', '447122903344');
  regSubmit();
  check('step 2 reached (address)', !!$('#r-village'), 'still on step 1');
  // step 2
  set('#r-village', 'Kodihalli'); set('#r-district', 'Mandya'); $('#r-nearest').value = 'C1';
  regSubmit();
  check('step 3 reached (land)', !!$('#r-area'));
  // step 3
  set('#r-area', '3.5');
  doc.querySelectorAll('[data-crop]')[0].dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
  regSubmit();
  check('step 4 reached (bank)', !!$('#r-acc'));
  // step 4 — bad IFSC must be rejected
  set('#r-holder', 'KAVYA MURTHY'); set('#r-acc', '50100991'); set('#r-ifsc', 'BADIFSC');
  regSubmit();
  check('invalid IFSC rejected', $('#e-ifsc').classList.contains('show'));
  set('#r-acc', '501009912345'); set('#r-ifsc', 'hdfc0001234');
  regSubmit();
  check('step 5 reached (OTP)', !!$('#r-otp'));
  check('OTP was generated', /\d{6}/.test(store(win).last_otp));
  // wrong OTP
  set('#r-otp', '000000');
  regSubmit();
  check('wrong OTP rejected', $('#e-otp').classList.contains('show'));
  // correct OTP
  const otp = store(win).last_otp;
  set('#r-otp', otp);
  regSubmit();
  const st = store(win);
  const newF = st.farmers[st.farmers.length - 1];
  check('farmer created with correct fields',
    newF.name === 'Kavya Murthy' && newF.phone === '9972012398' && newF.land_area === 3.5 &&
    newF.bank.ifsc === 'HDFC0001234' && newF.crops.length === 1, JSON.stringify(newF));
  check('session set for new farmer', st.session === newF.id);
  check('welcome SMS queued', st.notes.some(n => n.to === '9972012398' && /Farmer ID/.test(n.body)));
  check('navigated to welcome page', (nav.target || '').indexOf('welcome.html') === 0, nav.target);
  // welcome page renders for the new farmer
  const wv = makeDom('welcome.html?id=' + newF.id, store(win));
  check('welcome page shows the new farmer ID', wv.doc.body.textContent.indexOf(newF.id) >= 0);
  check('welcome page has no JS errors', wv.errors.length === 0, wv.errors.join(' | '));
  close(wv.win);
  check('no JS errors in journey', errors.length === 0, errors.join(' | '));
  seed = st;
  close(win);
}

/* ---------- 3. login + booking ---------- */
console.log('\n== login + booking ==');
{
  const { win, doc, errors, nav } = makeDom('login.html', seed);
  const $ = s => doc.querySelector(s);
  $('#l-id').value = 'NOPE-1';
  $('#login-form').dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));
  check('unknown farmer ID rejected', $('#e-lid').classList.contains('show'));
  $('#l-id').value = 'ksn-4471';
  $('#login-form').dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));
  check('OTP stage shown, ID case-insensitive', !!$('#l-otp'));
  $('#l-otp').value = '111111';
  $('#login-form').dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));
  check('wrong login OTP rejected', $('#e-lotp').classList.contains('show'));
  const st0 = store(win);
  $('#l-otp').value = st0.last_otp;
  $('#login-form').dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));
  check('session created on login', store(win).session === 'KSN-4471');
  check('login navigates to dashboard', (nav.target || '') === 'dashboard.html', nav.target);
  seed = store(win);
  close(win);
}
{
  const { win, doc, errors, nav } = makeDom('book.html', seed);
  const $ = s => doc.querySelector(s);
  const submit = () => $('#bk-form').dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));
  check('booking step 1 shows centres', doc.querySelectorAll('input[name="c"]').length === 3);
  doc.querySelector('input[name="c"][value="C1"]').dispatchEvent(new win.Event('change', { bubbles: true }));
  submit();
  check('step 2 lists active crops', doc.querySelectorAll('input[name="p"]').length >= 10);
  doc.querySelector('input[name="p"][value="ragi"]').dispatchEvent(new win.Event('change', { bubbles: true }));
  submit();
  // quantity validation
  submit();
  check('empty quantity rejected', $('#e-qty').classList.contains('show'));
  $('#b-qty').value = '22';
  $('#b-qty').dispatchEvent(new win.Event('input', { bubbles: true }));
  check('indicative value computed (22 × 4290 = 94,380)', /94,380/.test($('#est-amt').textContent), $('#est-amt').textContent);
  submit();
  check('step 4 shows date strip and slots', doc.querySelectorAll('[data-date]').length === 8 && doc.querySelectorAll('[data-slot]').length === 6);
  const freeSlot = [...doc.querySelectorAll('[data-slot]')].find(b => !b.disabled);
  freeSlot.dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
  submit();
  check('step 5 confirmation reached', /Confirm booking/.test(doc.body.innerHTML));
  const before = store(win).bookings.length;
  submit();
  const st = store(win);
  check('booking written to store', st.bookings.length === before + 1);
  const b = st.bookings[st.bookings.length - 1];
  check('booking has crop/qty/slot', b.crop_id === 'ragi' && b.est_qty === 22 && !!b.slot && b.status === 'confirmed', JSON.stringify(b));
  check('confirmation SMS sent', st.notes.some(n => n.body.indexOf(b.id) >= 0 && /Slot confirmed/.test(n.body)));
  check('farmer sent to the live queue page', /queue\.html\?id=/.test(nav.target || ''), nav.target);
  check('no JS errors', errors.length === 0, errors.join(' | '));
  seed = st;
  close(win);
}

/* ---------- 4. queue + staff check-in + procurement + payment ---------- */
console.log('\n== queue, check-in, procurement, payment ==');
{
  const { win, doc, errors } = makeDom('queue.html', seed);
  check('queue shows position', /Your position/i.test(doc.body.textContent));
  check('queue renders a QR svg', !!doc.querySelector('.qrbox svg rect'));
  check('queue lists farmers in slot', doc.querySelectorAll('.qrow').length > 0);
  check('no JS errors', errors.length === 0, errors.join(' | '));
  close(win);
}
{
  // staff signs in
  const { win, doc, errors } = makeDom('staff-login.html', seed);
  const $ = s => doc.querySelector(s);
  $('#s-id').value = 'WRONG'; $('#s-pw').value = 'x';
  $('#staff-form').dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));
  check('bad staff credentials rejected', $('#e-staff').classList.contains('show'));
  $('#s-id').value = 'STAFF-MANDYA-01'; $('#s-pw').value = 'mandya';
  $('#staff-form').dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));
  check('staff session created', store(win).staff === 'STAFF-MANDYA-01');
  seed = store(win);
  close(win);
}
{
  const { win, doc, errors, nav } = makeDom('admin-queue.html', seed);
  const KS = win.KS;
  // find today's waiting booking for the demo farmer
  const st = store(win);
  const today = new Date().toISOString().slice(0, 10);
  let target = st.bookings.find(b => b.date === today && b.center_id === 'C1' && b.status === 'confirmed' && b.farmer_id === 'KSN-4472');
  if (!target) target = st.bookings.find(b => b.date === today && b.status === 'confirmed');
  KS.checkIn(target.id);
  let after = store(win).bookings.find(b => b.id === target.id);
  check('check-in updates status', after.status === 'checked_in' && !!after.checked_in_at);
  check('check-in sends SMS', store(win).notes.some(n => /checked in/i.test(n.body) && n.body.indexOf(after.id) >= 0));
  // Staff flow from here: weigh a farmer, which frees a bay, then call the next one.
  const servingAfterCheckIn = store(win).bookings.filter(b => b.status === 'checked_in' && b.date === today).length;
  check('three farmers are now at the weighbridge (2 from the seed + the one we scanned)',
    servingAfterCheckIn === 3, 'serving=' + servingAfterCheckIn);
  KS.callNext();
  check('call-next does nothing while every bay is busy',
    store(win).bookings.filter(b => b.status === 'checked_in' && b.date === today).length === servingAfterCheckIn);
  check('no premature "you are next" SMS is sent',
    !store(win).notes.some(n => n.title === 'You are next'));

  const servingId = store(win).bookings.find(b => b.status === 'checked_in' && b.date === today).id;
  KS.recordOpen(servingId);
  check('record-weight link points at the procurement form',
    (nav.target || '') === 'admin-procure.html?id=' + servingId, nav.target);
  const weigh = (st) => {
    const id = st.bookings.find(b => b.status === 'checked_in' && b.date === today).id;
    const pv = makeDom('admin-procure.html?id=' + id, st);
    pv.doc.querySelector('#procure-form').dispatchEvent(new pv.win.Event('submit', { bubbles: true, cancelable: true }));
    const out = store(pv.win);
    close(pv.win);
    return out;
  };
  const afterFirst = weigh(store(win));
  check('weighing a lot frees a bay',
    afterFirst.bookings.filter(b => b.status === 'checked_in' && b.date === today).length === servingAfterCheckIn - 1);
  const afterSecond = weigh(afterFirst);
  check('weighing the second lot leaves one bay free',
    afterSecond.bookings.filter(b => b.status === 'checked_in' && b.date === today).length === 1,
    'serving=' + afterSecond.bookings.filter(b => b.status === 'checked_in' && b.date === today).length);

  const q2 = makeDom('admin-queue.html', afterSecond);
  const waitingBefore = store(q2.win).bookings.filter(b => b.status === 'confirmed' && b.date === today).length;
  q2.win.KS.callNext();
  check('call-next promotes a waiting farmer once a bay is free',
    store(q2.win).bookings.filter(b => b.status === 'checked_in' && b.date === today).length === 2);
  check('call-next SMS says "you are next"', store(q2.win).notes.some(n => n.title === 'You are next'));
  check('there was someone waiting to promote', waitingBefore > 1, 'waiting=' + waitingBefore);
  close(q2.win);
  check('no JS errors', errors.length === 0, errors.join(' | '));
  seed = store(win);
  close(win);
}
{
  const { win, doc, errors } = makeDom('admin-procure.html', seed);
  const st = store(win);
  const serving = st.bookings.find(b => b.status === 'checked_in');
  const { win: w2, doc: d2 } = makeDom('admin-procure.html?id=' + serving.id, seed);
  check('procurement form opens for a checked-in farmer', !!d2.querySelector('#w-qty'));
  const $ = s => d2.querySelector(s);
  $('#w-qty').value = '19.6';
  $('#w-qty').dispatchEvent(new w2.Event('input', { bubbles: true }));
  check('net payable recalculates (19.6 × rate − 1.2%)',
    /[\d,]+/.test($('#w-net').textContent) && $('#w-net').textContent.length > 3, $('#w-net').textContent);
  const rate = st.crops.find(c => c.id === serving.crop_id).rate;
  const expectNet = Math.round(19.6 * rate * (1 - 0.012));
  check('net value is arithmetically correct',
    $('#w-net').textContent.replace(/[^\d]/g, '') === String(expectNet),
    $('#w-net').textContent + ' vs ' + expectNet);
  $('#procure-form').dispatchEvent(new w2.Event('submit', { bubbles: true, cancelable: true }));
  const after = store(w2).bookings.find(b => b.id === serving.id);
  check('procurement recorded', after.status === 'procured' && after.actual_qty === 19.6 && after.amount === Math.round(19.6 * rate), JSON.stringify({ a: after.actual_qty, amt: after.amount }));
  check('weighment SMS sent to farmer', store(w2).notes.some(n => /Quantity recorded/.test(n.title)));
  seed = store(w2);
  close(win); close(w2);
}
{
  const { win, doc, errors } = makeDom('admin-payments.html', seed);
  const KS = win.KS;
  const st = store(win);
  const procured = st.bookings.find(b => b.status === 'procured');
  KS.initiatePayment(procured.id);
  check('payment initiated', store(win).bookings.find(b => b.id === procured.id).status === 'payment_initiated');
  KS.openSettle(procured.id);
  const utr = doc.querySelector('#s-utr').value;
  KS.settlePayment(procured.id);
  const done = store(win).bookings.find(b => b.id === procured.id);
  check('payment settled with UTR', done.status === 'payment_completed' && done.utr === utr && !!done.payment_completed_at, JSON.stringify(done));
  check('credit SMS includes UTR', store(win).notes.some(n => n.body.indexOf(utr) >= 0));
  check('no JS errors', errors.length === 0, errors.join(' | '));
  seed = store(win);
  close(win);
}
{
  // farmer sees the full timeline
  const st = seed;
  const paid = st.bookings.find(b => b.status === 'payment_completed' && b.farmer_id === 'KSN-4471');
  const { win, doc, errors } = makeDom('payment.html?id=' + (paid ? paid.id : st.bookings.find(b => b.stage === 'payment_completed').id), st);
  const steps = doc.querySelectorAll('.tl-item');
  check('payment timeline has 5 stages', steps.length === 5);
  check('all 5 stages marked done', [...steps].every(s => s.classList.contains('done')), [...steps].map(s => s.className).join('|'));
  check('calculation table shown', /Net payable to your account/.test(doc.body.textContent));
  check('QR present', !!doc.querySelector('.qrbox svg'));
  check('no JS errors', errors.length === 0, errors.join(' | '));
  close(win);
}

/* ---------- 5. rate management ---------- */
console.log('\n== rate management ==');
{
  const { win, doc, errors } = makeDom('admin-prices.html', seed);
  const KS = win.KS;
  const inp = doc.querySelector('[data-rate="wheat"]');
  const before = store(win).crops.find(c => c.id === 'wheat').rate;
  const farmersWithWheat = store(win).farmers.filter(f => (f.crops || []).includes('wheat')).length;
  inp.value = '2600';
  inp.dispatchEvent(new win.KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
  const c = store(win).crops.find(x => x.id === 'wheat');
  check('rate published', c.rate === 2600, 'rate=' + c.rate);
  check('history appended', c.history[c.history.length - 1].rate === 2600);
  check('farmers growing wheat got SMS',
    store(win).notes.filter(n => /rate revised from Rs 2475 to Rs 2600/.test(n.body)).length === farmersWithWheat,
    farmersWithWheat + ' farmers with wheat');
  KS.addProduct();
  doc.querySelector('#np-name').value = 'Sunflower';
  doc.querySelector('#np-rate').value = '6760';
  KS.saveProduct();
  check('new product added to catalogue', store(win).crops.some(x => x.id === 'sunflower' && x.rate === 6760));
  KS.toggleCrop('maize');
  check('product deactivated', store(win).crops.find(c => c.id === 'maize').active === false);
  check('no JS errors', errors.length === 0, errors.join(' | '));
  seed = store(win);
  close(win);
}

/* ---------- 6. disputes + profile ---------- */
console.log('\n== disputes + profile ==');
{
  const { win, doc, errors } = makeDom('dashboard.html', seed);
  const KS = win.KS;
  KS.openDisputeModal();
  check('dispute modal opens with lot list', !!doc.querySelector('#d-booking'));
  doc.querySelector('#d-reason').value = 'Quantity mismatch';
  doc.querySelector('#d-note').value = 'Slip showed 24.1 qtl.';
  KS.submitDispute();
  const d = store(win).disputes[0];
  check('dispute stored', d.status === 'open' && d.reason === 'Quantity mismatch');
  check('dispute SMS sent', store(win).notes.some(n => /Grievance DSP-/.test(n.body)));
  seed = store(win);
  close(win);
}
{
  const { win, doc, errors } = makeDom('admin-disputes.html', seed);
  const KS = win.KS;
  const open = store(win).disputes.find(d => d.status === 'open');
  KS.openResolve(open.id);
  doc.querySelector('#d-res').value = 'Re-weighed: 24.1 qtl confirmed, record corrected.';
  KS.saveResolution(open.id);
  const d = store(win).disputes.find(x => x.id === open.id);
  check('dispute resolved', d.status === 'resolved' && /Re-weighed/.test(d.resolution));
  check('resolution SMS sent', store(win).notes.some(n => /Grievance DSP-.* resolved/i.test(n.body)));
  check('no JS errors', errors.length === 0, errors.join(' | '));
  seed = store(win);
  close(win);
}
{
  const { win, doc, errors } = makeDom('profile.html', seed);
  const $ = s => doc.querySelector(s);
  $('#p-village').value = 'Bellur Cross';
  $('#p-acc').value = '50100247119999';
  $('#pf-form').dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));
  check('bank change demands OTP', !!$('#p-otp'));
  const code = /Demo code:\s*(\d{6})/.exec(doc.querySelector('.modal').textContent)[1];
  $('#p-otp').value = '000000';
  $('#p-otp-ok').dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
  check('wrong OTP does not save bank change', store(win).farmers.find(f => f.id === 'KSN-4471').bank.acc === '50100247119203');
  $('#p-otp').value = code;
  $('#p-otp-ok').dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
  const f = store(win).farmers.find(x => x.id === 'KSN-4471');
  check('bank change saved after OTP', f.bank.acc === '50100247119999');
  check('village saved too', f.village === 'Bellur Cross');
  check('no JS errors', errors.length === 0, errors.join(' | '));
  close(win);
}

/* ---------- 7. guided demo ---------- */
console.log('\n== guided demo ==');
{
  const { win, doc, errors } = makeDom('demo.html', seed);
  check('demo page lists all 14 steps', doc.querySelectorAll('.script li').length === win.KS.TOUR.length,
    doc.querySelectorAll('.script li').length + ' vs ' + win.KS.TOUR.length);
  check('every step points at a page that exists',
    win.KS.TOUR.every(t => PAGES.includes(t.page)), win.KS.TOUR.filter(t => !PAGES.includes(t.page)).map(t => t.page).join(','));
  check('demo accounts are documented', /KSN-4471/.test(doc.body.textContent) && /STAFF-MANDYA-01/.test(doc.body.textContent));
  check('no JS errors', errors.length === 0, errors.join(' | '));

  win.KS.startDemo();
  check('startDemo goes to the landing page', (nav0(win) || '') === 'index.html', nav0(win));
  const st = store(win);
  check('startDemo logs in the demo farmer', st.session === 'KSN-4471');
  check('startDemo logs in the centre operator', st.staff === 'STAFF-MANDYA-01');
  check('startDemo seeds today\'s queue',
    st.bookings.some(b => b.date === new Date().toISOString().slice(0, 10) && b.center_id === 'C1'));
  close(win);
}
{
  // with a tour active, every page shows the prompt card on the right step
  const st = store(makeDom('index.html', seed).win);
  const withTour = Object.assign({}, st, { session: 'KSN-4471', staff: 'STAFF-MANDYA-01' });
  const t0 = makeDom('index.html', withTour);
  t0.win.localStorage.setItem('kisan_setu_tour', JSON.stringify({ step: 0 }));
  close(t0.win);
  const t1 = makeDom('queue.html', withTour);
  t1.win.localStorage.setItem('kisan_setu_tour', JSON.stringify({ step: 6 }));
  close(t1.win);
  const t2 = makeDom('queue.html', withTour);
  // re-seed with the tour flag persisted
  close(t2.win);

  const seeded = Object.assign({}, withTour);
  const v = makeDom('admin-prices.html', seeded);
  v.win.localStorage.setItem('kisan_setu_tour', JSON.stringify({ step: 11 }));
  // reload the page so boot() picks the tour up
  const v2 = makeDom('admin-prices.html', JSON.parse(v.win.localStorage.getItem('kisan_setu_v1')));
  v2.win.localStorage.setItem('kisan_setu_tour', JSON.stringify({ step: 11 }));
  close(v.win); close(v2.win);

  const dom3 = new JSDOM(fs.readFileSync(path.join(ROOT, 'admin-prices.html'), 'utf8'), {
    url: 'https://ks.test/admin-prices.html', runScripts: 'dangerously', pretendToBeVisual: true,
    virtualConsole: new (require('jsdom').VirtualConsole)(),
    beforeParse(w) {
      w.localStorage.setItem('kisan_setu_v1', JSON.stringify(seeded));
      w.localStorage.setItem('kisan_setu_tour', JSON.stringify({ step: 11 }));
      w.scrollTo = () => {}; w.__KS_NAV = () => {}; w.__timers = [];
    }
  });
  for (const src of [API, APP]) {
    const sc = dom3.window.document.createElement('script');
    sc.textContent = src;
    dom3.window.document.body.appendChild(sc);
  }
  dom3.window.document.dispatchEvent(new dom3.window.Event('DOMContentLoaded', { bubbles: true, cancelable: true }));
  const card = dom3.window.document.querySelector('.tour');
  check('prompt card appears when a demo is running', !!card);
  check('prompt card shows the step for the current page',
    card && /Backend rate control/.test(card.textContent), card && card.textContent.slice(0, 60));
  check('prompt card shows all 14 step dots', dom3.window.document.querySelectorAll('.tdot').length === 14);
  dom3.window.close();
}
{
  const { win, doc, errors, nav } = makeDom('login.html', seed);
  check('farmer login offers a one-click demo entry',
    /Demo login as KSN-4471/.test(doc.body.textContent));
  win.KS.demoLoginFarmer();
  check('demo login signs in the seeded farmer', store(win).session === 'KSN-4471');
  check('demo login lands on the dashboard', (nav.target || '') === 'dashboard.html', nav.target);
  check('no JS errors', errors.length === 0, errors.join(' | '));
  close(win);
}

console.log('\n' + (failures ? failures + ' FAILURE(S):\n - ' + fails.join('\n - ') : 'All checks passed.'));
process.exit(failures ? 1 : 0);
