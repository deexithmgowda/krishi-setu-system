=================================================================
 KRISHI SETU — COMBINED FOLDER, READY TO DEPLOY
=================================================================
Everything is already in the right place. You do NOT need to move
or merge any files. Frontend and backend live together:

    index.html, demo.html, ... (21 pages)   the website
    assets/style.css, api.js, app.js        design + logic
    server/index.js                         the backend
    package.json                            tells the host how to start it

One process serves both the website and the API. One URL for everything.


-----------------------------------------------------------------
STEP 0 — CHECK IT WORKS ON YOUR COMPUTER FIRST  (2 minutes)
-----------------------------------------------------------------
You need Node.js 18 or newer. Check with:

    node --version

If that says "command not found", install it from https://nodejs.org
(pick the LTS button, click Next until it finishes).

Then, in this folder:

    npm start

You should see:

    Krishi Setu — server running
    Site      http://localhost:3000

Open http://localhost:3000. Top-right corner must say "Live server".
Press Ctrl+C in the terminal to stop it.


-----------------------------------------------------------------
OPTION A — RENDER   (free, gives you a public link, ~10 minutes)
-----------------------------------------------------------------
Render needs your code on GitHub first.

1. Create a free account at https://github.com
2. Click the + (top right) > "New repository".
   Name it:  kisan-setu     Tick "Public"     Click "Create repository".
3. Click "uploading an existing file".
   Open THIS folder, select everything inside it (Ctrl+A / Cmd+A) and
   drag it into the box. IMPORTANT: drag the CONTENTS, not the folder —
   index.html and package.json must end up at the top level.
   Tick "Include everything" if asked. Click "Commit changes".
4. Go to https://render.com and sign in with GitHub.
5. Dashboard > New > Web Service > connect your kisan-setu repo.
6. Fill in exactly this:
       Name              krishi-setu
       Region            Singapore (closest to India)
       Runtime           Node
       Build Command     npm install --omit=dev
       Start Command     npm start
       Instance Type     Free
7. Add one environment variable (Advanced section):
       Key   NPM_CONFIG_PRODUCTION     Value   true
8. Click "Create Web Service".
9. Wait about 2 minutes. You get:
       https://krishi-setu.onrender.com
   That is your live website AND your API. Share that link with judges.

Note: the free tier sleeps after 15 minutes of no traffic, so the first
visit after a pause takes ~30 seconds to wake up. Open your link once
before you present.


-----------------------------------------------------------------
OPTION B — RAILWAY   (free trial credit, slightly faster setup)
-----------------------------------------------------------------
1. https://railway.app > Login with GitHub.
2. New Project > Deploy from GitHub repo > pick kisan-setu
   (if it is not listed, click "Configure GitHub App" and allow it).
3. Railway reads package.json and starts it automatically.
4. Settings > Networking > "Generate Domain".
5. That domain is your live site.


-----------------------------------------------------------------
OPTION C — YOUR OWN LAPTOP, ON THE HACKATHON WI-FI  (no internet needed)
-----------------------------------------------------------------
This is the safest option on stage, because it does not depend on
anybody else's server being awake.

1. In this folder:   npm start
2. Find your laptop's IP address:
       Windows:  ipconfig        (look for IPv4 Address, e.g. 192.168.1.7)
       Mac/Linux: ifconfig       or:  ip addr
3. Judges on the same Wi-Fi open:   http://192.168.1.7:3000
   Everyone shares one queue and one dataset.

If Windows Firewall asks, tick "Private networks" and allow.


-----------------------------------------------------------------
OPTION D — NETLIFY  (frontend only, no backend)
-----------------------------------------------------------------
Only if you cannot get a Node host. Drag this folder onto
https://app.netlify.com/drop and it works as a website, but each
visitor's data stays in their own browser — two phones will NOT see
the same queue. The badge will read "Offline · local data".
That is fine for a single-screen demo and nothing breaks.


-----------------------------------------------------------------
AFTER YOU DEPLOY — CHECKLIST
-----------------------------------------------------------------
[ ] Open your link. Top-right badge says "Live server".
[ ] demo.html > "Start the guided demo" > the 14-step card appears.
[ ] Log in as the farmer: KSN-4471 (OTP is shown on screen).
[ ] Log in as staff: STAFF-MANDYA-01 / mandya
[ ] Open the link on your phone too. Book a slot on the phone,
    refresh the laptop — the staff queue must show it. That is the
    proof the backend is working.


-----------------------------------------------------------------
THINGS THAT WILL CONFUSE YOU IF YOU DO NOT KNOW
-----------------------------------------------------------------
* "npm: command not found" — Node.js is not installed, or you did not
  restart the terminal after installing it.

* Port already in use — something else is on 3000. Use:
      PORT=8080 npm start
  (on Windows:  set PORT=8080 && npm start )

* The data resets when the free server restarts. That is normal — free
  containers have no permanent disk. The demo dataset comes back
  automatically. For permanent data you need a database (see BACKEND.txt).

* SMS is simulated: messages appear on the farmer's Alerts page and are
  written to server/data/outbox.log. Real SMS = three environment
  variables, no code change (see BACKEND.txt).

* To reset everything to a clean demo state at any time:
  open demo.html and press "Reset all demo data".
